/**
 * @brief       PID基础控制库(C++) - 电赛动态dt升级版
 * @details     增加动态时间差(dt)计算和积分分离功能，适配非固定频率的视觉任务
 * */

#ifndef PID_H
#define PID_H
#include <algorithm>
#include <cmath>

class PID {
public:
    enum PID_type {
        position_type, //位置式PID
        delta_type,    //增量式PID
    };

    PID() = delete;

    // 构造函数增加了 integral_separation_threshold 参数，默认值为 NAN
    PID(const PID_type PID_type, const float kp, const float ki, const float kd,
        const float sum_error_limit_p = NAN, const float sum_error_limit_n = NAN,
        const float output_limit_p = NAN, const float output_limit_n = NAN,
        const float integral_separation_threshold = NAN)
        : PID_type(PID_type), kp(kp), ki(ki), kd(kd),
          sum_error_limit_p(sum_error_limit_p), sum_error_limit_n(sum_error_limit_n),
          output_limit_p(output_limit_p), output_limit_n(output_limit_n),
          integral_separation_threshold(integral_separation_threshold) {}

    void SetTarget(const float Target) { target = Target; }
    void set_sum_error(const float sum_error) { PID::sum_error = sum_error; }
    void clear() {
        sum_error = 0.0f;
        error = 0.0f;
        pre_error = 0.0f;
        output = 0.0f;
    }
    // 经典固定频率 PID 计算 (内环 IMU 200Hz 使用)
    [[nodiscard]] float calc(float input);

    // 专为视觉外环设计的动态 dt PID 计算（直接传入误差）
    [[nodiscard]] float calc_error_dynamic(float current_error, float dt);

    /*设置参数*/
    float target{0};
    PID_type PID_type;
    float kp, ki, kd;

    /*限幅与高阶策略参数*/
    float sum_error_limit_p{NAN};
    float sum_error_limit_n{NAN};
    float output_limit_p{NAN};
    float output_limit_n{NAN};

    // 积分分离阈值：当误差绝对值大于此值时，不再积分并清空历史积分
    float integral_separation_threshold{NAN};

private:
    float error{0};
    float pre_error{0};
    float sum_error{0};
    float output{0};
};

// 经典固定频率计算保持不变
inline float PID::calc(const float input) {
    const float error_ = target - input;
    if (PID_type == position_type) {
        sum_error += error_;
        if (!std::isnan(sum_error_limit_p) && sum_error >= sum_error_limit_p) sum_error = sum_error_limit_p;
        if (!std::isnan(sum_error_limit_n) && sum_error <= sum_error_limit_n) sum_error = sum_error_limit_n;
        output = kp * error_ + ki * sum_error + kd * (error_ - error);
        error = error_;
    } else if (PID_type == delta_type) {
        output += kp * (error_ - error) + ki * (error_) + kd * (error_ - 2 * error + pre_error);
        pre_error = error;
        error = error_;
    }
    if (!std::isnan(output_limit_p) && output >= output_limit_p) output = output_limit_p;
    if (!std::isnan(output_limit_n) && output <= output_limit_n) output = output_limit_n;
    return output;
}

// 动态 dt 与直接误差输入计算
inline float PID::calc_error_dynamic(const float current_error, float dt) {
    // 容错防爆：防止极端掉线情况导致 dt 过大，积分项和微分项爆炸
    if (dt <= 0.001f || dt > 0.1f) dt = 0.01f;

    if (PID_type == position_type) {
        // 积分分离策略
        if (std::isnan(integral_separation_threshold) || std::abs(current_error) <= integral_separation_threshold) {
            // 在瞄准圈内，正常累加积分（严谨公式：误差 * 时间）
            sum_error += current_error * dt;

            // 积分限幅
            if (!std::isnan(sum_error_limit_p) && sum_error >= sum_error_limit_p) sum_error = sum_error_limit_p;
            if (!std::isnan(sum_error_limit_n) && sum_error <= sum_error_limit_n) sum_error = sum_error_limit_n;
        } else {
            // 误差过大出圈时，停止继续累加积分，保持原有积分力度。
            // 绝不能写 sum_error = 0.0f; 否则会导致电机输出突然断崖式下跌。
        }

        // 计算输出（微分项严谨公式：误差变化率 / 时间）
        output = kp * current_error +
                 ki * sum_error +
                 kd * (current_error - error) / dt;

        error = current_error;
    }
    else if (PID_type == delta_type) {
        // 增量式配合 dt
        output += kp * (current_error - error) +
                  ki * current_error * dt +
                  kd * (current_error - 2 * error + pre_error) / dt;
        pre_error = error;
        error = current_error;
    }

    // 输出限幅
    if (!std::isnan(output_limit_p) && output >= output_limit_p) output = output_limit_p;
    if (!std::isnan(output_limit_n) && output <= output_limit_n) output = output_limit_n;

    return output;
}

#endif //PID_H