#include "IMU.h"

uint16_t IMU_rawRoll, IMU_rawPinch, IMU_rawYaw;
float yawAngle, rollAngle, pinchAngle;
uint8_t IMU_buffer[12];
uint8_t IMU_bufferIdx = 0;

// 初始化偏移量为0
float yawAngleOffset = 0.0f;