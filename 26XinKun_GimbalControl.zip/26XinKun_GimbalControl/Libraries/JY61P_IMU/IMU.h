// #ifndef __IMU_H
// #define __IMU_H
//
// #include "stdint.h"
//
// #ifdef __cplusplus
// extern "C" {
//
//
//
// #endif
// // 全部静态内联
// extern uint16_t IMU_rawRoll, IMU_rawPinch, IMU_rawYaw;
// extern float yawAngle, rollAngle, pinchAngle;
// extern uint8_t IMU_buffer[12];
// extern uint8_t IMU_bufferIdx;
// //IUM原始数据-32768~+32767映射到-180°~179.99°
// static inline void IMU_SaveBuffer(uint8_t *buf) {
//     IMU_rawRoll = buf[2] | (buf[3] << 8u);
//     IMU_rawPinch = buf[4] | (buf[5] << 8u);
//     IMU_rawYaw = buf[6] | (buf[7] << 8u);
//     rollAngle = IMU_rawRoll / 32768.0f * 180.0f;
//     pinchAngle = IMU_rawPinch / 32768.0f * 180.0f;//现在的安装方向是电机正方向和IMUpitch轴正方向反向
//     yawAngle = IMU_rawYaw / 32768.0f * 180.0f;//现在的安装方向是电机正方向和IMUyaw轴正方向同向
// }
//
// static inline uint8_t IMU_CheckSum(uint8_t *buf) {
//     uint8_t i;
//     uint8_t checkSum = 0x00;
//     // 对前四个字节求校验和
//     for (i = 0; i < 10; i++) {
//         checkSum += buf[i];
//     }
//     return checkSum;
// }
//
// static inline void IMU_PutByte(uint8_t byte) {
//     if (IMU_bufferIdx == 0) {
//         if (byte == 0x55) {
//             IMU_buffer[IMU_bufferIdx] = byte;
//             IMU_bufferIdx += 1u;
//         }
//     } else if (IMU_bufferIdx == 1) {
//         if (byte == 0x53) {
//             IMU_buffer[IMU_bufferIdx] = byte;
//             IMU_bufferIdx += 1u;
//         } else {
//             IMU_bufferIdx = 0u;
//         }
//     } else if (IMU_bufferIdx < 10) {
//         IMU_buffer[IMU_bufferIdx] = byte;
//         IMU_bufferIdx += 1u;
//     } else if (IMU_bufferIdx == 10) {
//         // 检查校验和
//         if (byte == IMU_CheckSum(IMU_buffer)) {
//             IMU_SaveBuffer(IMU_buffer);
//         }
//         IMU_bufferIdx = 0u;
//     } else {
//         IMU_bufferIdx = 0u;
//     }
// }
//
// #ifdef __cplusplus
// }
// #endif
//
//
// #endif
#ifndef __IMU_H
#define __IMU_H

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

// 全部静态内联
extern uint16_t IMU_rawRoll, IMU_rawPinch, IMU_rawYaw;
extern float yawAngle, rollAngle, pinchAngle;
extern uint8_t IMU_buffer[12];
extern uint8_t IMU_bufferIdx;

// 新增：偏航角偏移量
extern float yawAngleOffset;

// IUM原始数据-32768~+32767映射到-180°~179.99°
static inline void IMU_SaveBuffer(uint8_t *buf) {
    IMU_rawRoll = buf[2] | (buf[3] << 8u);
    IMU_rawPinch = buf[4] | (buf[5] << 8u);
    IMU_rawYaw = buf[6] | (buf[7] << 8u);
    rollAngle = IMU_rawRoll / 32768.0f * 180.0f;
    pinchAngle = IMU_rawPinch / 32768.0f * 180.0f;  //现在的安装方向是电机正方向和IMUpitch轴正方向反向
    yawAngle = IMU_rawYaw / 32768.0f * 180.0f;  //现在的安装方向是电机正方向和IMUyaw轴正方向同向
}

// 给 Yaw 轴置零
// 思路：将当前时刻的原始 Yaw 角度作为零位基准记录下来
static inline void IMU_ZeroYaw(void) {
    yawAngleOffset = yawAngle;
}

// 获取置零后的相对 Yaw 角度 (给外环 PID 使用)
// 思路：当前角度 - 偏移角度，并处理好 360 度循环的边界跳变
static inline float IMU_GetRelativeYaw(void) {
    float relative_yaw = yawAngle - yawAngleOffset;

    // 优化的过零点翻转处理 (保证输出始终在 -180 到 180 之间)
    if (relative_yaw > 180.0f) {
        relative_yaw -= 360.0f;
    } else if (relative_yaw < -180.0f) {
        relative_yaw += 360.0f;
    }

    return relative_yaw;
}

static inline uint8_t IMU_CheckSum(uint8_t *buf) {
    uint8_t i;
    uint8_t checkSum = 0x00;
    for (i = 0; i < 10; i++) {
        checkSum += buf[i];
    }
    return checkSum;
}

static inline void IMU_PutByte(uint8_t byte) {
    // ... 原有代码保持不变 ...
    if (IMU_bufferIdx == 0) {
        if (byte == 0x55) {
            IMU_buffer[IMU_bufferIdx] = byte;
            IMU_bufferIdx += 1u;
        }
    } else if (IMU_bufferIdx == 1) {
        if (byte == 0x53) {
            IMU_buffer[IMU_bufferIdx] = byte;
            IMU_bufferIdx += 1u;
        } else {
            IMU_bufferIdx = 0u;
        }
    } else if (IMU_bufferIdx < 10) {
        IMU_buffer[IMU_bufferIdx] = byte;
        IMU_bufferIdx += 1u;
    } else if (IMU_bufferIdx == 10) {
        if (byte == IMU_CheckSum(IMU_buffer)) {
            IMU_SaveBuffer(IMU_buffer);
        }
        IMU_bufferIdx = 0u;
    } else {
        IMU_bufferIdx = 0u;
    }
}

#ifdef __cplusplus
}
#endif

#endif