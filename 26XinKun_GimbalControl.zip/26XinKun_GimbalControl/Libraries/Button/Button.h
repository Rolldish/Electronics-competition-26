#ifndef BUTTON_H
#define BUTTON_H

#include "main.h"

// 面向对象的按键驱动类
class Button {
public:
    // 构造函数：传入端口、引脚、有效电平（默认低电平有效）
    Button(GPIO_TypeDef* port, uint16_t pin, GPIO_PinState active_level = GPIO_PIN_RESET);

    // 核心心跳函数：必须每隔 10ms 调用一次！
    void tick();

    // 事件读取接口（读取一次后会自动清零，类似读取中断标志位）
    bool isSingleClick();
    bool isDoubleClick();
    bool isLongPress();

private:
    GPIO_TypeDef* port;
    uint16_t pin;
    GPIO_PinState active_level;

    uint8_t state;         // 状态机当前状态
    uint16_t press_time;   // 按下持续时间计数
    uint16_t release_time; // 松开持续时间计数（用于双击判定）

    bool single_click_flag;
    bool double_click_flag;
    bool long_press_flag;
};

#endif // BUTTON_H