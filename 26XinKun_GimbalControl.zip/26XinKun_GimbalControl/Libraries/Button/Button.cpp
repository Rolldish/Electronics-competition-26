#include "Button.h"

Button::Button(GPIO_TypeDef* port, uint16_t pin, GPIO_PinState active_level)
    : port(port), pin(pin), active_level(active_level),
      state(0), press_time(0), release_time(0),
      single_click_flag(false), double_click_flag(false), long_press_flag(false) {}

void Button::tick() {
    // 读取当前真实引脚电平
    bool is_pressed = (HAL_GPIO_ReadPin(port, pin) == active_level);

    // 经典按键状态机（10ms 为一拍）
    switch (state) {
        case 0: // 闲置等待状态
            if (is_pressed) {
                state = 1; // 疑似按下，进入消抖
                press_time = 0;
            }
            break;

        case 1: // 按下消抖与长按检测
            if (is_pressed) {
                press_time++;
                if (press_time >= 50) { // 连续按下 50*10ms = 500ms，判定为长按
                    long_press_flag = true;
                    state = 4; // 进入等待长按释放状态
                }
            } else {
                // 如果没到长按时间就松手了，说明是一次短按
                if (press_time > 2) { // 大于 20ms 才算有效按键，滤除高频干扰
                    state = 2; // 进入等待双击状态
                    release_time = 0;
                } else {
                    state = 0; // 纯属干扰，回退
                }
            }
            break;

        case 2: // 等待双击判定
            if (is_pressed) {
                state = 3; // 在超时前又按下了，进入双击消抖
            } else {
                release_time++;
                if (release_time >= 25) { // 25*10ms = 250ms 内没有第二次按下
                    single_click_flag = true; // 最终判定为单次点击！
                    state = 0;
                }
            }
            break;

        case 3: // 双击确认
            if (is_pressed) {
                double_click_flag = true; // 确认双击！
                state = 4; // 等待最终松手
            } else {
                state = 0; // 干扰，重置
            }
            break;

        case 4: // 等待彻底松手（防止长按或双击后一直按着不断触发）
            if (!is_pressed) {
                state = 0;
            }
            break;
    }
}

// 获取事件，并在读取后自动清除标志位（阅后即焚）
bool Button::isSingleClick() {
    if (single_click_flag) { single_click_flag = false; return true; }
    return false;
}

bool Button::isDoubleClick() {
    if (double_click_flag) { double_click_flag = false; return true; }
    return false;
}

bool Button::isLongPress() {
    if (long_press_flag) { long_press_flag = false; return true; }
    return false;
}