#include <algorithm>
#include <numbers>
#include "QD4310.h"

void QD4310::SendCommand(const Command cmd, const int16_t value) {
    static uint8_t TxBuffer[3];
    TxBuffer[0] = static_cast<uint8_t>(cmd);

    // 【消灭警告】使用 C++ 风格的 reinterpret_cast
    *reinterpret_cast<int16_t *>(TxBuffer + 1) = value;

    uint32_t txMailbox = CAN_TX_MAILBOX0;
    CAN_TxHeaderTypeDef TxHeader;
    TxHeader.IDE = CAN_ID_STD;
    TxHeader.RTR = CAN_RTR_DATA;
    TxHeader.StdId = 0x400 + id;
    TxHeader.ExtId = 0x400 + id;
    TxHeader.TransmitGlobalTime = DISABLE;
    TxHeader.DLC = 3;
    HAL_CAN_AddTxMessage(hcan, &TxHeader, TxBuffer, &txMailbox);

    // 加入防死锁超时机制
    uint32_t timeout = 10000;
    while (HAL_CAN_GetTxMailboxesFreeLevel(hcan) == 0) {
        if (--timeout == 0) break; // 邮箱满且发不出去，直接退出保平安
    }
}

void QD4310::update(const uint8_t feedback[8]) {
    enabled = feedback[0] & 0x01;
    // 使用 C++ 风格强转，避免隐式截断
    current = static_cast<float>(*reinterpret_cast<const int16_t *>(feedback + 2)) * 10.0f / INT16_MAX;
    speed   = static_cast<float>(*reinterpret_cast<const int16_t *>(feedback + 4)) * 1000.0f / INT16_MAX;
    angle   = static_cast<float>(*reinterpret_cast<const uint16_t *>(feedback + 6)) * 2.0f * std::numbers::pi_v<float> / UINT16_MAX;
}

void QD4310::setAngle(const float _angle) {
    // 接收 nodiscard 返回值
    float clamped = std::clamp(_angle, 0.0f, 2.0f * std::numbers::pi_v<float>);
    // 显式转换 float 到 int16_t
    SendCommand(Command::ANGLE, static_cast<int16_t>(clamped / 2.0f / std::numbers::pi_v<float> * UINT16_MAX));
}

void QD4310::setStepAngle(const float _step_angle) {
    float clamped = std::clamp(_step_angle, -2.0f * std::numbers::pi_v<float>, 2.0f * std::numbers::pi_v<float>);
    SendCommand(Command::STEP_ANGLE, static_cast<int16_t>(clamped / 2.0f / std::numbers::pi_v<float> * INT16_MAX));
}

void QD4310::setSpeed(const float _speed) {
    float clamped = std::clamp(_speed, -1000.0f, 1000.0f);
    SendCommand(Command::SPEED, static_cast<int16_t>(clamped / 1000.0f * INT16_MAX));
}

void QD4310::setLowSpeed(const float _speed) {
    float clamped = std::clamp(_speed, -1000.0f, 1000.0f);
    SendCommand(Command::LOW_SPEED, static_cast<int16_t>(clamped / 1000.0f * INT16_MAX));
}

void QD4310::setCurrent(const float _current) {
    float clamped = std::clamp(_current, -10.0f, 10.0f);
    SendCommand(Command::CURRENT, static_cast<int16_t>(clamped / 10.0f * INT16_MAX));
}