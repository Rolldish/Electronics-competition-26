#include "task_public.h"
#include "main.h"
#include "usart.h"
#include "tim.h"
#include "cmsis_os.h"
#include "QD4310.h"
#include "IMU.h"
#include "PID.h"
#include "cmd_protocol.h"
#include "Button.h"
#include <cmath>

extern uint8_t IMU_uartRxBuffer;
float yaw_center = 2.90f;
float pitch_center = 1.528f;
constexpr float PITCH_MAX_LIMIT = 1.528f + 0.15f;
constexpr float PITCH_MIN_LIMIT = 1.528f - 0.15f;
float yaw_speed_imu = 0.0f;
float yaw_speed_vision = 0.0f;
float pitch_speed_vision = 0.0f;
bool stabilizer_enabled = true;

QD4310 YawMotor(&hcan1, 0x00);
QD4310 PitchMotor(&hcan1, 0x01);

PID PID_yaw_imu{PID::PID_type::position_type, 3.0f, 0.0f, 15.0f, NAN, NAN, 450, -450};
PID PID_yaw{PID::PID_type::position_type, 0.3f, 0.0f, 0.001f, NAN, NAN, 15, -15};
PID PID_pitch{PID::PID_type::position_type, 0.3f, 0.0f, 0.001f, NAN, NAN, 10, -10};

MotorCmd current_cmd = {CMD_NONE, 0, 0, 0};

void enable_stabilizer();
void disable_stabilizer();
extern MotorCmd commUARTBuffer;
void enableCommunicationUART() {
    HAL_UARTEx_ReceiveToIdle_DMA(&huart6, (uint8_t*)&commUARTBuffer, sizeof(MotorCmd));
}
extern uint8_t IMU_RxChunkBuffer[];
#define IMU_CHUNK_SIZE 33
void enableIMU() {
    HAL_UARTEx_ReceiveToIdle_DMA(&huart1, IMU_RxChunkBuffer, IMU_CHUNK_SIZE);
}
void commUARTCallback(const MotorCmd* cmd) {
    current_cmd = *cmd;
}
void CAN_InterfaceInit();

Button btnStart(GPIOE, GPIO_PIN_9, GPIO_PIN_RESET); // 启动按键 (PE9)
Button btnStop(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET); // 失能急停按键 (PA0)

void DebugTask(void *argument)
{
    CAN_InterfaceInit();
    osDelay(pdMS_TO_TICKS(100));

    bool is_system_ready = false;

    while (true) {
        // 每10ms滴答一次，纯数学状态机更新，不阻塞CPU
        btnStart.tick();
        btnStop.tick();

        // 按键 1：PE9 长按启动
        if (btnStart.isLongPress()) {
            IMU_ZeroYaw(); //IMU偏航角归零

            // 电机重新上电使能并归中
            YawMotor.enable();
            PitchMotor.enable();
            PitchMotor.setAngle(pitch_center);
            osDelay(pdMS_TO_TICKS(100));

            // 强行清空并重启串口通信
            HAL_UART_AbortReceive(&huart6);
            HAL_UART_AbortReceive(&huart1);
            enableIMU();
            enableCommunicationUART();

            // 启动200Hz角度闭环控制
            HAL_TIM_Base_Start_IT(&htim14);
            is_system_ready = true;
        }

        // 按键 2：PA0 单击失能
        if (btnStop.isSingleClick()) {
            if (is_system_ready) {
                // 关掉增稳逻辑
                disable_stabilizer();

                // 速度归零并切断电机使能
                YawMotor.setSpeed(0);
                PitchMotor.setSpeed(0);
                YawMotor.disable();
                PitchMotor.disable();

                //关掉200Hz定时器中断
                HAL_TIM_Base_Stop_IT(&htim14);
                is_system_ready = false;
            }
        }

        // 挂起任务10ms交出CPU控制权给其他任务
        osDelay(pdMS_TO_TICKS(10));
    }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim == &htim14)
    {
        if (stabilizer_enabled) {
            float current_yaw = IMU_GetRelativeYaw();
            PID_yaw_imu.target += (yaw_speed_vision * 6.0f) / 200.0f;

            if (PID_yaw_imu.target > 180.0f) PID_yaw_imu.target -= 360.0f;
            else if (PID_yaw_imu.target < -180.0f) PID_yaw_imu.target += 360.0f;

            float pid_output = 0.0f;
            if (PID_yaw_imu.target - current_yaw > 180.0f) {
                pid_output = PID_yaw_imu.calc(current_yaw + 360.0f);
            } else if (PID_yaw_imu.target - current_yaw < -180.0f) {
                pid_output = PID_yaw_imu.calc(current_yaw - 360.0f);
            } else {
                pid_output = PID_yaw_imu.calc(current_yaw);
            }
            yaw_speed_imu = pid_output;
        } else {
            yaw_speed_imu = 0;
        }
        YawMotor.setSpeed(yaw_speed_imu);

        if (!std::isnan(pitch_speed_vision)) {
            float current_pitch = PitchMotor.angle;

            if (pitch_speed_vision > 0.0f && current_pitch >= PITCH_MAX_LIMIT) {
                pitch_speed_vision = 0.0f;
                PID_pitch.set_sum_error(0.0f);
            }
            else if (pitch_speed_vision < 0.0f && current_pitch <= PITCH_MIN_LIMIT) {
                pitch_speed_vision = 0.0f;
                PID_pitch.set_sum_error(0.0f);
            }
            PitchMotor.setSpeed(pitch_speed_vision);
        } else {
            PitchMotor.setSpeed(0.0f);
        }
    }
}

void CAN_InterfaceInit() {
    CAN_FilterTypeDef sFilterConfig;
    sFilterConfig.FilterBank = 0;
    sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
    sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
    sFilterConfig.FilterIdLow = 0x0000;
    sFilterConfig.FilterIdHigh = 0x0000;
    sFilterConfig.FilterMaskIdLow = 0x0000;
    sFilterConfig.FilterMaskIdHigh = 0x0000;
    sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
    sFilterConfig.FilterActivation = ENABLE;
    sFilterConfig.SlaveStartFilterBank = 14;
    if (HAL_CAN_ConfigFilter(&hcan1, &sFilterConfig) != HAL_OK) Error_Handler();
    if (HAL_CAN_Start(&hcan1) != HAL_OK) Error_Handler();
    if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) Error_Handler();
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
    if (hcan == &hcan1) {
        CAN_RxHeaderTypeDef rx_header;
        uint8_t rx_data[8];
        HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data);
        if (rx_header.StdId >= 0x500 && rx_header.StdId <= 0x508) {
            if (rx_header.StdId == 0x500) {
                YawMotor.update(rx_data);
            } else if (rx_header.StdId == 0x501) {
                PitchMotor.update(rx_data);
            }
        }
    }
}

void enable_stabilizer() {
    if (stabilizer_enabled) return;
    PID_yaw_imu.target = IMU_GetRelativeYaw();
    stabilizer_enabled = true;
}

void disable_stabilizer() {
    if (!stabilizer_enabled) return;
    stabilizer_enabled = false;
}