//
// Created by 21115 on 2026/4/30.
// brief：协议头文件
//

#ifndef CMD_PROTOCOL_H
#define CMD_PROTOCOL_H

// 指令类型枚举
enum CmdType : uint8_t {
    CMD_NONE = 0,    // 无操作
    CMD_ANGLE = 1,   // 角度指令
    CMD_SPEED = 2,   // 速度指令
    CMD_STOP = 3     // 急停指令
};

// 紧凑打包（禁用字节对齐），确保与上位机结构体字节一致
#pragma pack(push, 1)
typedef struct {
    uint8_t cmd_type;  // 指令类型 (1字节)
    int16_t param1;    // 参数1（角度1/速度1）(2字节)
    int16_t param2;    // 参数2（角度2/速度2）(2字节)
    uint8_t checksum;  // 校验和 (1字节)
} MotorCmd;
#pragma pack(pop)

// 计算校验和（与上位机逻辑一致）
inline uint8_t calc_checksum(const MotorCmd& cmd) {
    uint8_t p1_h = (cmd.param1 >> 8) & 0xFF;
    uint8_t p1_l = cmd.param1 & 0xFF;
    uint8_t p2_h = (cmd.param2 >> 8) & 0xFF;
    uint8_t p2_l = cmd.param2 & 0xFF;
    return (cmd.cmd_type + p1_h + p1_l + p2_h + p2_l) & 0xFF;
}

// 校验指令合法性
inline bool is_cmd_valid(const MotorCmd& cmd) {
    return calc_checksum(cmd) == cmd.checksum;
}

#endif // CMD_PROTOCOL_H