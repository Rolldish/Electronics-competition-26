#include "task_public.h"
#include "cmsis_os.h"
#include "PID.h"
#include "QD4310.h"
#include "cmd_protocol.h"

extern osSemaphoreId_t vision_semHandleHandle;
extern MotorCmd current_cmd;
extern float yaw_speed_vision;
extern float pitch_speed_vision;
extern PID PID_yaw;
extern PID PID_pitch;
extern QD4310 PitchMotor;
extern QD4310 YawMotor;
extern float pitch_center;

extern void enable_stabilizer();
extern void disable_stabilizer();

// 真正的任务执行体
void StartVisionTask_Entry(void *argument) {
    // 上电时强制清空CubeMX赋予的初始信号量
    osSemaphoreAcquire(vision_semHandleHandle, 0);
    uint32_t last_tick = osKernelGetTickCount();

    while (true) {
        // 死等信号量（最多等100ms）
        osStatus_t status = osSemaphoreAcquire(vision_semHandleHandle, pdMS_TO_TICKS(100));

        if (status == osOK) {
            // 收到新帧，瞬间苏醒
            // 屏蔽中断，防止拷贝到一半时被 DMA 串口覆盖
            taskENTER_CRITICAL();
            MotorCmd local_cmd = current_cmd;
            taskEXIT_CRITICAL();

            uint32_t current_tick = osKernelGetTickCount();
            float dt = (current_tick - last_tick) / 1000.0f;
            last_tick = current_tick;

            // 防止极端卡顿导致积分爆炸
            if (dt <= 0.001f || dt > 0.1f) dt = 0.01f;

            // 视觉追踪逻辑
            switch (local_cmd.cmd_type) {
                case CMD_ANGLE:
                    enable_stabilizer();
                    if (local_cmd.param1 >= -320 && local_cmd.param1 <= 320 &&
                        local_cmd.param2 >= -240 && local_cmd.param2 <= 240) {

                        float yaw_error = static_cast<float>(local_cmd.param1);
                        yaw_speed_vision = PID_yaw.calc_error_dynamic(yaw_error, dt);

                        float pitch_error = static_cast<float>(local_cmd.param2);
                        pitch_speed_vision = PID_pitch.calc_error_dynamic(pitch_error, dt);

                    } else {
                        yaw_speed_vision = 0.0f;
                        pitch_speed_vision = 0.0f;
                    }
                    break;

                case CMD_STOP:
                case CMD_NONE:

                    yaw_speed_vision = 0.0f;
                    pitch_speed_vision = 0.0f;
                    PitchMotor.setSpeed(0);
                    break;

                case CMD_SPEED:
                    enable_stabilizer();
                    yaw_speed_vision = static_cast<float>(local_cmd.param1);
                    pitch_speed_vision = 0.0f; // 速度控制模式下，Pitch锁死在中心
                    PitchMotor.setAngle(pitch_center);
                    break;
            }
        } else {
            // 超时保护(超过 100ms 没收到数据)

            yaw_speed_vision = 0.0f;
            pitch_speed_vision = 0.0f;
            PitchMotor.setSpeed(0);
        }
    }
}