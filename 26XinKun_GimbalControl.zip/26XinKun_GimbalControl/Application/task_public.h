#ifndef TASK_PUBLIC_H
#define TASK_PUBLIC_H

#ifdef __cplusplus
extern "C" {
#endif



//任务句柄和任务函数声明
void DebugTask(void *argument);
void StartVisionTask_Entry(void *argument);

#ifdef __cplusplus
};
#endif

#endif //TASK_PUBLIC_H

