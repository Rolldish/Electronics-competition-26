#include "usart.h"
#include "IMU.h"
#include "cmd_protocol.h"
#include "cmsis_os.h"

extern "C" {

}

extern osSemaphoreId_t vision_semHandleHandle;
MotorCmd commUARTBuffer;
extern void commUARTCallback(const MotorCmd* cmd);

// 定义一个数组，用来成批接收IMU数据（如33字节，足够装3帧数据）
#define IMU_CHUNK_SIZE 33
uint8_t IMU_RxChunkBuffer[IMU_CHUNK_SIZE];

// 空闲中断回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if(huart->Instance == huart6.Instance)
    {
        if(Size == sizeof(MotorCmd)) {
            if(is_cmd_valid(commUARTBuffer)) {
                commUARTCallback(&commUARTBuffer);
                if (vision_semHandleHandle != NULL) {
                    osSemaphoreRelease(vision_semHandleHandle);
                }
            }
        }
        HAL_UARTEx_ReceiveToIdle_DMA(&huart6, (uint8_t*)&commUARTBuffer, sizeof(MotorCmd));
    }
    else if(huart->Instance == huart1.Instance)
    {
        // DMA已经把数据自动搬运到了IMU_RxChunkBuffer中，Size是本次实际接收到的字节数
        // 极快的for循环把数据给状态机解析
        for(uint16_t i = 0; i < Size; i++) {
            IMU_PutByte(IMU_RxChunkBuffer[i]);
        }

        // 重新开启DMA空闲接收
        HAL_UARTEx_ReceiveToIdle_DMA(&huart1, IMU_RxChunkBuffer, IMU_CHUNK_SIZE);
    }
}

// 串口硬件错误抢救回调函数
extern "C" void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
    // 强行清除溢出(ORE)和帧错误(FE)的底层寄存器标志位
    __HAL_UART_CLEAR_OREFLAG(huart);
    __HAL_UART_CLEAR_FEFLAG(huart);

    // 针对上位机视觉串口抢救
    if (huart->Instance == huart6.Instance) {
        HAL_UART_AbortReceive(&huart6);
        HAL_UARTEx_ReceiveToIdle_DMA(&huart6, (uint8_t*)&commUARTBuffer, sizeof(MotorCmd));
    }
    // 针对IMU串口抢救
    else if (huart->Instance == huart1.Instance) {
        HAL_UART_AbortReceive(&huart1);
        HAL_UARTEx_ReceiveToIdle_DMA(&huart1, IMU_RxChunkBuffer, IMU_CHUNK_SIZE);
    }
}