"use strict";

// The node prepares status at 10 Hz. Two browser polls per second are enough
// for field supervision and reduce HTTP/JSON work while vision has priority.
const STATUS_INTERVAL_MS = 500;
// Match the raw 8080 MJPEG stream. Recording is encoded by the PAD/browser,
// not by the Raspberry Pi vision process.
const VIDEO_FPS = 20;
const RUN_ACTIVE = 0x02;
const BALL_VALID = 0x01;
const CAMERA_CALIBRATED = 0x04;
const PROCESSING_DEGRADED = 0x08;
const BALL_CONFIDENCE_MIN = 180 / 255;
const MEASUREMENT_MAX_AGE_MS = 77;
const DB_NAME = "hball-receiver";
const DB_VERSION = 1;
const STORE_NAME = "recordings";

const TASK_NAMES = {
  0: "空闲监视",
  2: "T2 · O点静止保持",
  3: "T3 · +5 cm 到 -5 cm",
  4: "T4 · A-B期间保持O点",
  5: "T5 · 整圈保持O点",
  6: "T6 · 整圈保持指定位置",
};

const PHASE_NAMES = {
  IDLE: "空闲",
  WAIT_TRACK: "等待跟踪",
  PREPARE: "就位准备",
  READY: "等待启动",
  HOLD: "保持中",
  TO_POSITIVE: "前往 +5 cm",
  TO_NEGATIVE: "返回 -5 cm",
  DONE: "任务完成",
  TIMEOUT: "任务超时",
};

const SETUP_NAMES = {
  CAMERA: "选择现场相机参数",
  BACKGROUND: "采集空轨背景",
  EMPTY_CHECK: "确认空轨无误检",
  PLACE_BALL: "请放置钢球",
  PASSED: "赛前检查通过",
  FAILED: "赛前检查失败",
};

const TASK_RECORD_SECONDS = {
  2: 25,
  3: 8,
  4: 12,
  5: 35,
  6: 35,
};

const byId = (id) => document.getElementById(id);
const liveFeed = byId("live-feed");
const recordCanvas = byId("record-canvas");
const recordContext = recordCanvas.getContext("2d", { alpha: false });

let latestStatus = null;
let lastStatusAt = 0;
let statusRequestRunning = false;
let videoRetryTimer = null;
let competitionEnabled = false;
let wakeLock = null;
let drawTimer = null;
let mediaRecorder = null;
let mediaChunks = [];
let mediaMeta = null;
let mediaStartedAt = 0;
let mediaStopTimer = null;
let saveOnStop = false;
let replayRecord = null;
let replayUrl = null;

function number(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function formatSigned(value, digits = 2) {
  if (!Number.isFinite(value)) {
    return "--";
  }
  return `${value >= 0 ? "+" : ""}${value.toFixed(digits)}`;
}

function formatClock(seconds) {
  const safe = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(safe / 60);
  const remainder = safe % 60;
  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function setConnection(mode, text) {
  const pill = byId("connection-pill");
  pill.classList.remove("online", "offline");
  if (mode) {
    pill.classList.add(mode);
  }
  byId("connection-text").textContent = text;
}

function setFlag(id, label, good) {
  const element = byId(id);
  element.textContent = label;
  element.classList.remove("good", "bad", "warning");
  if (good === true) {
    element.classList.add("good");
  } else if (good === false) {
    element.classList.add("bad");
  } else if (good === "warning") {
    element.classList.add("warning");
  }
}

function setConfidence(id, barId, value) {
  const safe = Math.max(0, Math.min(1, number(value)));
  byId(id).textContent = safe.toFixed(2);
  const bar = byId(barId);
  if (bar) {
    bar.style.width = `${Math.round(safe * 100)}%`;
  }
}

function setReadiness(tone, title, code, reason) {
  const banner = byId("readiness-banner");
  banner.classList.remove("ready", "waiting", "bad");
  banner.classList.add(tone);
  byId("readiness-title").textContent = title;
  byId("readiness-code").textContent = code;
  byId("gate-reason").textContent = reason;
}

function setMeasurementChip(tone, text) {
  const chip = byId("measurement-chip");
  chip.classList.remove("valid", "waiting", "warning", "invalid");
  chip.classList.add(tone);
  chip.textContent = text;
}

function positionToLeftPercent(positionM) {
  const clamped = Math.max(-0.125, Math.min(0.125, number(positionM)));
  return ((0.125 - clamped) / 0.25) * 100;
}

function updateCoordinate(status, measurementValid) {
  const ball = byId("ball-marker");
  const target = byId("target-marker");
  const taskId = number(status.task_id);
  const xM = number(status.x_m);
  const targetM = number(status.target_x_m);

  if (measurementValid && !status.predicted) {
    ball.hidden = false;
    ball.style.left = `${positionToLeftPercent(xM)}%`;
    byId("coordinate-caption").textContent =
      `x = ${formatSigned(xM * 100)} cm`;
  } else {
    ball.hidden = true;
    byId("coordinate-caption").textContent = status.jump_quarantined
      ? "跳变复核中"
      : "等待真实钢球";
  }

  if (taskId >= 2 && taskId <= 6) {
    target.hidden = false;
    target.style.left = `${positionToLeftPercent(targetM)}%`;
  } else {
    target.hidden = true;
  }
}

function updateSetupProgress(status) {
  const strip = byId("setup-strip");
  let label = "";
  let current = 0;
  let required = 0;

  if (!status.registered_background_ready) {
    label = status.registered_background_failed
      ? "空轨背景失败"
      : "空轨背景";
    current = number(status.registered_background_frames);
    required = Math.max(1, number(status.registered_background_required, 30));
  } else if (String(status.node_mode) === "SETUP") {
    const phase = String(status.setup_phase || "");
    if (phase === "EMPTY_CHECK") {
      label = "空轨连续确认";
      current = number(status.setup_empty_consecutive);
      required = Math.max(1, number(status.setup_empty_required, 20));
    } else if (phase === "PLACE_BALL") {
      label = "钢球连续有效";
      current = number(status.setup_ball_consecutive);
      required = Math.max(1, number(status.setup_ball_required, 10));
    }
  }

  if (!label) {
    strip.hidden = true;
    return;
  }
  strip.hidden = false;
  byId("setup-label").textContent = label;
  byId("setup-count").textContent = `${current} / ${required}`;
  byId("setup-progress").style.width =
    `${Math.min(100, (current / required) * 100)}%`;
}

function updateAdmission(status, measurementValid, sendAgeMs) {
  const cameraFps = number(status.camera_fps);
  const detectFps = number(status.detection_fps);
  const confidence = number(status.confidence);
  const backgroundReady = Boolean(status.registered_background_ready);
  const backgroundFailed = Boolean(status.registered_background_failed);
  const calibrated = Boolean(status.calibration_ready);
  const serialOpen = Boolean(status.uart_tx_open);
  const realtimeReady = Boolean(status.control_realtime_ready);

  if (backgroundFailed || String(status.setup_phase) === "FAILED") {
    setReadiness(
      "bad",
      "赛前条件未通过",
      "STOP",
      status.setup_error || "空轨背景建立失败：移走钢球，检查绿色导轨和现场光线后重试。",
    );
  } else if (!backgroundReady || !calibrated) {
    setReadiness(
      "waiting",
      "正在建立空轨基准",
      "WAIT",
      "必须移走钢球并保持轨道、相机和光线静止，完成背景后才能发送有效测量。",
    );
  } else if (!serialOpen) {
    setReadiness(
      "bad",
      "Pi→C板串口未打开",
      "STOP",
      "视觉可继续检查，但当前不能把有效位置送到C板。",
    );
  } else if (cameraFps < 50) {
    setReadiness(
      "bad",
      "相机帧率不足",
      "STOP",
      `当前 ${cameraFps.toFixed(1)} FPS，低于上机要求 50 FPS。`,
    );
  } else if (detectFps < 30) {
    setReadiness(
      "bad",
      "识别更新不足",
      "STOP",
      `当前 ${detectFps.toFixed(1)} FPS，可能造成测量过期；先减少负载并检查温度、供电。`,
    );
  } else if (!measurementValid) {
    const reason = status.jump_quarantined
      ? "检测到坐标跳变，正在等待下一张真实图像复核。"
      : (confidence < BALL_CONFIDENCE_MIN
        ? `钢球置信度 ${confidence.toFixed(2)}，未达到 180/255。`
        : "当前没有真实有效钢球测量；检查遮挡、阴影和钢球是否位于导轨内。");
    setReadiness("waiting", "等待有效钢球", "WAIT", reason);
  } else if (!Number.isFinite(sendAgeMs)) {
    setReadiness(
      "waiting",
      "等待 BallLink 时龄",
      "WAIT",
      "已经识别到钢球，正在等待最终串口打包字段。",
    );
  } else if (sendAgeMs > MEASUREMENT_MAX_AGE_MS) {
    setReadiness(
      "bad",
      "测量发送已过期",
      "STOP",
      `最终发送时龄 ${sendAgeMs.toFixed(1)} ms，超过 77 ms 安全线。`,
    );
  } else if (!realtimeReady) {
    setReadiness(
      "waiting",
      "实时余量不足",
      "HOLD",
      "测量仍在安全时限内，但处理余量不足；图传会自动降帧保护视觉。",
    );
  } else {
    setReadiness(
      "ready",
      "Pi视觉发送条件满足",
      "READY",
      "真实钢球、轨道、帧率、时龄和串口均满足；再以C板接收状态确认闭环准入。",
    );
  }
}

function taskHint(status) {
  if (String(status.node_mode) === "SETUP") {
    const setupPhase = String(status.setup_phase || "");
    const setupHints = {
      CAMERA: "移走钢球、轨道水平，正在选择当前场地的相机参数。",
      BACKGROUND: "保持空轨、相机和光线静止，正在建立运行背景。",
      EMPTY_CHECK: "继续保持空轨，确认没有钢球误检。",
      PLACE_BALL: "现在把钢球放到导轨上，等待连续10张真实有效测量。",
      PASSED: "赛前检查已经通过，可进入 BALL CHECK 或正式任务。",
      FAILED: status.setup_error || "赛前检查失败，请按提示处理后重试。",
    };
    return setupHints[setupPhase] || "正在执行赛前一键检查。";
  }
  const phase = String(status.task_phase || "IDLE");
  const taskId = number(status.task_id);
  if (taskId === 0) {
    return "在树莓派 OLED 选择 T2-T6；接收端只监视和录像，不发送控制命令。";
  }
  if (phase === "HOLD") {
    const holdHints = {
      2: "T2 O点静止保持进行中：重点观察位置误差、有效测量连续性和是否出现超时。",
      4: "T4 A-B时间段保持O点：无线端持续录像，不参与小车运动控制。",
      5: "T5 小车整圈运动中保持O点：重点观察阴影变化下钢球是否连续有效。",
      6: "T6 小车整圈运动中保持指定点：目标标记显示在画面下方坐标尺。",
    };
    return holdHints[taskId] || "正式测试进行中，保持页面前台并观察闭环准入状态。";
  }
  const hints = {
    WAIT_TRACK: "等待有效钢球和轨道位置，请先检查校准与画面。",
    PREPARE: "C板正在把钢球送到目标位置，录像已经提前准备。",
    READY: "钢球已稳定。短按 OLED START 后，接收端将自动标记正式测试。",
    HOLD: "正式测试进行中，保持页面前台，录像将在设定窗口后自动保存。",
    TO_POSITIVE: "T3正在前往 +5 cm，正式录像中。",
    TO_NEGATIVE: "T3正在折返 -5 cm，正式录像中。",
    DONE: "任务动作完成，录像将按对应测评窗口自动封存。",
    TIMEOUT: "任务超时，保留本次录像和状态用于复盘。",
  };
  return hints[phase] || `当前阶段：${phase}`;
}

function updateStatus(status) {
  latestStatus = status;
  lastStatusAt = Date.now();
  setConnection("online", "树莓派在线");
  byId("last-update").textContent = "刚刚更新";
  byId("video-message").classList.add("ready");

  const taskId = number(status.task_id);
  const setupMode = String(status.node_mode) === "SETUP";
  const taskName = setupMode
    ? "赛前一键检查"
    : (TASK_NAMES[taskId] || `任务 ${taskId}`);
  const phase = String(status.task_phase || status.state || "IDLE");
  const phaseLabel = setupMode
    ? (SETUP_NAMES[String(status.setup_phase)] || "赛前检查")
    : (PHASE_NAMES[phase] || phase);
  const xCm = number(status.x_m) * 100;
  const targetCm = number(status.target_x_m) * 100;
  const speedCm = number(status.v_mps) * 100;
  const errorValue = status.task_error_m;
  const errorCm = errorValue === null || errorValue === undefined
    ? NaN
    : number(errorValue) * 100;
  const measurementValid = Boolean(
    status.control_measurement_valid
    ?? (
      status.measurement_valid
      && status.calibration_ready
      && !status.predicted
      && number(status.confidence) >= BALL_CONFIDENCE_MIN
    )
  );
  const rawDelayValue = status.telemetry_capture_to_send_delay_us;
  const rawDelayUs = rawDelayValue === null || rawDelayValue === undefined
    ? NaN
    : Number(rawDelayValue);
  const sendAgeMs = Number.isFinite(rawDelayUs) ? rawDelayUs / 1000 : NaN;
  const visionFlags = number(status.telemetry_vision_flags);
  const controlFlags = number(
    status.telemetry_control_flags ?? status.control_flags,
  );

  byId("task-badge").textContent = setupMode
    ? "CHECK"
    : (taskId === 0 ? "IDLE" : `T${taskId}`);
  byId("run-label").textContent = phaseLabel;
  byId("task-title").textContent = taskName;
  byId("phase-chip").textContent = phaseLabel;
  byId("task-time").textContent = `${number(status.task_elapsed_s).toFixed(2)} s`;
  byId("task-error").textContent = `${formatSigned(errorCm)} cm`;
  byId("run-id").textContent = String(status.run_id ?? "----");
  byId("task-hint").textContent = taskHint(status);
  byId("overlay-position").textContent = measurementValid
    ? `${formatSigned(xCm)} cm`
    : "--.-- cm";
  byId("overlay-target").textContent = `${formatSigned(targetCm)} cm`;
  byId("overlay-speed").textContent = measurementValid
    ? `${formatSigned(speedCm)} cm/s`
    : "--.-- cm/s";

  byId("camera-fps").textContent = `${number(status.camera_fps).toFixed(1)} FPS`;
  byId("detection-fps").textContent =
    `${number(status.detection_fps).toFixed(1)} FPS`;
  byId("processing-ms").textContent =
    `${number(status.processing_ewma_ms).toFixed(1)} ms`;
  byId("video-fps").textContent =
    `${number(status.video_effective_fps).toFixed(0)} FPS`;
  byId("measurement-age").textContent = Number.isFinite(sendAgeMs)
    ? `${sendAgeMs.toFixed(1)} ms`
    : "-- ms";
  byId("measurement-state").textContent = measurementValid
    ? "有效"
    : (status.predicted ? "仅预测" : "无效");
  byId("acquisition-state").textContent =
    `连续 ${number(status.acquisition_frames)} / ${Math.max(
      1,
      number(status.acquisition_required, 3),
    )}`;

  setConfidence("ball-confidence", "ball-confidence-bar", status.confidence);
  byId("rail-confidence").textContent =
    number(status.tube_pose_confidence).toFixed(2);

  setFlag(
    "flag-background",
    status.registered_background_ready
      ? "背景 OK"
      : (status.registered_background_failed ? "背景失败" : "背景采集中"),
    status.registered_background_ready
      ? true
      : (status.registered_background_failed ? false : "warning"),
  );
  setFlag(
    "flag-rail",
    status.tube_pose_valid ? "轨道有效" : "轨道无效",
    Boolean(status.tube_pose_valid),
  );
  setFlag(
    "flag-ball",
    status.jump_quarantined
      ? "跳变复核"
      : (measurementValid ? "钢球有效" : "钢球无效"),
    status.jump_quarantined ? "warning" : measurementValid,
  );
  setFlag(
    "flag-uart",
    status.uart_tx_open ? "Pi发送正常" : "Pi串口断开",
    Boolean(status.uart_tx_open),
  );
  const processMs = number(status.processing_ewma_ms);
  const detectFps = number(status.detection_fps);
  setFlag(
    "flag-delay",
    status.control_realtime_ready
      ? "实时性 OK"
      : `${detectFps.toFixed(0)}fps / ${processMs.toFixed(0)}ms`,
    status.control_realtime_ready
      ? true
      : (
        detectFps < 30
        || (Number.isFinite(sendAgeMs) && sendAgeMs > MEASUREMENT_MAX_AGE_MS)
          ? false
          : "warning"
      ),
  );

  const ballFlag = Boolean(visionFlags & BALL_VALID);
  const calibratedFlag = Boolean(visionFlags & CAMERA_CALIBRATED);
  const degradedFlag = Boolean(visionFlags & PROCESSING_DEGRADED);
  byId("wire-flags").textContent =
    `V=0x${visionFlags.toString(16).padStart(2, "0").toUpperCase()} `
    + `C=0x${controlFlags.toString(16).padStart(2, "0").toUpperCase()}`;
  byId("wire-value").textContent =
    `x ${status.telemetry_x_0p1mm ?? "--"} / v ${status.telemetry_v_mmps ?? "--"}`;

  if (measurementValid && !status.predicted && !degradedFlag) {
    setMeasurementChip("valid", "真实测量有效");
  } else if (status.jump_quarantined || status.predicted) {
    setMeasurementChip(
      "warning",
      status.jump_quarantined ? "跳变复核" : "仅跟踪预测",
    );
  } else if (ballFlag && calibratedFlag) {
    setMeasurementChip("warning", "发送条件复核");
  } else {
    setMeasurementChip("invalid", "无有效钢球");
  }

  updateCoordinate(status, measurementValid);
  updateSetupProgress(status);
  updateAdmission(status, measurementValid, sendAgeMs);
  reconcileAutomaticRecording(status);
}

async function pollStatus() {
  if (statusRequestRunning) {
    return;
  }
  statusRequestRunning = true;
  try {
    const response = await fetch(`/status.json?t=${Date.now()}`, {
      cache: "no-store",
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    updateStatus(await response.json());
  } catch (error) {
    if (Date.now() - lastStatusAt > 2000) {
      setConnection("offline", "连接中断");
      byId("last-update").textContent = "状态连接中断";
      byId("video-message").classList.remove("ready");
      byId("video-message").textContent = "正在重新连接树莓派";
    }
  } finally {
    statusRequestRunning = false;
  }
}

function scheduleVideoReconnect() {
  if (videoRetryTimer !== null) {
    return;
  }
  byId("video-message").classList.remove("ready");
  byId("video-message").textContent = "视频中断，正在重连";
  videoRetryTimer = window.setTimeout(() => {
    videoRetryTimer = null;
    liveFeed.src = `/stream.mjpg?reconnect=${Date.now()}`;
  }, 1000);
}

function beginCanvasDrawing() {
  if (drawTimer !== null) {
    return;
  }
  drawTimer = window.setInterval(() => {
    if (!liveFeed.naturalWidth || !liveFeed.naturalHeight) {
      return;
    }
    try {
      recordContext.drawImage(liveFeed, 0, 0, 640, 480);
    } catch (error) {
      // A reconnect can briefly leave the image without a drawable frame.
    }
  }, 1000 / VIDEO_FPS);
}

function endCanvasDrawing() {
  if (drawTimer !== null) {
    window.clearInterval(drawTimer);
    drawTimer = null;
  }
}

function recorderSupported() {
  return Boolean(
    window.MediaRecorder
    && recordCanvas.captureStream
    && window.indexedDB,
  );
}

function chooseMimeType() {
  const isAppleTablet =
    /iPad|iPhone|iPod/.test(navigator.userAgent)
    || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const apple = [
    "video/mp4;codecs=avc1.42E01E",
    "video/mp4",
    "video/webm;codecs=vp8",
    "video/webm",
  ];
  const android = [
    "video/webm;codecs=vp8",
    "video/webm",
    "video/mp4;codecs=avc1.42E01E",
    "video/mp4",
  ];
  const candidates = isAppleTablet ? apple : android;
  return candidates.find((value) => MediaRecorder.isTypeSupported(value)) || "";
}

function recordingState(text, warning = false) {
  const state = byId("recording-state");
  state.textContent = text;
  state.style.background = warning
    ? "rgba(255, 102, 122, 0.10)"
    : "";
  state.style.color = warning ? "#ff9cab" : "";
}

function setRecorderButtons(active) {
  byId("manual-record").disabled = active;
  byId("stop-record").disabled = !active;
  byId("record-indicator").hidden = !active;
}

function currentRecordElapsed() {
  return mediaStartedAt ? (Date.now() - mediaStartedAt) / 1000 : 0;
}

function startRecording(meta) {
  if (mediaRecorder || !recorderSupported()) {
    return false;
  }
  beginCanvasDrawing();
  const stream = recordCanvas.captureStream(VIDEO_FPS);
  const mimeType = chooseMimeType();
  const options = { videoBitsPerSecond: 2_500_000 };
  if (mimeType) {
    options.mimeType = mimeType;
  }
  try {
    mediaRecorder = new MediaRecorder(stream, options);
  } catch (error) {
    recordingState(`浏览器无法启动录像：${error.message}`, true);
    mediaRecorder = null;
    endCanvasDrawing();
    return false;
  }

  mediaChunks = [];
  mediaMeta = {
    ...meta,
    preparedAt: new Date().toISOString(),
    officialStartedAt: null,
  };
  mediaStartedAt = Date.now();
  saveOnStop = false;
  mediaRecorder.ondataavailable = (event) => {
    if (event.data && event.data.size > 0) {
      mediaChunks.push(event.data);
    }
  };
  mediaRecorder.onerror = (event) => {
    recordingState(`录像错误：${event.error?.message || "未知错误"}`, true);
  };
  mediaRecorder.onstop = finalizeStoppedRecording;
  mediaRecorder.start(1000);
  setRecorderButtons(true);
  recordingState(
    meta.mode === "auto"
      ? `${meta.taskName} 已开始提前录像，等待 OLED START。`
      : "手动录像进行中，保持页面前台。",
  );
  return true;
}

async function finalizeStoppedRecording() {
  const chunks = mediaChunks;
  const meta = mediaMeta;
  const shouldSave = saveOnStop;
  const duration = currentRecordElapsed();
  const mimeType = mediaRecorder?.mimeType || chunks[0]?.type || "video/webm";

  mediaRecorder = null;
  mediaChunks = [];
  mediaMeta = null;
  mediaStartedAt = 0;
  saveOnStop = false;
  if (mediaStopTimer !== null) {
    clearTimeout(mediaStopTimer);
    mediaStopTimer = null;
  }
  setRecorderButtons(false);
  endCanvasDrawing();

  if (!shouldSave || !chunks.length || !meta) {
    recordingState(
      competitionEnabled
        ? "自动录像已就绪，等待下一项任务。"
        : "录像未保存。",
    );
    return;
  }

  const blob = new Blob(chunks, { type: mimeType });
  const record = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    createdAt: new Date().toISOString(),
    duration,
    size: blob.size,
    mimeType,
    taskId: number(meta.taskId),
    taskName: meta.taskName || "手动录像",
    runId: meta.runId ?? null,
    officialStartedAt: meta.officialStartedAt,
    mode: meta.mode,
    blob,
  };
  try {
    await saveRecord(record);
    recordingState(
      `${record.taskName} 已保存在本设备，可立即回放或下载。`,
    );
    await renderRecordings();
  } catch (error) {
    recordingState(`录像保存失败：${error.message}`, true);
  }
}

function stopRecording(save, reason = "") {
  if (!mediaRecorder) {
    return;
  }
  saveOnStop = save;
  if (mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
  }
  if (reason) {
    recordingState(reason);
  }
}

function markOfficialRun(status) {
  if (!mediaRecorder || !mediaMeta || mediaMeta.officialStartedAt) {
    return;
  }
  mediaMeta.officialStartedAt = new Date().toISOString();
  mediaMeta.runId = status.run_id;
  const taskId = number(status.task_id);
  const fullWindow = TASK_RECORD_SECONDS[taskId] || 35;
  const elapsed = Math.max(0, number(status.task_elapsed_s));
  const remainingMs = Math.max(1000, (fullWindow - elapsed) * 1000);
  if (mediaStopTimer !== null) {
    clearTimeout(mediaStopTimer);
  }
  mediaStopTimer = window.setTimeout(() => {
    stopRecording(true, "任务录像窗口结束，正在保存到本设备。");
  }, remainingMs);
  recordingState(
    `${TASK_NAMES[taskId]} 正式录像中，将在约${Math.ceil(remainingMs / 1000)}秒后保存。`,
  );
}

function reconcileAutomaticRecording(status) {
  if (!competitionEnabled || !recorderSupported()) {
    return;
  }
  const taskId = number(status.task_id);
  const runId = status.run_id;
  const phase = String(status.task_phase || "");
  const runActive = Boolean(number(status.control_flags) & RUN_ACTIVE);
  const formalTask = Object.prototype.hasOwnProperty.call(
    TASK_RECORD_SECONDS,
    taskId,
  );

  if (formalTask && !mediaRecorder) {
    startRecording({
      mode: "auto",
      taskId,
      taskName: TASK_NAMES[taskId],
      runId,
      phase,
    });
  }

  if (
    mediaRecorder
    && mediaMeta?.mode === "auto"
    && (number(mediaMeta.taskId) !== taskId || mediaMeta.runId !== runId)
  ) {
    stopRecording(
      Boolean(mediaMeta.officialStartedAt),
      mediaMeta.officialStartedAt
        ? "任务已退出，正在提前封存录像。"
        : "任务未开始，丢弃本次准备录像。",
    );
    return;
  }

  if (mediaMeta?.mode === "auto" && formalTask && runActive) {
    markOfficialRun(status);
  }
}

function requestWakeLock() {
  if (!("wakeLock" in navigator)) {
    return Promise.resolve(false);
  }
  return navigator.wakeLock.request("screen")
    .then((lock) => {
      wakeLock = lock;
      lock.addEventListener("release", () => {
        wakeLock = null;
      });
      return true;
    })
    .catch(() => false);
}

async function enableCompetitionMode() {
  competitionEnabled = true;
  if (navigator.storage?.persist) {
    try {
      await navigator.storage.persist();
    } catch (error) {
      // Persistent storage is a best-effort browser feature.
    }
  }
  const wake = await requestWakeLock();
  byId("competition-mode").textContent = wake
    ? "比赛模式已启用"
    : "比赛模式已启用 · 请保持亮屏";
  byId("competition-mode").disabled = true;
  if (recorderSupported()) {
    recordingState("自动录像已就绪：选择T2-T6后会提前录像，OLED START后正式计时。");
    if (latestStatus) {
      reconcileAutomaticRecording(latestStatus);
    }
  } else {
    recordingState(
      "当前浏览器不支持网页录像；实时显示可用，请改用OPPO Pad Chrome或笔记本录像。",
      true,
    );
  }
}

async function toggleFullscreen() {
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else if (document.documentElement.requestFullscreen) {
      await document.documentElement.requestFullscreen();
    }
  } catch (error) {
    recordingState("浏览器拒绝全屏，请使用系统手势隐藏工具栏。", true);
  }
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function withStore(mode, callback) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    let result;
    try {
      result = callback(store);
    } catch (error) {
      db.close();
      reject(error);
      return;
    }
    transaction.oncomplete = () => {
      db.close();
      resolve(result);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error);
    };
  });
}

async function listRecords() {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, "readonly");
    const request = transaction.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => {
      const records = request.result.sort(
        (left, right) => right.createdAt.localeCompare(left.createdAt),
      );
      db.close();
      resolve(records);
    };
    request.onerror = () => {
      db.close();
      reject(request.error);
    };
  });
}

async function saveRecord(record) {
  await withStore("readwrite", (store) => store.put(record));
}

async function deleteRecord(id) {
  await withStore("readwrite", (store) => store.delete(id));
}

function recordSubtitle(record) {
  const time = new Date(record.createdAt).toLocaleString("zh-CN", {
    hour12: false,
  });
  const mebibytes = record.size / (1024 * 1024);
  return `${time} · ${record.duration.toFixed(1)}s · ${mebibytes.toFixed(1)}MB`;
}

async function renderRecordings() {
  const container = byId("record-list");
  let records = [];
  try {
    records = await listRecords();
  } catch (error) {
    container.textContent = "无法读取浏览器录像存储";
    return;
  }
  container.replaceChildren();
  if (!records.length) {
    const empty = document.createElement("div");
    empty.className = "empty-records";
    empty.textContent = "还没有保存录像";
    container.append(empty);
    return;
  }
  records.forEach((record) => {
    const row = document.createElement("div");
    row.className = "record-row";
    const text = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = record.taskName;
    const subtitle = document.createElement("span");
    subtitle.textContent = recordSubtitle(record);
    text.append(title, subtitle);
    const replay = document.createElement("button");
    replay.textContent = "回放";
    replay.addEventListener("click", () => openReplay(record));
    row.append(text, replay);
    container.append(row);
  });
}

function openReplay(record) {
  replayRecord = record;
  if (replayUrl) {
    URL.revokeObjectURL(replayUrl);
  }
  replayUrl = URL.createObjectURL(record.blob);
  byId("replay-title").textContent = record.taskName;
  byId("replay-video").src = replayUrl;
  const dialog = byId("replay-dialog");
  if (dialog.showModal) {
    dialog.showModal();
  } else {
    dialog.setAttribute("open", "");
  }
}

function closeReplay() {
  const dialog = byId("replay-dialog");
  byId("replay-video").pause();
  byId("replay-video").removeAttribute("src");
  byId("replay-video").load();
  if (dialog.open && dialog.close) {
    dialog.close();
  } else {
    dialog.removeAttribute("open");
  }
  if (replayUrl) {
    URL.revokeObjectURL(replayUrl);
    replayUrl = null;
  }
  replayRecord = null;
}

function downloadRecord(record) {
  const extension = record.mimeType.includes("mp4") ? "mp4" : "webm";
  const timestamp = record.createdAt.replace(/[:.]/g, "-");
  const run = record.runId === null ? "manual" : `run${record.runId}`;
  const task = record.taskId ? `T${record.taskId}` : "MANUAL";
  const link = document.createElement("a");
  const url = URL.createObjectURL(record.blob);
  link.href = url;
  link.download = `HBall_${task}_${run}_${timestamp}.${extension}`;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function updateStorageState() {
  if (!navigator.storage?.estimate) {
    return;
  }
  try {
    const estimate = await navigator.storage.estimate();
    const used = number(estimate.usage) / (1024 * 1024);
    const quota = number(estimate.quota) / (1024 * 1024);
    byId("storage-state").textContent =
      `${used.toFixed(0)} / ${quota.toFixed(0)} MB`;
  } catch (error) {
    // Storage estimate is informational only.
  }
}

function bindEvents() {
  liveFeed.addEventListener("load", () => {
    byId("video-message").classList.add("ready");
  });
  liveFeed.addEventListener("error", scheduleVideoReconnect);
  byId("competition-mode").addEventListener("click", enableCompetitionMode);
  byId("fullscreen").addEventListener("click", toggleFullscreen);
  byId("manual-record").addEventListener("click", () => {
    if (!recorderSupported()) {
      recordingState("当前浏览器不支持网页录像。", true);
      return;
    }
    startRecording({
      mode: "manual",
      taskId: 0,
      taskName: "手动录像",
      runId: null,
    });
  });
  byId("stop-record").addEventListener("click", () => {
    stopRecording(true, "正在封存录像。");
  });
  byId("latest-replay").addEventListener("click", async () => {
    const records = await listRecords();
    if (records.length) {
      openReplay(records[0]);
    } else {
      recordingState("还没有可回放的录像。", true);
    }
  });
  byId("close-replay").addEventListener("click", closeReplay);
  byId("download-replay").addEventListener("click", () => {
    if (replayRecord) {
      downloadRecord(replayRecord);
    }
  });
  byId("delete-replay").addEventListener("click", async () => {
    if (!replayRecord) {
      return;
    }
    const id = replayRecord.id;
    closeReplay();
    await deleteRecord(id);
    await renderRecordings();
    await updateStorageState();
  });
  document.addEventListener("visibilitychange", () => {
    if (
      document.visibilityState === "visible"
      && competitionEnabled
      && !wakeLock
    ) {
      requestWakeLock();
    }
    if (document.visibilityState === "hidden" && mediaRecorder) {
      recordingState("页面已进入后台，部分PAD可能暂停录像；请立即返回前台。", true);
    }
  });
  window.addEventListener("beforeunload", (event) => {
    if (mediaRecorder) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
}

function startClock() {
  const update = () => {
    byId("clock").textContent = new Date().toLocaleTimeString("zh-CN", {
      hour12: false,
    });
    if (mediaRecorder) {
      byId("record-time").textContent = formatClock(currentRecordElapsed());
    }
    if (lastStatusAt) {
      const ageMs = Date.now() - lastStatusAt;
      byId("last-update").textContent = ageMs < 900
        ? "刚刚更新"
        : `${(ageMs / 1000).toFixed(1)} 秒前`;
      if (ageMs > 2000) {
        setConnection("offline", "连接中断");
      }
    }
  };
  update();
  window.setInterval(update, 500);
}

async function initialize() {
  bindEvents();
  startClock();
  if (!recorderSupported()) {
    byId("device-note").textContent =
      "实时显示可用，但此浏览器不支持网页录像；请使用OPPO Pad Chrome或笔记本接收器。";
  }
  await renderRecordings();
  await updateStorageState();
  await pollStatus();
  window.setInterval(pollStatus, STATUS_INTERVAL_MS);
  window.setInterval(updateStorageState, 15000);
}

initialize();
