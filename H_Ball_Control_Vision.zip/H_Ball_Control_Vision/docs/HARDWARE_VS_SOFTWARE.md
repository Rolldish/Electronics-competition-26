# 硬件通用基线与现场软件校准

## HARDWARE_BASELINE：固定底座

这些参数适应大多数环境，比赛现场不能由自动校准改变：

- 相机固定安装位置、焦距和导轨相对几何；
- `/dev/video0`、MJPEG、640×480、60 FPS、4个MMAP缓冲；
- 关闭自动曝光、自动白平衡和动态降帧；
- 通用启动值 E80/G0/WB4500；
- 钢球直径10 mm、导轨全长25 cm、右负左正；
- 绿色导轨ROI几何范围、球半径安全范围；
- BallLink 32字节、115200、50 Hz、CRC、单位及新鲜度门；
- 视觉最低30 FPS、C板置信度180等安全语义。

这里的“硬件基线”仍由软件通过V4L2写入相机，但它是固定安全底座，不是现场搜索结果。

## CURRENT_ENVIRONMENT：当前场地覆盖

`FIELD TUNE`只允许产生三个值：

- `exposure`；
- `gain`；
- `white_balance_temperature`。

结果写入 `calibration/camera_controls.json`，状态JSON显示
`camera_controls.source=CURRENT_ENVIRONMENT`。候选和最终20帧复核都必须通过正式导轨
估计器的检出率、置信度和抖动门，并满足阴影亮度及绿色过曝保护，否则拒绝覆盖。

下列内容也随当前运行自适应，但不写成长期模型：

- 每次启动30帧空轨背景；
- 本次启动的绿色导轨几何和ROI；
- 每帧局部阴影补偿；
- 钢球一维跟踪、速度滤波和跳变隔离。

## 加载优先级

1. `config/pi.toml`提供完整 `HARDWARE_BASELINE`；
2. `load_config()`校验 `camera_controls.json`；
3. 有有效文件时只覆盖E/G/WB，来源标记为 `CURRENT_ENVIRONMENT`；
4. 文件不存在时使用E80/G0/WB4500，来源标记为 `HARDWARE_BASELINE`；
5. 其他模块不得再次读配置文件。

查询当前来源：

```bash
curl -s http://127.0.0.1:8080/status.json | python3 -c '
import json,sys
s=json.load(sys.stdin)
print(s.get("camera_controls"))
'
```
