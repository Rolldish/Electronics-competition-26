# 配置与更新链路

## 唯一入口

所有人工可调参数位于 `config/pi.toml`。所有运行入口先调用 `hball.common.config.load_config()`，得到不可变的 `AppConfig`。

加载顺序只有两步：

1. 读取并校验 `config/pi.toml`；
2. 若 `calibration/camera_controls.json` 存在且有效，用其中的曝光、增益、白平衡覆盖 `[camera]` 的启动预备值。

`runtime_profile.py` 不再读取任何文件，只把已经合并的 `AppConfig` 交给视觉节点。这样修改同一配置后，T2–T6、BALL CHECK、PREFLIGHT、调试和图传看到的是同一组参数。

## 参数归属

- `[camera]`：分辨率、60 FPS、MJPEG和没有输出文件时的相机预备值。
- `[detector]`：阴影补偿、球尺寸、候选门槛。
- `[tracker]`：三帧中值、跳变隔离、短时跟踪参数。
- `[mapping]`：25 cm右负左正物理端点和启动几何预备值。
- `[tube_pose]`：绿色导轨几何与固定安装后的背景锁定。
- `[runtime]`：30帧背景、视觉目标帧率和处理预算。
- `[video]`：20 FPS图传及10 FPS降级。
- `[calibration]`：FIELD TUNE三档候选、正式导轨检测门和最终复核帧数。
- `[preflight]`：上机前校验门槛。
- `[serial]`、`[network]`：BallLink和比赛热点。

## FIELD TUNE 输出

`FIELD TUNE`只写 `calibration/camera_controls.json`，采用临时文件、落盘同步、原子替换和回读校验。面板看到成功退出后会立即重启节点，新节点重新执行 `load_config()`，因此新参数立刻对全工程生效。

当前已验证参数会与三档曝光一起比较。程序优先保持零增益；只有零增益全部不能建立
导轨时才试G4/G8。候选必须由正式 `RailPoseEstimator` 达到检出率、置信度和端点
抖动门槛，最后再用20张新图像复核。失败会恢复原参数并保留原文件。

如果要手动改相机预备值，修改 `[camera]`；如果已有 `camera_controls.json`，它仍会覆盖预备值。要重新选择，直接运行 `FIELD TUNE`，不要在代码里增加第二份候选表。

## 现场预备项

默认曝光是亮场E64、正常E88、暗场E120，另始终保留当前已保存值参与比较；本包初值为E80/G0/WB4500，白平衡为4000/4500/5000。不要现场随意扩成几十组，候选越多越慢，也越容易被短暂阴影误导。

PREFLIGHT 的默认要求：相机不低于50 FPS，识别不低于30 FPS，P95处理不超过40 ms，空轨误检率不超过2%，导轨置信度不低于0.45，并检查串口和热点。

## 实时调度

`[runtime]`集中管理状态刷新率、旧帧丢弃年龄、Python线程切换间隔和周期GC。
`[video]`的 `full_rate_*` 是20 FPS图传恢复门槛，不是C板安全门：只有视觉链有明确
余量时才允许全速图传，临界状态始终优先控制。

系统层由 `deploy/prepare_realtime.sh` 设置CPU performance governor并关闭USB自动
休眠；systemd服务以较高CPU权重和负nice运行。PREFLIGHT会验证这些条件，防止降频、
温度或欠压被误判成算法问题。
