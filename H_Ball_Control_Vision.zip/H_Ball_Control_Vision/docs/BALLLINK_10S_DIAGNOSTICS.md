# BallLink 10秒累计诊断

正式比赛的INFO级别不执行累计诊断。只有定位问题时才临时使用DEBUG级别，
BallLink发送线程每10秒输出一条汇总；比赛任务不要这样启动：

```bash
python3 -m hball.threads.node --task t3 --log-level DEBUG
```

统计基于最终编码并成功写入UART的 `Telemetry` 字段。`unique_capture_frames` 只在
`capture_timestamp_ms` 改变时增加；同一图像的50 Hz重复广播计入
`repeated_capture_frames`。70–200 ms 的旧快照仍按50 Hz发送诚实的无效降级心跳，
计入 `stale_invalid_heartbeat_frames`；超过 C 板合法字段范围的200 ms后才暂停，
并计入 `stale_pause_count`。两种情况都不会发送旧位置或伪造时间戳。

Pi端诊断使用与C板一致的有效条件：控制已使能、球有效、相机已标定、未降级、
置信度至少180、采集到发送延迟加约3 ms串口余量不超过80 ms；Pi因此只在
`delay_us<=70000` 时保留测量有效标志。`vision_flags=0x05`和`0x07`都可满足
位置测量条件；只有速度有效位存在时C板才能使用速度字段。

重点判断：

- `unique_capture_frames / 10 >= 20`：视觉更新频率达到建议值；
- `max_valid_measurement_gap_ms < 80`：相邻有效新测量没有跨过C板门限；
- `current_valid_measurement_age_ms` 持续增大：当前正处于有效测量断流；
- `ball_invalid_frames` 高：检测或跟踪未形成当前测量；
- `camera_uncalibrated_frames` 高：标定或运行背景未就绪；
- `processing_degraded_frames` 高：轨道姿态或处理状态无效；
- `low_confidence_frames` 高：最终协议置信度低于180；
- `stale_invalid_heartbeat_frames` 非零：出现70–200 ms短时陈旧，通信仍在但测量不会更新；
- `stale_pause_count` 非零：旧快照超过200 ms，视觉线程曾长时间停更；
- `delay_over_77ms_frames` 非零：可与上述两项结合判断陈旧程度；
- `session_change_count`、单次任务中的 `run_change_count` 必须为0。

`max_gap_from`和`max_gap_to`给出本窗口最大有效测量间隔两端的采集时间、延迟、
置信度、视觉标志、位置和速度；它们是最终协议字段，不是检测器中间值。
