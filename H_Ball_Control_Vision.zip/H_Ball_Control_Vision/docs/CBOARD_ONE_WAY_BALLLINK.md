# 树莓派 5B → 大疆 C 板单向 BallLink 通信协议

> 用途：2026 年电赛 H 题“车载平衡滚球运动控制系统”  
> 文档状态：联调定稿  
> 接口方向：仅树莓派发送，C 板只接收  
> 帧协议版本：`0x02`  
> 更新日期：2026-07-30，CH340 USB-TTL 真机验收通过

## 0. 给 C 板同学的结论

请按本文件实现树莓派到 C 板的单向 UART 接口：

1. 树莓派以固定 `50 Hz` 发送一帧完整的“视觉 + 控制目标快照”。
2. C 板只接收，不需要给树莓派回传状态，也不需要逐帧 ACK。
3. 只连接树莓派 TX、C 板 RX 和 GND；C 板 TX 可以不接。
4. C 板根据帧内的 `x`、`v`、`target_x` 和有效标志完成滚球控制。
5. C 板必须独立实现超时保护；不能依赖树莓派发“停机命令”才进入安全状态。

原 BallLink 通用帧头、变长载荷和 CRC 设计保留。原手册中的
`CBOARD_STATUS (TYPE=0x80)`、C 板回传线程和 ACK 全部取消。

## 1. 系统边界和双方分工

### 1.1 树莓派负责

- USB 摄像头采集和钢球识别；
- 将像素坐标换算为管道物理坐标；
- 输出钢球位置 `x`、速度 `v`、置信度和视觉状态；
- 根据 OLED 菜单和测评任务生成目标位置 `target_x`；
- 以固定 `50 Hz` 向 C 板广播完整快照；
- 单独完成低帧率无线视频发送。

树莓派不控制小车底盘，不向 C 板发送底盘循迹、轮速或停车命令。

### 1.2 C 板负责

- 接收并解析树莓派数据；
- 完成滚球 PD、QD4310 位置闭环和自身 IMU 加速度补偿；
- 判断测量是否可用、是否过期；
- 在视觉失效、UART 失联或控制未使能时进入本地安全状态。

### 1.3 笔记本负责

- 接收、显示、录像和回放比赛视频；
- 不参与树莓派到 C 板的实时控制链路。

## 2. 硬件连接

| CH340 USB-TTL | 大疆 C 板 | 方向 |
|---|---|---|
| TX | PG9 / USART6_RX | Pi → C |
| GND | GND | 共地 |

不需要连接：

- USB-TTL RX；
- C 板 PG14 / USART6_TX；
- USB-TTL VCC/3.3V/5V；
- 任何 ACK 或状态回传线。

串口电气和格式：

```text
115200 bit/s
8 data bits
no parity
1 stop bit
no flow control
3.3 V TTL
```

注意：

- 两块板必须共地；
- 不要把树莓派 5 V 接到 C 板串口信号；
- 不要用树莓派 3.3 V 针脚给 C 板供电；
- 两块板分别正常供电，断电后再接线或拆线；
- 树莓派 USB 连接 CH340，正式程序使用稳定路径
  `/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0`。
- `/dev/ttyUSB0` 编号可能随插拔变化，不写入正式配置。
- GPIO14 `/dev/ttyAMA0` 和 `/dev/serial0` 已在 60 秒测试中出现 UART/CRC
  错误，不能作为本项目备用链路。

## 3. 坐标、单位和正方向

管道中心 O 定义为位置零点：

```text
另一端（负） ←──────── 中心 O = 0 ────────→ QD4310 控制端（正）
```

| 量 | 传输类型 | 单位 | 正方向 |
|---|---|---|---|
| 钢球位置 `x` | `int16` | 0.1 mm | 向 QD4310 控制端 |
| 钢球速度 `v` | `int16` | 1 mm/s | 向 QD4310 控制端 |
| 目标位置 `target_x` | `int16` | 0.1 mm | 向 QD4310 控制端 |

示例：

```text
x = +500         表示钢球位于 +50.0 mm
x = -500         表示钢球位于 -50.0 mm
v = +250         表示钢球以 250 mm/s 向正方向运动
target_x = -500  表示控制目标为 -50.0 mm
```

首次联调必须人工把球放在 QD4310 控制端一侧，确认 C 板收到的 `x`
为正数；如果机械定义与上图不一致，只允许在一端统一翻转，不能两端各自猜测。

## 4. 通用帧格式

```text
A5 5A | VERSION | TYPE | SEQUENCE | LENGTH | PAYLOAD | CRC16_LE
```

| 帧偏移 | 长度 | 字段 | 本协议取值 |
|---:|---:|---|---|
| 0 | 1 | `MAGIC0` | `0xA5` |
| 1 | 1 | `MAGIC1` | `0x5A` |
| 2 | 1 | `VERSION` | `0x02` |
| 3 | 1 | `TYPE` | `0x10` |
| 4 | 1 | `SEQUENCE` | `0~255` 循环 |
| 5 | 1 | `LENGTH` | `0x18`，即 24 |
| 6 | 24 | `PAYLOAD` | 见第 5 节 |
| 30 | 2 | `CRC16` | 小端序，低字节先发 |

完整帧固定为：

```text
8 + LENGTH = 8 + 24 = 32 字节
```

所有多字节整数均为小端序。不能直接发送或 `memcpy` Python/C 结构体的
内存布局，必须按字段显式打包和解包。

## 5. 唯一业务帧：VISION_CONTROL_SNAPSHOT

```text
TYPE   = 0x10
LENGTH = 24
完整帧 = 32 字节
周期   = 50 Hz
```

### 5.1 载荷定义

| 载荷偏移 | 格式 | 字段 | 含义 |
|---:|---|---|---|
| 0 | `<I` | `pi_session_id` | 本次树莓派视觉进程的随机会话号 |
| 4 | `<I` | `capture_timestamp_ms` | 图像采集单调时钟低 32 位，ms |
| 8 | `<I` | `capture_to_send_delay_us` | 图像采集到本次即将发送的延迟，μs |
| 12 | `<h` | `x_0p1mm` | 钢球位置，0.1 mm |
| 14 | `<h` | `v_mmps` | 钢球速度，mm/s |
| 16 | `B` | `confidence` | 视觉置信度，0~255 |
| 17 | `B` | `vision_flags` | 视觉有效标志 |
| 18 | `<h` | `target_x_0p1mm` | 当前控制目标，0.1 mm |
| 20 | `B` | `task_id` | 当前测评/调试任务编号 |
| 21 | `B` | `control_flags` | 控制状态标志 |
| 22 | `<H` | `run_id` | 每次开始或重启任务时递增 |

对应的载荷格式串为：

```text
<IIIhhBBhBBH
```

### 5.2 vision_flags

| 位 | 掩码 | 名称 | 含义 |
|---:|---:|---|---|
| bit0 | `0x01` | `BALL_VALID` | 本帧有真实钢球测量 |
| bit1 | `0x02` | `VELOCITY_VALID` | 本帧速度估计可用 |
| bit2 | `0x04` | `CAMERA_CALIBRATED` | 像素到物理坐标标定有效 |
| bit3 | `0x08` | `PROCESSING_DEGRADED` | 视觉处理已降级 |
| bit4~7 | — | 保留 | 当前发送 0 |

视觉内部可用短时预测维持动态 ROI，但预测结果不能伪装成真实测量发送。
只有当前图像中真实检测到钢球时才能置 `BALL_VALID=1`。

当球道姿态估计失效、坐标映射不可用或测量明显异常时，树莓派必须清除
`BALL_VALID`，而不是发送未经矫正的像素位置。

### 5.3 control_flags

| 位 | 掩码 | 名称 | 含义 |
|---:|---:|---|---|
| bit0 | `0x01` | `CONTROL_ENABLED` | 允许 C 板启用滚球闭环 |
| bit1 | `0x02` | `RUN_ACTIVE` | OLED已短按START，正式任务和录像窗口已开始 |
| bit2 | `0x04` | `TASK_DONE` | 树莓派判定本次任务完成 |
| bit3 | `0x08` | `TASK_TIMEOUT` | 树莓派判定任务超时 |
| bit4 | `0x10` | `TARGET_LATCHED` | T6目标已由OLED输入并确认，不再等待目标输入 |
| bit5~7 | — | 保留 | 当前发送 0 |

`TASK_DONE` 和 `TASK_TIMEOUT` 是任务状态，不等于立即停控。C 板是否继续
保持目标只看 `CONTROL_ENABLED`。只有 `CONTROL_ENABLED=0` 或发生本地安全
条件时，C 板才退出正常滚球闭环。

### 5.4 task_id

| 值 | 含义 | 典型 target_x |
|---:|---|---:|
| 0 | 空闲/视觉调试 | 0 |
| 2 | 测评 2，底盘项目；滚球装置保持 O | `0` |
| 3 | 测评 3，O → +5 cm → -5 cm | 分阶段为 `+500`、`-500` |
| 4 | 测评 4，车辆从 A 经 B，钢球保持 O | `0` |
| 5 | 测评 5，车辆循迹一周，钢球保持 O | `0` |
| 6 | 测评 6，钢球保持指定任意位置 | OLED输入的-10～+10 cm目标值 |

C 板不需要实现测评流程状态机，只需持续跟踪帧内 `target_x`。`task_id`
用于联调、日志和按任务选择经过验证的控制参数。

## 6. CRC16

采用 `CRC-16/CCITT-FALSE`：

```text
poly   = 0x1021
init   = 0xFFFF
refin  = false
refout = false
xorout = 0x0000
```

CRC 覆盖：

```text
VERSION | TYPE | SEQUENCE | LENGTH | PAYLOAD
```

CRC 不包含帧头 `A5 5A`，也不包含 CRC 自身。计算结果在帧尾按小端序发送。

C 参考实现：

```c
static uint16_t balllink_crc16_ccitt_false(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFu;

    while (len-- > 0u) {
        crc ^= (uint16_t)(*data++) << 8;
        for (uint8_t bit = 0u; bit < 8u; ++bit) {
            crc = (crc & 0x8000u)
                ? (uint16_t)((crc << 1) ^ 0x1021u)
                : (uint16_t)(crc << 1);
        }
    }
    return crc;
}
```

## 7. 发送时序和数据新鲜度

### 7.1 树莓派发送规则

- 串口线程独立以固定 `50 Hz` 运行，即每 `20 ms` 一帧；
- 使用绝对节拍 `next_tick += 20 ms`，不能在循环末尾简单
  `sleep(20 ms)` 后累积视觉处理时间；
- 每发送一帧，`SEQUENCE` 加 1，并按 `uint8` 从 255 回到 0；
- 每次视觉进程启动生成新的随机 `pi_session_id`；
- 任务每次重新开始时改变 `run_id`；
- 目标、任务号和控制标志在每一帧中重复发送，不能依赖单次命令到达；
- 串口暂时断开后自动重连，重连后继续发送当前完整快照。

### 7.2 时间字段

`capture_timestamp_ms` 来自树莓派单调时钟，不是日期时间。C 板与树莓派
没有时钟同步，因此 C 板不能直接用自己的时钟减去该字段。

当前树莓派使用 `v4l2-ctl` 保留原始 MJPEG 直通，因此拿到的是完整 JPEG 到达
主机的时刻，而不是 UVC 传感器的硬件曝光时间戳。v0.6.0 默认额外计入
`20 ms` 保守相机链路裕量，避免低估测量年龄；现场通过高速运动或闪灯测试得到
端到端延迟后可以收紧该裕量，但不能直接设为 0 后宣称它是曝光时间。

树莓派在每次即将写串口前重新计算：

```text
capture_to_send_delay_us =
    当前树莓派单调时刻 - 该测量对应的图像采集时刻
```

如果同一幅视觉结果被两个 50 Hz 发送周期重复使用，时间戳可以不变，但
`capture_to_send_delay_us` 必须继续增大，不能把旧测量伪装成新测量。

C 板可按下式估计当前测量年龄：

```text
measurement_age_ms =
    capture_to_send_delay_us / 1000
  + 距完整帧接收完成后的本地时间
  + UART线传输时间
```

32 字节在 115200-8-N-1 下的线传输时间约为 `2.78 ms`。实现中可使用固定
`3 ms` 补偿。

## 8. 无球和异常数据

即使没有检测到球，树莓派仍然以 `50 Hz` 发送合法帧：

```text
BALL_VALID = 0
VELOCITY_VALID = 0
x = 0
v = 0
confidence = 0
```

`CAMERA_CALIBRATED` 继续反映标定是否有效，任务和目标字段继续正常发送。
这样 C 板可以区分：

- 树莓派在线，但当前没有检测到球；
- 树莓派程序、串口或连接线已经失联。

如果 `VELOCITY_VALID=0`，树莓派必须发送 `v=0`。C 板可以在位置仍有效时
使用位置控制，但不能把该速度用于速度阻尼。

## 9. C 板接收判定和安全策略

### 9.1 合法通信帧

一帧只有同时满足以下条件才是合法通信帧：

```text
帧头正确
VERSION == 0x02
TYPE == 0x10
LENGTH == 24
CRC16 正确
字段可解码
-1300 <= x_0p1mm <= +1300
-5000 <= v_mmps <= +5000
-1200 <= target_x_0p1mm <= +1200
capture_to_send_delay_us <= 200000
```

范围限制是双保险。树莓派会先限幅，C 板仍需独立检查。目标位置最终上限
可根据实际 25 cm 管道、钢球半径和机械限位再收紧。

合法的“无球帧”仍然算通信在线，但不算可用于控制的新测量。

### 9.2 可接受的控制测量

建议同时满足以下条件才把测量作为滚球控制输入：

```text
CONTROL_ENABLED = 1
BALL_VALID = 1
CAMERA_CALIBRATED = 1
PROCESSING_DEGRADED = 0
confidence >= 180
measurement_age_ms <= 80
```

`VELOCITY_VALID=1` 时才使用 `v`。否则只使用位置，速度项置零或使用 C 板
自身经过验证的估计，不能使用该帧的 `v`。

置信度门限 `180/255 ≈ 0.706` 是联调初值。若后续根据现场样本调整，双方
必须使用同一份冻结参数，不能一端按 0.45、另一端按 0.706。

### 9.3 重复测量

- `SEQUENCE` 表示 UART 发送帧，每帧都应变化；
- `capture_timestamp_ms` 表示视觉源图像；
- 同一 `pi_session_id` 下时间戳相同，表示同一幅图像的重复广播；
- C 板可以用重复帧刷新“通信在线”状态，但不能刷新“最后一幅新测量”的
  本地接收时刻，也不能把过期测量重新变新；
- 重复图像不能再次更新差分器或观测器。

### 9.4 会话和任务变化

- `pi_session_id` 变化：树莓派视觉进程已重启。C 板清除旧视觉历史并重置
  相关观测器/差分器；
- `run_id` 变化：新一轮任务开始。C 板清除上一轮任务状态；
- `target_x` 变化：按新的设定位置控制；
- 不依赖单次边沿命令，所有状态都以最新合法快照为准。

### 9.5 超时和安全状态

C 板必须在本地实现以下保护：

| 条件 | C 板动作 |
|---|---|
| `CONTROL_ENABLED=0` | 立即退出正常滚球闭环，进入安全状态 |
| 最近可接受测量年龄超过 `80 ms` | 视觉测量失效，进入安全状态 |
| 超过 `100 ms` 没有合法通信帧 | 判定 Pi/UART 失联，进入安全状态 |
| CRC、版本、长度或字段范围错误 | 丢弃该帧，不刷新合法帧计时 |
| 新会话或新任务 | 清除旧测量历史后再使用新数据 |
| IMU 未就绪、QD4310/CAN 故障 | 禁止启用滚球闭环并进入本地安全状态 |

“安全状态”建议保持 QD4310 位置环工作，并用受限斜率把管道回到水平附近，
不要突然撤掉电机控制。具体回平斜率、角度限幅和电机故障处理由 C 板结合
实际机械系统整定。

上电、失联恢复或新会话出现后，建议至少连续收到 `3` 幅可接受且时间戳不同的
新测量，才允许重新启用滚球闭环。50 Hz 下增加约 40~60 ms，能过滤启动瞬态。

短时漏检时，C 板可以继续使用最近一次可接受测量，直到其真实年龄达到
`80 ms`；无效帧不能刷新这次测量的年龄。

C 板还必须在协议之外独立限制管道角度、电机位置、速度、电流和目标变化率，
并启用硬件或 RTOS 看门狗。通信数据合法不代表执行机构可以越过机械安全范围。

## 10. C 板接收流程参考

UART 是连续字节流，DMA 环形缓冲区可能从任意位置开始。解析器应：

1. 在字节流中搜索 `A5 5A`；
2. 收到 6 字节固定头后检查 `LENGTH <= 32`；
3. 等待 `8 + LENGTH` 个完整字节；
4. 校验 CRC；
5. 检查 `VERSION/TYPE/LENGTH`；
6. 用显式小端函数读取各字段；
7. 通过范围和状态检查后更新控制快照；
8. 出错时至少丢弃一个字节并重新搜索帧头，不能永久卡死。

简化伪代码：

```c
if (frame_ok && type == 0x10 && length == 24) {
    decode_snapshot(payload, &rx);

    if (!range_ok(&rx)) {
        drop_without_refreshing_link_timer();
        return;
    }

    refresh_valid_link_timer();

    if (session_changed(rx.pi_session_id)) {
        clear_old_vision_state();
        reset_vision_observer();
    }

    if (run_changed(rx.run_id)) {
        reset_task_state();
    }

    if ((rx.control_flags & CONTROL_ENABLED) == 0u) {
        enter_safe_level_mode();
        return;
    }

    if (measurement_acceptable(&rx) && measurement_is_new(&rx)) {
        update_ball_measurement(&rx);
    }
}

if (accepted_measurement_age_ms() > 80u ||
    valid_link_silence_ms() > 100u) {
    enter_safe_level_mode();
}
```

## 11. CRC 联调测试向量

给定：

```text
VERSION                    = 0x02
TYPE                       = 0x10
SEQUENCE                   = 0x2A
LENGTH                     = 24
pi_session_id              = 0x12345678
capture_timestamp_ms       = 0x01020304
capture_to_send_delay_us   = 15000
x_0p1mm                    = +500
v_mmps                     = -250
confidence                 = 220
vision_flags               = 0x07
target_x_0p1mm             = +500
task_id                    = 3
control_flags              = 0x03
run_id                     = 42
```

CRC 计算结果：

```text
CRC16 = 0x68F0
线上字节 = F0 68
```

完整 32 字节帧：

```text
A5 5A 02 10 2A 18
78 56 34 12
04 03 02 01
98 3A 00 00
F4 01
06 FF
DC
07
F4 01
03
03
2A 00
F0 68
```

双方各自编码后必须得到完全相同的 32 个字节，解码后也必须还原为上述值，
再进入真机联调。

## 12. 联调验收清单

- [ ] 只接 Pi TX、C RX 和 GND，C 板不发送任何数据；
- [ ] 串口参数为 115200-8-N-1、3.3 V TTL；
- [ ] Pi 连续以 50 Hz 发送 32 字节帧；
- [ ] CRC 测试向量完全一致；
- [ ] `SEQUENCE` 正确循环，Pi 重启后 `pi_session_id` 改变；
- [ ] 无球时仍有 50 Hz 合法无效帧，且 `x/v/confidence` 为 0；
- [ ] 人工放球确认坐标正负方向；
- [ ] `+5 cm`、`-5 cm` 和中心 O 的目标值分别为 `+500/-500/0`；
- [ ] C 板不会把重复图像当作新测量；
- [ ] 上电或恢复后连续 3 幅新测量才重新使能；
- [ ] `CONTROL_ENABLED=0` 时 C 板进入安全状态；
- [ ] 停止 Pi 发送后，C 板在 100 ms 内检测到失联并安全回平；
- [ ] 人为破坏 CRC、长度和范围后，C 板丢弃错误帧；
- [ ] 视觉掉球超过 80 ms 后，C 板不继续使用过期测量；
- [ ] Pi 重启或 `run_id` 变化后，C 板不沿用旧观测器历史；
- [ ] IMU/CAN/电机故障和角度、速度、电流限幅均在 C 板本地生效；
- [ ] 视频显示/录像故障不会阻塞 UART 控制数据。

## 13. 冻结规则

联调通过后，以下内容视为冻结接口：

- 帧头、版本、类型和长度；
- 字段顺序、宽度、单位和正方向；
- CRC 参数与覆盖范围；
- 50 Hz 周期；
- 80 ms 测量超时和 100 ms 链路超时；
- 单向通信、无回传、无 ACK。

后续若增加字段，不能直接改变本帧长度或复用保留位语义；应提升协议版本
或新增 `TYPE`，并由双方同时更新。
