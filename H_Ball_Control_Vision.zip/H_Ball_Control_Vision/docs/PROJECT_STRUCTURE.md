# 项目结构

```text
H_Ball_Control_Vision/
├─ main.py                       OLED比赛主入口
├─ camera_calibrate.py           相机参数入口
├─ system_selftest.py            PREFLIGHT入口
├─ vision_probe.py               算法探针入口
├─ config/pi.toml                唯一人工配置
├─ calibration/
│  └─ camera_controls.json       FIELD TUNE生成的相机参数
├─ hball/
│  ├─ algorithms/
│  │  ├─ competition_vision.py   背景、导轨、检测、跟踪总管线
│  │  ├─ rail_context_detector.py 阴影补偿钢球候选
│  │  ├─ tube_pose.py            绿色导轨几何
│  │  ├─ axis_tracker.py         一维连续跟踪与跳变隔离
│  │  ├─ mapping.py              25 cm线性右负左正映射
│  │  └─ runtime_profile.py      使用已合并配置，不再读文件
│  ├─ common/
│  │  ├─ config.py               唯一配置加载与校验
│  │  ├─ camera_controls.py      相机输出读写
│  │  └─ atomic_json.py          原子JSON写入
│  ├─ threads/
│  │  ├─ camera.py               最新MJPEG帧
│  │  ├─ node.py                 正式视觉/BallLink节点
│  │  └─ streaming.py            低开销原始图传
│  ├─ drivers/                   串口、网络、OLED
│  └─ tasks/
│     ├─ panel.py                比赛菜单
│     ├─ calibrate.py            仅相机参数搜索
│     ├─ selftest.py             PREFLIGHT
│     └─ rail_context_probe.py   独立算法诊断
├─ web/                          平板比赛接收台
├─ laptop/                       笔记本调试工具
├─ docs/                         当前版本文档
└─ tests/                        当前链路测试
```

工程中没有位置点数据集、模型激活指针、分段坐标映射或对应发布器。运行时几何和30帧背景只保存在当前进程内。
