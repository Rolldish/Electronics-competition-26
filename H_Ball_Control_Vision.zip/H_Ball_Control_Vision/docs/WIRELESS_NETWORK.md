# MT7612U 比赛热点、图传和接收端连接

这份说明只讲无线链路。滚球视觉和给 C 板的 50 Hz 串口不依赖无线网络；即使电脑
关机、热点掉线或视频页面断开，树莓派仍应继续识别，C 板仍应继续收到数据。

## 1. 已确定的现场网络

| 项目 | 正式配置 |
|---|---|
| USB 无线网卡 | MediaTek MT7612U，USB ID `0e8d:7612` |
| Linux 驱动 | `mt76x2u` |
| 树莓派接口名 | `wlan1` |
| NetworkManager 连接名 | `H2026-CAR` |
| 电脑看到的 Wi-Fi 名称 | `never give up` |
| 模式 | 5 GHz AP |
| 国家码 / 信道 | `CN` / 36 |
| 树莓派地址 | `192.168.50.1/24` |
| 客户端地址 | NetworkManager 共享模式自动分配 |
| IPv6 | 关闭 |
| 加密 | WPA2-PSK，密码不写进工程 |
| 开机启动 | 自动连接，优先级 100 |

网卡插树莓派蓝色 USB 3.0 口。`wlan0` 可以在开发阶段继续连接实验室网络，
`wlan1` 只负责比赛热点，两者互不替代。

## 2. 本工程实际使用的地址

当前版本继续使用已经完成的原始 MJPEG 方案，没有换成 WebRTC：

```text
PAD/电脑连接 Wi-Fi “never give up”
    ├─ http://192.168.50.1:8080/              统一接收、录像和回放页
    ├─ http://192.168.50.1:8080/stream.mjpg   正式原始画面
    ├─ http://192.168.50.1:8080/status.json   节点状态
    ├─ http://192.168.50.1:8080/              FIELD TUNE也沿用统一页面
    ├─ http://192.168.50.1:8083/stream.mjpg   新版算法诊断画面
    └─ UDP 10002                              BallLink镜像/录像状态
```

正式图传是摄像头原始 JPEG 的 20 FPS 抽样，不重新编码。树莓派不保存正式视频。
OPPO Pad/电脑浏览器可在统一网页中显示、保存和回放；笔记本的
`laptop/monitor.py`作为独立备用接收器。

UDP 发送目标是 `192.168.50.255:10002`，不是全局广播
`255.255.255.255`。这是因为开发时 `wlan0` 和 `wlan1` 可能同时在线，使用热点
网段的定向广播才能明确从 `wlan1` 发给电脑。

## 3. 上电后先用这些命令检查

```bash
lsusb
lsusb -t
nmcli device status
nmcli connection show --active
iw dev wlan1 info
ip -4 address show wlan1
```

关键结果应该接近：

```text
Driver=mt76x2u
wlan1  wifi  已连接  H2026-CAR
ssid never give up
type AP
channel 36
inet 192.168.50.1/24
```

`lsusb -t` 理想状态是 `Driver=mt76x2u, 5000M`。如果显示 `480M`，说明网卡只以
USB 2.0 速率工作；先检查是否插在蓝色接口以及延长线、转接头是否限制速率。

查看电脑或平板是否真的接入：

```bash
iw dev wlan1 station dump
ip neigh show dev wlan1
```

## 4. 不要把密码写进工程

热点已经配置好时，不需要重新创建。若只需修改密码，可在树莓派终端隐藏输入：

```bash
read -r -s -p "请输入Wi-Fi密码: " WIFI_PASS
echo
sudo nmcli connection modify H2026-CAR \
  802-11-wireless-security.key-mgmt wpa-psk \
  802-11-wireless-security.psk "$WIFI_PASS"
unset WIFI_PASS
sudo nmcli connection down H2026-CAR
sudo nmcli connection up H2026-CAR
```

密码至少 8 个字符。不要把真实密码写进 `pi.toml`、README、截图或比赛技术文档。

## 5. 热点配置丢失时如何恢复

先确认 `wlan1` 存在，再执行。连接已经存在时只运行 `modify`，不要重复 `add`：

```bash
nmcli connection show H2026-CAR
```

如果提示不存在，创建连接：

```bash
sudo nmcli connection add type wifi ifname wlan1 \
  con-name H2026-CAR ssid "never give up"
```

设置比赛参数：

```bash
sudo nmcli connection modify H2026-CAR \
  connection.interface-name wlan1 \
  connection.autoconnect yes \
  connection.autoconnect-priority 100 \
  802-11-wireless.mode ap \
  802-11-wireless.band a \
  802-11-wireless.channel 36 \
  ipv4.method shared \
  ipv4.addresses 192.168.50.1/24 \
  ipv6.method disabled
```

然后按上一节隐藏输入 WPA2 密码并启动连接。系统国家码仍应保持 `CN`。

## 6. 笔记本第一次连接

1. 在PAD或Windows Wi-Fi中连接 `never give up`。
2. 浏览器打开 `http://192.168.50.1:8080/`。
3. 点击一次`进入比赛模式`。
4. 确认页面显示视频和`树莓派在线`。
5. 进入一次测试任务，检查自动录像、本机列表、回放和下载。
6. 使用笔记本备用端时，再运行 `python laptop/monitor.py` 并确认UDP状态。

SSID 含空格是合法的；在命令行里必须加引号。

## 7. `PREFLIGHT` 会检查什么

`system_selftest.py` 现在会只读检查：

- `wlan1` 是否存在；
- 驱动是否为 `mt76x2u`；
- 活动连接是否为 `H2026-CAR`；
- 是否处于 AP 模式；
- SSID 是否为 `never give up`；
- 地址是否为 `192.168.50.1/24`；
- 信道是否为 36；
- 国家码是否为 `CN`。

其中一项不对，OLED 的 `PREFLIGHT` 会报告失败，终端 JSON 会显示具体字段。这个
检查只影响上场前自检结果，不会在正式任务运行中强制停止视觉、UART或滚球控制。

## 8. 常见现象

### 有视频但显示 `TELEMETRY NO DATA`

先检查 `config/pi.toml` 中：

```toml
[telemetry_udp]
host = "192.168.50.255"
port = 10002
```

再检查 Windows 防火墙是否允许 Python 接收专用网络上的 UDP 10002。

### 电脑连上热点但网页打不开

依次检查：

```bash
ip -4 address show wlan1
systemctl status hball-vision.service
ss -lntup | grep -E ':8080|:10002'
```

客户端地址必须是 `192.168.50.x`，不能是 `169.254.x.x`。

### 热点正常但重启后没有自动出现

```bash
nmcli connection show H2026-CAR
sudo nmcli connection modify H2026-CAR \
  connection.autoconnect yes \
  connection.autoconnect-priority 100
sudo nmcli connection up H2026-CAR
```

`hball-vision.service` 只把网络当软依赖：热点启动失败不能拖死视觉与 C 板控制。
