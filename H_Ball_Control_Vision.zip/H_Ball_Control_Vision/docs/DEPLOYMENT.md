# 部署到树莓派

## Windows发送

假设压缩包位于 Windows 的 `C:\Users\21115\Documents\2026`，树莓派地址为 `192.168.10.155`：

```powershell
scp C:\Users\21115\Documents\2026\H_Ball_Control_Vision_v1.6.11_competition.zip pi@192.168.10.155:/home/pi/Desktop/
```

## 树莓派替换

```bash
cd ~/Desktop
pkill -INT -f "hball.threads.node" 2>/dev/null || true

mv H_Ball_Control_Vision H_Ball_Control_Vision_before_v1.6.11
unzip -q H_Ball_Control_Vision_v1.6.11_competition.zip

cd H_Ball_Control_Vision
python3 -c "import hball; print(hball.__version__); print(hball.__file__)"
python3 -m py_compile \
  hball/common/config.py \
  hball/tasks/calibrate.py \
  hball/tasks/selftest.py \
  hball/threads/node.py

sudo bash deploy/prepare_realtime.sh
```

压缩包自带已确认的 `camera_controls.json`。若比赛场地亮度明显不同，运行 `FIELD TUNE`生成新的文件；不要从更旧目录复制任何其他校准文件。

## 启动与校验

```bash
cd ~/Desktop/H_Ball_Control_Vision
python3 main.py
```

按 `VIDEO CHECK → FIELD TUNE → READY CHECK → T2` 执行。环境未变化时跳过 `FIELD TUNE`。

```bash
python3 system_selftest.py
```

成功条件是输出JSON中的 `passed` 为 `true`。
