# BallLink v2 协议索引

本工程使用树莓派 5B 到大疆 C 板的单向 BallLink：

```text
树莓派 USB → CH340 USB-TTL TX ──→ C板 PG9 / USART6_RX
CH340 GND                         ─── C板 GND
```

C 板不回传状态，不发送 ACK，树莓派不启动 UART 接收线程。

联调时唯一有效的完整协议、接线、安全策略和 CRC 测试向量见：

```text
docs/CBOARD_ONE_WAY_BALLLINK.md
```

## 工程实现

- Python 编解码：`hball/drivers/protocol.py`
- 固定 50 Hz 发送线程：`hball/drivers/links.py`
- 视觉和任务快照接入：`hball/threads/node.py`
- C 板参考解析：`firmware/c_board/ball_telemetry.c/.h`
- Python 协议测试：`tests/test_protocol.py`
- 50 Hz 线程测试：`tests/test_links.py`
- C 解析测试：`tests/c/test_ball_telemetry.c`

当前线上帧固定为 32 字节：

```text
A5 5A | 02 | 10 | SEQ | 18 | 24字节PAYLOAD | CRC16_LE
```

24 字节载荷：

```text
<IIIhhBBhBBH
session, capture_ms, delay_us,
x_0p1mm, v_mmps, confidence, vision_flags,
target_x_0p1mm, task_id, control_flags, run_id
```

正式参数：

```text
UART             115200-8-N-1，CH340 USB-TTL
正式设备         /dev/serial/by-id/usb-1a86_USB_Serial-if00-port0
发送频率         50 Hz
控制置信度       >= 180/255
视觉发布预算     50 ms（最坏再等待一次20 ms发送周期仍不超过70 ms）
Pi 有效测量年龄  70 ms（为 C 板 80 ms 门限预留传输余量）
降级心跳范围     70–200 ms（真实时间戳，清零x/v/conf，撤销球有效）
Pi 发送硬上限    200 ms（超过后暂停旧快照，等待真正的新图像）
合法帧失联时间   100 ms
```

旧 `AA 55`、34 字节浮点协议和 v1 兼容解析均已删除，不能与本版本混用。
