# 新版轨道视觉诊断

工程只保留一条视觉算法链：

```text
绿色轨道姿态
→ 轨道配准 Lab 彩色背景
→ 物理走廊内紧凑变化候选
→ 圆形/半径/绿色上下文复核
→ 右负左正的一维跟踪
```

`vision_test.py` 和 `vision_probe.py` 都调用同一个
`hball.tasks.rail_context_probe`，不会打开 UART、不会发送 UDP 控制数据，也不会
修改正式运行的坐标、背景或相机输出文件。

## 启动

先停正式服务，避免争抢摄像头：

```bash
sudo systemctl stop hball-vision.service
cd ~/Desktop/H_Ball_Control_Vision
python3 -m py_compile \
  hball/algorithms/rail_context_detector.py \
  hball/algorithms/axis_tracker.py \
  hball/tasks/rail_context_probe.py
python3 vision_test.py --mode server
```

访问：

```text
原始视频：http://192.168.50.1:8080/
诊断视频：http://192.168.50.1:8083/stream.mjpg
诊断状态：http://192.168.50.1:8083/status.json
```

VNC/HDMI 本地查看：

```bash
python3 vision_test.py --mode local
```

默认锁定启动时 30 帧空轨的中位姿态，适合当前支架联调。验证最终机械倾角时使用：

```bash
python3 vision_test.py --mode server --dynamic-rail
```

## 固定验证顺序

1. 启动前移走钢球，等待 30 帧空轨背景完成。
2. 空轨保持 30 秒，必须始终为 `SEARCH`，不能误进入 `TRACK`。
3. 依次放置 −10、−5、0、+5、+10 cm；当前实物约定为右负左正。
4. 慢速全行程往返。
5. 快速全行程往返。
6. 保存失败时的诊断截图和完整 `status.json`。

候选拒绝原因、字段含义和详细判读见
[新版轨道上下文探针](RAW_RAIL_CONTEXT_PROBE.md)。

调试结束后恢复：

```bash
sudo systemctl start hball-vision.service
```
