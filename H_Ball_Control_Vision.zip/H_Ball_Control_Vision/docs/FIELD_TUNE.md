# FIELD TUNE：赛前现场一键相机调参

## 它解决什么

换到测评场地后，环境光与实验室不同，但相机、焦距和绿色导轨相对位置不变。
`FIELD TUNE`只为当前光线选择：

- 曝光 `exposure`；
- 增益 `gain`；
- 白平衡 `white_balance_temperature`。

它不修改绿色阈值、球检测门槛、25 cm映射、五点位置修正、速度、BallLink或C板
安全门。空轨现场样本不足以安全学习这些参数，自动修改反而容易制造误检。

## 一键流程

1. 相机、焦距、导轨和正式环境光全部固定。
2. 移走钢球，把导轨放在水平中位，手和身体离开画面。
3. OLED选 `FIELD TUNE`，长按一次启动；PAD仍打开
   `http://192.168.50.1:8080/`。
4. 程序等待2秒，然后自动完成三档曝光、必要时低增益、三档白平衡和20帧复核。
5. 成功后原子写入 `calibration/camera_controls.json`，面板自动重启视觉。
6. 再运行 `READY CHECK`：保持空轨采背景，OLED提示后放球，连续10帧有效才通过。

正常候选数约7组，通常十几秒内完成；只有零增益三档全部不能可靠建立导轨时，
才额外测试G4/G8。

## 选择依据

每个候选不仅看亮度，还直接运行比赛使用的 `RailPoseEstimator`。必须同时满足：

- 正式导轨检出率至少80%；
- 导轨置信度至少0.45；
- 端点P95抖动不超过8 px；
- 阴影区域保留可见亮度；
- 绿色区域过曝比例不超过25%。

选中候选后再采20张新图像，导轨检出率必须至少90%，且相机采集不低于50 FPS。
最终复核通过后才发布，因此某个候选短暂“碰巧识别到”不能成为正式参数。

## 失败语义

任何阶段失败都会：

- 把摄像头恢复到任务启动前的参数；
- 不覆盖原 `camera_controls.json`；
- 不修改坐标、背景和识别门限；
- 明确打印最接近候选的导轨检出、阴影亮度、过曝、置信度与抖动。

失败后先检查：钢球是否真的移走、人员阴影是否在移动、导轨是否水平完整入画、
相机是否仍为640×480 MJPEG 60 FPS。不要通过放宽C板180置信度或80/90 ms安全门解决。

## 终端入口

OLED面板是正式入口。需要脱离面板运行时：

```bash
cd ~/Desktop/H_Ball_Control_Vision
pkill -INT -f "hball.threads.node" 2>/dev/null || true
python3 camera_calibrate.py --auto-start
```

成功后检查：

```bash
python3 -m json.tool calibration/camera_controls.json
python3 -c "from hball.common.config import load_config; c=load_config('config/pi.toml'); print(c.camera_controls_source, c.camera)"
```
