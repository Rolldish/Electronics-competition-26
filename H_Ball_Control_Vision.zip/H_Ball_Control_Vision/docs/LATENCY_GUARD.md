# BallLink 延时保护

本保护只修改树莓派发送策略，不改 C 板、32 字节 BallLink v2、CRC、115200、
50 Hz、坐标单位、180 置信度门限或80 ms测量新鲜度门限。

## 根因与时间预算

32 字节在115200-8-N-1下约需2.78 ms。BallLink发送周期为20 ms，因此视觉线程
若在采集后50 ms内发布结果，即使恰好错过一次发送时隙，Pi打包年龄仍可控制在
70 ms内，并为 C 板80 ms门限保留约10 ms串口和调度余量。

以前视觉结果可在处理已经降级时继续发布为候选有效值；同时串口写超时为1 s，
USB异常可能长时间堵住发送线程。现在两处均已封住。

## 三层保护

| 采集到发送年龄 | Pi 行为 | C 板含义 |
|---:|---|---|
| `<=70 ms` | 按真实检测结果打包 | 满足其它安全门时可更新测量 |
| `70–200 ms` | 保留真实采集时间戳；清零 `x/v/confidence`；撤销 `BALL_VALID/VELOCITY_VALID`；置 `PROCESSING_DEGRADED` | 合法无效心跳，保持接收链路，但不能更新测量 |
| `>200 ms` | 暂停该旧快照，等待真正的新结果 | 不发送超出 C 板字段合法范围的帧 |

同一图像重复广播时始终使用同一 `capture_timestamp_ms`。没有球、处理降级或过期时，
绝不保留旧坐标，也不把预测值冒充新测量。

## 实时路径改动

- 节点只允许采集后50 ms内完成、相机不低于50 FPS、视觉不低于30 FPS、处理
  EWMA不高于40 ms的结果成为控制有效测量；否则直接生成降级无效帧。
- 串口 `write_timeout_s` 从1 s收紧到20 ms。32字节正常发送约2.78 ms，20 ms
  足够覆盖正常调度，USB故障则快速退出并重连。
- 串口连接/重连在锁定待发快照之前完成，避免用重连耗时把刚锁定的图像变旧。
- 网页状态 JSON 从10 Hz降到5 Hz；浏览器实际约2 Hz轮询，不影响观察。
- 图传、网页和 UDP 镜像都排在 UART 之后，不能阻塞控制串口。

## 现场判据

运行任务至少30秒，查看三个连续10秒汇总：

```bash
grep "BallLink 10s summary" ~/Desktop/hball*.log | tail -n 3
```

比赛目标：

```text
sent_frames                    约500/10s
unique_capture_frames          >=300/10s，建议>=350/10s
valid_unique_capture_frames    持续增长
max_valid_measurement_gap_ms   <80
max_delay_us                   有效帧最好<40000，必须<=70000
stale_invalid_heartbeat_frames 最好为0，偶发时应立即恢复
stale_pause_count              必须为0
session_change_count           0
run_change_count               单次任务内为0
```

`stale_invalid_heartbeat_frames` 增加时，C 板接收/接受帧计数应继续增长，但测量更新计数
不会增长，这是正确保护，不是有效视觉数据。要进入 C 板连续10帧和控制状态5，仍必须
由新图像产生连续合格测量，任何心跳都不能替代它。
