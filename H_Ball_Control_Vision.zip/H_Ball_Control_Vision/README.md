# H_Ball_Control_Vision v1.6.11

2026 电赛 H 题树莓派视觉工程。v1.6.11 以队友完成实车验证的 v1.6.7
为唯一基线，保留 E80/G0/WB4500、实物绿色轨道参数和五点位置修正，并升级
PAD/笔记本图像接收台与现场快速调参。比赛只保留一条视觉链：

`固定相机/轨道结构 → 绿色导轨运行时几何 → 30 帧空轨背景 → 阴影补偿钢球检测 → 一维跟踪 → BallLink`

坐标冻结为：画面右侧/车头为负，画面左侧/车尾为正。导轨全长以 25 cm
线性映射为主，当前五点数据只叠加位置残差，不修改速度。

## 比赛菜单

| 序号 | 菜单 | 用途 |
|---:|---|---|
| 1 | `VIDEO CHECK` | 20 FPS 原始图传，检查完整入画、清晰度和亮度 |
| 2 | `T2 O HOLD` | O 点保持 |
| 3 | `T3 +5>-5` | T3 正式任务 |
| 4 | `T4 AB@O` | T4 正式任务 |
| 5 | `T5 LAP@O` | T5 正式任务 |
| 6 | `T6 LAP@X` | 选择目标位置后运行 T6 |
| 7 | `FIELD TUNE` | 空轨一键选择当前场地E/G/WB，成功后立即重启视觉 |
| 8 | `READY CHECK` | 不重调相机，快速重采背景并检查连续10帧钢球 |
| 9 | `LINK TEST` | 保持节点和 50 Hz BallLink，检查串口链路 |

面板短按切换，长按进入；正式任务 READY 后短按 START。

## 上机前唯一流程

1. 固定相机、焦距和导轨结构，打开 `VIDEO CHECK`。
2. 换场地或光线明显变化时移走球、轨道水平，运行一次 `FIELD TUNE`。
3. 调参成功并自动重启后运行 `READY CHECK`；提示放球时再放球，等待通过。
4. 环境没变时跳过 `FIELD TUNE`，只运行 `READY CHECK`，通过后进入 T2。

不要在钢球仍位于导轨时启动节点、采背景或运行 `PREFLIGHT`。

## 唯一配置链

人工只修改 [config/pi.toml](config/pi.toml)。`FIELD TUNE` 的相机输出是
`calibration/camera_controls.json`。每个进程只调用一次 `load_config()`；该函数读取 TOML 后统一合并相机输出，节点、检查、图传和调试不再各自加载第二份配置。

现场需要扩大相机候选范围时，只修改 `[calibration]`：

```toml
exposures = [64, 88, 120]       # 亮场 / 正常 / 暗场；另含当前已保存值
gains = [0, 4, 8]               # G4/G8只在零增益全部失败时启用
white_balances = [4000, 4500, 5000]
```

上机校验门槛只修改 `[preflight]`。正式控制安全门、BallLink 协议、50 Hz 发送和字段单位不由相机校准改变。

## H题图像接收台

打开 `http://192.168.50.1:8080/`。新版第一屏显示：

- 完整 640×480 原始图传和右负左正坐标尺；
- T2-T6阶段、目标、误差、任务计时和运行编号；
- 空轨背景、真实测量、30 FPS底线和最终串口发送时龄；
- 最终 BallLink flags、x、v以及Pi串口发送状态；
- 本机自动录像、回放、下载和防息屏。

网页是无线只读接收端，不向小车发送控制命令。“Pi发送正常”不等于C板已经收到，
C板闭环状态仍以C板调试量为准。坐标尺和状态颜色均由PAD浏览器计算，树莓派仍是
原始JPEG直通，不增加视觉画框或重编码负担。

## 终端入口

```bash
cd ~/Desktop/H_Ball_Control_Vision

# OLED 主入口
python3 main.py

# 空轨现场一键调参（OLED菜单会自动使用--auto-start）
python3 camera_calibrate.py --auto-start

# 空轨上机前校验
python3 system_selftest.py

# 无任务全速视觉
python3 -m hball.threads.node --task idle --log-level INFO
```

## 图传地址

- 比赛/检查主页面：`http://192.168.50.1:8080/`
- 原始 MJPEG：`http://192.168.50.1:8080/stream.mjpg`
- 状态 JSON：`http://192.168.50.1:8080/status.json`
- `FIELD TUNE`、`READY CHECK` 与比赛任务都使用同一主页面
- 算法探针：`http://192.168.50.1:8083/`

正常比赛图传为 20 FPS；控制实时性下降时自动退到 10 FPS，视觉目标保持 30–35 FPS。

实时保护不是简单看平均帧率：节点在解码前再次锁定相机最新帧，超过20 ms的旧JPEG
直接丢弃；网页状态降到5 Hz；正式循环关闭周期GC；相机与BallLink线程使用2 ms
Python调度间隔。图传只有在视觉≥35 FPS、处理≤32 ms、发送延迟≤50 ms连续保持
2秒后才恢复20 FPS，否则保持10 FPS。

BallLink 的比赛保护分为三层：视觉结果必须在采集后 50 ms 内发布，才可能成为
有效测量；发送时年龄不超过 70 ms 才保留有效标志；70–200 ms 只发送位置、速度、
置信度全为零的降级心跳，维持接收链路但绝不更新 C 板测量；超过 200 ms 的旧快照
停止发送，等待真正的新图像。串口写超时固定为 20 ms，协议仍为 32 字节、50 Hz，
时间戳始终来自真实采集时刻。详见 [延时保护](docs/LATENCY_GUARD.md)。

正式比赛使用 `INFO` 日志：不做逐帧诊断累计，不发送非必要的 BallLink UDP 镜像。
PAD 图传仍使用 8080 HTTP/MJPEG，不受 UDP 关闭影响。只有明确使用 `DEBUG` 启动时，
才启用10秒累计诊断。

## 文档

- [上机与部署](docs/DEPLOYMENT.md)
- [配置与更新链路](docs/CONFIGURATION.md)
- [硬件基线与现场软件校准](docs/HARDWARE_VS_SOFTWARE.md)
- [FIELD TUNE现场一键调参](docs/FIELD_TUNE.md)
- [项目结构](docs/PROJECT_STRUCTURE.md)
- [比赛校验流程](docs/COMPETITION_WORKFLOW.md)
- [BallLink 协议](docs/PROTOCOL.md)
- [10 秒链路诊断](docs/BALLLINK_10S_DIAGNOSTICS.md)
- [BallLink 延时保护](docs/LATENCY_GUARD.md)
- [平板接收台](docs/PAD_WEB_RECEIVER.md)

## 约束

- 不给同一张图像伪造时间戳，不用预测值冒充有效新测量。
- 没有有效钢球时位置、速度清零并撤销 `BALL_VALID`。
- 保持 32 字节 BallLink v2、115200、50 Hz、CRC 和单位不变。
- 识别、控制、图传优先级固定为：新视觉测量 > BallLink > 图传装饰。
