# -*- coding: utf-8 -*-
"""独立验证新版钢球视觉链，不发送控制数据。

树莓派运行：
    python3 vision_probe.py

本地屏幕：
    python3 vision_probe.py --mode local
"""

from hball.tasks.rail_context_probe import main


if __name__ == "__main__":
    main()
