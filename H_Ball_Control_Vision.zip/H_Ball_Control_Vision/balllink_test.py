# -*- coding: utf-8 -*-
"""树莓派到大疆C板的单向 BallLink 通信测试。

直接运行：
    python3 balllink_test.py

默认按 50 Hz 自动发送约 15 秒：
    无球 -> 中心 -> +5 cm -> -5 cm -> 无球

所有测试帧的 CONTROL_ENABLED 均为 0，不会请求C板启用滚球控制。
"""

from __future__ import annotations

import argparse
import secrets
import time
from dataclasses import dataclass

from hball.drivers.protocol import (
    ControlFlags,
    Flags,
    TaskId,
    Telemetry,
    encode_packet,
)
from hball.drivers.usb_serial import resolve_usb_serial_port


@dataclass(frozen=True)
class TestStage:
    name: str
    x_0p1mm: int
    confidence: int
    flags: Flags


STAGES = (
    TestStage("无球", 0, 0, Flags.CAMERA_CALIBRATED),
    TestStage(
        "中心 O",
        0,
        220,
        Flags.BALL_VALID | Flags.VELOCITY_VALID | Flags.CAMERA_CALIBRATED,
    ),
    TestStage(
        "+5 cm",
        500,
        220,
        Flags.BALL_VALID | Flags.VELOCITY_VALID | Flags.CAMERA_CALIBRATED,
    ),
    TestStage(
        "-5 cm",
        -500,
        220,
        Flags.BALL_VALID | Flags.VELOCITY_VALID | Flags.CAMERA_CALIBRATED,
    ),
    TestStage("无球（结束）", 0, 0, Flags.CAMERA_CALIBRATED),
)


def make_test_packet(
    stage: TestStage,
    *,
    session_id: int,
    sequence: int,
    run_id: int,
    timestamp_ms: int,
) -> bytes:
    message = Telemetry(
        session_id=session_id,
        sequence=sequence,
        capture_timestamp_ms=timestamp_ms & 0xFFFFFFFF,
        capture_to_send_delay_us=0,
        x_0p1mm=stage.x_0p1mm,
        v_mmps=0,
        confidence_u8=stage.confidence,
        flags=stage.flags,
        target_x_0p1mm=0,
        task_id=TaskId.IDLE,
        control_flags=ControlFlags(0),
        run_id=run_id,
    )
    return encode_packet(message)


def open_serial(port: str, baudrate: int):
    try:
        import serial
    except ImportError as error:
        raise RuntimeError(
            "未安装 pyserial，请执行：sudo apt install python3-serial"
        ) from error

    try:
        return serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=8,
            parity="N",
            stopbits=1,
            timeout=0,
            write_timeout=0.1,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False,
            exclusive=True,
        )
    except Exception as error:
        raise RuntimeError(
            f"无法打开 {port}：{error}\n"
            "请确认没有其他程序占用串口，可先停止视觉服务。"
        ) from error


def run(
    *,
    port: str,
    baudrate: int,
    tx_hz: float,
    stage_seconds: float,
    dry_run: bool,
) -> int:
    if tx_hz <= 0 or stage_seconds <= 0:
        raise ValueError("tx_hz 和 stage_seconds 必须大于 0")

    resolved_port = port if dry_run else resolve_usb_serial_port(port)
    serial_port = None if dry_run else open_serial(resolved_port, baudrate)
    session_id = secrets.randbits(32)
    run_id = 1
    sequence = 0
    generated_count = 0
    sent_count = 0
    sent_bytes = 0
    period_ns = int(round(1_000_000_000 / tx_hz))
    stage_ns = int(round(stage_seconds * 1_000_000_000))

    print(
        f"BallLink TX: {resolved_port} @ {baudrate}, {tx_hz:g} Hz, "
        f"session=0x{session_id:08X}"
    )
    print("安全状态：CONTROL_ENABLED=0；C板不应启动滚球控制")

    try:
        next_tick_ns = time.monotonic_ns()
        for index, stage in enumerate(STAGES, start=1):
            print(
                f"[{index}/{len(STAGES)}] {stage.name}: "
                f"x={stage.x_0p1mm:+d} (0.1 mm), "
                f"flags=0x{int(stage.flags):02X}"
            )
            deadline_ns = next_tick_ns + stage_ns
            first_packet = True

            while next_tick_ns < deadline_ns:
                now_ns = time.monotonic_ns()
                if now_ns < next_tick_ns:
                    time.sleep((next_tick_ns - now_ns) / 1_000_000_000)
                    continue
                if now_ns - next_tick_ns > period_ns * 2:
                    next_tick_ns = now_ns
                    deadline_ns = max(deadline_ns, next_tick_ns + period_ns)

                packet = make_test_packet(
                    stage,
                    session_id=session_id,
                    sequence=sequence,
                    run_id=run_id,
                    timestamp_ms=now_ns // 1_000_000,
                )
                if first_packet:
                    print("  首帧:", packet.hex(" ").upper())
                    first_packet = False
                if serial_port is not None:
                    written = serial_port.write(packet)
                    if written != len(packet):
                        raise RuntimeError(f"串口短写：{written}/{len(packet)} 字节")
                    sent_count += 1
                    sent_bytes += written

                generated_count += 1
                sequence = (sequence + 1) & 0xFF
                next_tick_ns += period_ns

        if serial_port is not None:
            serial_port.flush()
    finally:
        if serial_port is not None:
            serial_port.close()

    if dry_run:
        print(
            f"DRY-RUN完成：生成 {generated_count} 帧，"
            "实际串口发送 0 帧、0 字节"
        )
    else:
        print(
            f"完成：串口成功写入 {sent_count} 帧、{sent_bytes} 字节；"
            "停止后C板应在100 ms内判定失联"
        )
    return sent_count


def main() -> None:
    parser = argparse.ArgumentParser(description="树莓派到C板 BallLink 单向通信测试")
    parser.add_argument(
        "--port",
        default="/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0",
        help="CH340稳定by-id路径；更换模块后可用auto-usb诊断",
    )
    parser.add_argument("--baudrate", type=int, default=115200)
    parser.add_argument("--tx-hz", type=float, default=50.0)
    parser.add_argument("--stage-seconds", type=float, default=3.0)
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="不打开串口，只生成并显示测试帧",
    )
    args = parser.parse_args()

    try:
        run(
            port=args.port,
            baudrate=args.baudrate,
            tx_hz=args.tx_hz,
            stage_seconds=args.stage_seconds,
            dry_run=args.dry_run,
        )
    except (OSError, RuntimeError, ValueError) as error:
        raise SystemExit(f"测试失败：{error}") from error


if __name__ == "__main__":
    main()
