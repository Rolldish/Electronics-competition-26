"""Raspberry Pi application entry point.

The OLED/button task panel is the normal boot-time supervisor. Individual
workers remain available through the command-line entry points in pyproject.toml.
"""

from hball.tasks.panel import main


if __name__ == "__main__":
    main()
