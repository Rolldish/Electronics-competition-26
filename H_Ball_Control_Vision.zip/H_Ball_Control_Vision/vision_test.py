# -*- coding: utf-8 -*-
"""树莓派新版轨道上下文钢球识别测试。

直接运行：
    python3 vision_test.py

常用选项：
    python3 vision_test.py --mode local
    python3 vision_test.py --mode server
    python3 vision_test.py --mode server --dynamic-rail

本程序不会发送 UART/UDP 控制数据。
"""

from hball.tasks.rail_context_probe import main


if __name__ == "__main__":
    main()
