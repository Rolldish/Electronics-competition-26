#!/usr/bin/env python3
"""Competition camera exposure/gain/white-balance calibration entry point."""

from hball.tasks.calibrate import main


if __name__ == "__main__":
    main()
