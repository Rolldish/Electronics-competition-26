from pathlib import Path
import unittest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = PROJECT_ROOT / "hball"


class ProjectStructureTests(unittest.TestCase):
    def test_required_responsibility_packages_exist(self) -> None:
        expected = {"algorithms", "threads", "drivers", "tasks", "common"}
        actual = {
            path.name
            for path in PACKAGE_ROOT.iterdir()
            if path.is_dir() and (path / "__init__.py").is_file()
        }
        self.assertTrue(expected.issubset(actual))

    def test_hball_root_contains_no_uncategorized_python_modules(self) -> None:
        modules = {path.name for path in PACKAGE_ROOT.glob("*.py")}
        self.assertEqual(modules, {"__init__.py"})

    def test_default_main_entry_exists(self) -> None:
        entry = PROJECT_ROOT / "main.py"
        self.assertTrue(entry.is_file())
        self.assertIn(
            "from hball.tasks.panel import main",
            entry.read_text(encoding="utf-8"),
        )

    def test_previous_project_style_direct_launchers_exist(self) -> None:
        expected = {
            "vision_test.py": "hball.tasks.rail_context_probe",
            "vision_probe.py": "hball.tasks.rail_context_probe",
            "camera_calibrate.py": "hball.tasks.calibrate",
            "system_selftest.py": "hball.tasks.selftest",
        }
        for filename, module in expected.items():
            with self.subTest(filename=filename):
                source = (PROJECT_ROOT / filename).read_text(encoding="utf-8")
                self.assertIn(f"from {module} import main", source)

    def test_nested_probe_entry_bootstraps_project_root(self) -> None:
        source = (PACKAGE_ROOT / "tasks" / "rail_context_probe.py").read_text(
            encoding="utf-8"
        )
        self.assertIn("sys.path.insert(0, str(PROJECT_ROOT))", source)

    def test_removed_legacy_algorithms_do_not_return(self) -> None:
        removed = {
            PACKAGE_ROOT / "algorithms" / "detector.py",
            PACKAGE_ROOT / "algorithms" / "tracking.py",
            PACKAGE_ROOT / "algorithms" / "vision.py",
            PACKAGE_ROOT / "algorithms" / "autotune.py",
            PACKAGE_ROOT / "tasks" / "debug_viewer.py",
        }
        self.assertTrue(all(not path.exists() for path in removed))


if __name__ == "__main__":
    unittest.main()
