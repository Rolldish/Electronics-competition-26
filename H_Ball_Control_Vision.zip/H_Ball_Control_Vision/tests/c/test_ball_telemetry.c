#include <assert.h>
#include <stddef.h>
#include <stdint.h>

#include "../../firmware/c_board/ball_telemetry.h"


int main(void)
{
    static const uint8_t packet[HBALL_PACKET_SIZE] = {
        0xA5, 0x5A, 0x02, 0x10, 0x2A, 0x18,
        0x78, 0x56, 0x34, 0x12,
        0x04, 0x03, 0x02, 0x01,
        0x98, 0x3A, 0x00, 0x00,
        0xF4, 0x01,
        0x06, 0xFF,
        0xDC,
        0x07,
        0xF4, 0x01,
        0x03,
        0x03,
        0x2A, 0x00,
        0xF0, 0x68
    };
    hball_parser_t parser;
    hball_snapshot_t output;
    size_t i;
    bool complete = false;

    assert(hball_crc16_ccitt_false(
        (const uint8_t *)"123456789",
        9u
    ) == 0x29B1u);

    hball_parser_init(&parser);
    (void)hball_parser_push(&parser, 0x13u, &output);
    (void)hball_parser_push(&parser, 0xA5u, &output);
    (void)hball_parser_push(&parser, 0x01u, &output);
    for (i = 0u; i < HBALL_PACKET_SIZE; ++i) {
        complete = hball_parser_push(&parser, packet[i], &output);
    }

    assert(complete);
    assert(parser.good_packets == 1u);
    assert(output.version == HBALL_VERSION);
    assert(output.frame_type == HBALL_TYPE_VISION_CONTROL_SNAPSHOT);
    assert(output.sequence == 0x2Au);
    assert(output.pi_session_id == 0x12345678u);
    assert(output.capture_timestamp_ms == 0x01020304u);
    assert(output.capture_to_send_delay_us == 15000u);
    assert(output.x_0p1mm == 500);
    assert(output.v_mmps == -250);
    assert(output.confidence == 220u);
    assert(output.vision_flags == (
        HBALL_FLAG_BALL_VALID
        | HBALL_FLAG_VELOCITY_VALID
        | HBALL_FLAG_CAMERA_CALIBRATED
    ));
    assert(output.target_x_0p1mm == 500);
    assert(output.task_id == HBALL_TASK_T3);
    assert(output.control_flags == (
        HBALL_CONTROL_ENABLED | HBALL_CONTROL_RUN_ACTIVE
    ));
    assert(output.run_id == 42u);
    assert(hball_measurement_acceptable(&output, 20u));
    assert(!hball_measurement_acceptable(&output, 81u));
    assert(hball_velocity_valid(&output));

    {
        uint8_t broken[HBALL_PACKET_SIZE];
        for (i = 0u; i < HBALL_PACKET_SIZE; ++i) {
            broken[i] = packet[i];
        }
        broken[18] ^= 0x80u;
        complete = false;
        for (i = 0u; i < HBALL_PACKET_SIZE; ++i) {
            complete = hball_parser_push(&parser, broken[i], &output);
        }
        assert(!complete);
        assert(parser.bad_packets >= 1u);
    }
    return 0;
}
