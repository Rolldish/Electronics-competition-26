import threading
import time
import unittest

from hball.common.config import SerialConfig
from hball.drivers.links import BallLinkPublisher, _BallLinkDiagnostics
from hball.drivers.protocol import (
    ControlFlags,
    Flags,
    TaskId,
    Telemetry,
    TxSnapshot,
    decode_packet,
)


class BallLinkPublisherTests(unittest.TestCase):
    @staticmethod
    def _message(
        capture_ms: int,
        *,
        delay_us: int = 30_000,
        confidence: int = 200,
        flags: Flags = (
            Flags.BALL_VALID
            | Flags.VELOCITY_VALID
            | Flags.CAMERA_CALIBRATED
        ),
        session_id: int = 1,
        run_id: int = 7,
    ) -> Telemetry:
        return Telemetry(
            session_id=session_id,
            sequence=0,
            capture_timestamp_ms=capture_ms,
            capture_to_send_delay_us=delay_us,
            x_0p1mm=100 if flags & Flags.BALL_VALID else 0,
            v_mmps=20 if flags & Flags.VELOCITY_VALID else 0,
            confidence_u8=confidence,
            flags=flags,
            target_x_0p1mm=0,
            task_id=TaskId.T2,
            control_flags=ControlFlags.CONTROL_ENABLED,
            run_id=run_id,
        )

    def test_ten_second_diagnostics_uses_final_wire_fields(self) -> None:
        diagnostics = _BallLinkDiagnostics(window_started_ns=0)
        diagnostics.observe_sent(self._message(1_000), 1_000_000_000)
        diagnostics.observe_sent(self._message(1_000), 1_010_000_000)
        diagnostics.observe_sent(
            self._message(
                1_040,
                delay_us=45_000,
                flags=Flags.BALL_VALID | Flags.CAMERA_CALIBRATED,
            ),
            1_040_000_000,
        )
        diagnostics.observe_sent(
            self._message(
                1_125,
                delay_us=50_000,
                confidence=100,
                flags=Flags.CAMERA_CALIBRATED | Flags.PROCESSING_DEGRADED,
                session_id=2,
                run_id=8,
            ),
            1_125_000_000,
        )
        diagnostics.observe_sent(
            self._message(
                1_200,
                delay_us=80_000,
                confidence=0,
                flags=Flags.CAMERA_CALIBRATED
                | Flags.PROCESSING_DEGRADED,
                session_id=2,
                run_id=8,
            ),
            1_200_000_000,
        )

        self.assertEqual(diagnostics.sent_frames, 5)
        self.assertEqual(diagnostics.unique_capture_frames, 4)
        self.assertEqual(diagnostics.repeated_capture_frames, 1)
        self.assertEqual(diagnostics.valid_vision_frames, 3)
        self.assertEqual(diagnostics.ball_invalid_frames, 2)
        self.assertEqual(diagnostics.processing_degraded_frames, 2)
        self.assertEqual(diagnostics.low_confidence_frames, 2)
        self.assertEqual(diagnostics.delay_over_77ms_frames, 1)
        self.assertEqual(diagnostics.stale_paused_frames, 0)
        self.assertEqual(diagnostics.stale_invalid_heartbeat_frames, 1)
        self.assertEqual(diagnostics.max_capture_gap_ms, 85)
        self.assertEqual(diagnostics.session_change_count, 1)
        self.assertEqual(diagnostics.run_change_count, 1)

        with self.assertLogs("hball.drivers.links", level="INFO") as captured:
            diagnostics.emit_if_due(10_000_000_000)
        summary = captured.output[0]
        self.assertIn("max_valid_measurement_gap_ms=40", summary)
        self.assertIn("current_valid_measurement_age_ms=8960", summary)
        self.assertIn("last_vision_flags=0x0C", summary)
        self.assertIn("last_task_id=2", summary)
        self.assertIn("last_run_id=8", summary)
        self.assertIn("session_id=2", summary)

    def test_stale_snapshot_keeps_50hz_invalid_heartbeat(self) -> None:
        packets: list[bytes] = []
        received_two = threading.Event()

        def collect(packet: bytes) -> None:
            packets.append(packet)
            if len(packets) >= 2:
                received_two.set()

        publisher = BallLinkPublisher(
            SerialConfig(enabled=False, tx_hz=50.0),
            packet_sinks=(collect,),
        )
        capture_ns = time.monotonic_ns() - 100_000_000
        publisher.start()
        publisher.publish(
            TxSnapshot(
                capture_timestamp_ns=capture_ns,
                flags=Flags.BALL_VALID
                | Flags.VELOCITY_VALID
                | Flags.CAMERA_CALIBRATED,
                x_m=0.01,
                v_mps=0.02,
                confidence=0.9,
                target_x_m=0.0,
                task_id=TaskId.T2,
                control_flags=ControlFlags.CONTROL_ENABLED,
                run_id=9,
            )
        )
        try:
            self.assertTrue(received_two.wait(0.30))
        finally:
            publisher.close()

        messages = [decode_packet(packet) for packet in packets]
        self.assertGreaterEqual(len(messages), 2)
        self.assertTrue(
            all(item.flags & Flags.PROCESSING_DEGRADED for item in messages)
        )
        self.assertTrue(
            all(not item.flags & Flags.BALL_VALID for item in messages)
        )
        self.assertTrue(all(item.x_0p1mm == 0 for item in messages))
        self.assertEqual(
            len({item.capture_timestamp_ms for item in messages}),
            1,
        )

    def test_repeats_latest_snapshot_on_fixed_rate_worker(self) -> None:
        packets: list[bytes] = []
        received_two = threading.Event()

        def collect(packet: bytes) -> None:
            packets.append(packet)
            if len(packets) >= 2:
                received_two.set()

        publisher = BallLinkPublisher(
            SerialConfig(enabled=False, tx_hz=50.0),
            packet_sinks=(collect,),
        )
        capture_ns = time.monotonic_ns()
        publisher.start()
        publisher.publish(
            TxSnapshot(
                capture_timestamp_ns=capture_ns,
                flags=(
                    Flags.BALL_VALID
                    | Flags.VELOCITY_VALID
                    | Flags.CAMERA_CALIBRATED
                ),
                x_m=0.01,
                v_mps=0.02,
                confidence=0.9,
                target_x_m=0.0,
                task_id=TaskId.T4,
                control_flags=(
                    ControlFlags.CONTROL_ENABLED | ControlFlags.RUN_ACTIVE
                ),
                run_id=9,
            )
        )
        try:
            # Two sends prove that a 50 Hz worker repeats the same source frame.
            self.assertTrue(received_two.wait(0.30))
        finally:
            publisher.close()

        messages = [decode_packet(packet) for packet in packets]
        self.assertGreaterEqual(len(messages), 2)
        self.assertEqual(
            [item.sequence for item in messages[:2]],
            [
                messages[0].sequence,
                (messages[0].sequence + 1) & 0xFF,
            ],
        )
        self.assertEqual({item.session_id for item in messages}, {publisher.session_id})
        self.assertEqual(
            {item.capture_timestamp_ms for item in messages},
            {(capture_ns // 1_000_000) & 0xFFFFFFFF},
        )


if __name__ == "__main__":
    unittest.main()
