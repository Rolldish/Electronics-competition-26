import unittest
import struct

from hball.drivers.mjpeg import (
    JpegByteStreamParser,
    V4L2_FILE_HEADER_ID,
    V4l2FramedJpegParser,
)


class MjpegParserTests(unittest.TestCase):
    def test_chunk_boundaries_and_multipart_noise(self) -> None:
        first = b"\xff\xd8first-jpeg\xff\xd9"
        second = b"\xff\xd8second-jpeg\xff\xd9"
        wire = (
            b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"
            + first
            + b"\r\n--frame\r\nContent-Type: image/jpeg\r\n\r\n"
            + second
        )
        parser = JpegByteStreamParser()
        output = []
        for index in range(0, len(wire), 7):
            output.extend(parser.push(wire[index : index + 7]))
        self.assertEqual(output, [first, second])

    def test_recovers_after_oversized_incomplete_frame(self) -> None:
        parser = JpegByteStreamParser(max_frame_bytes=12)
        self.assertEqual(parser.push(b"\xff\xd8" + b"x" * 20), [])
        valid = b"\xff\xd8ok\xff\xd9"
        self.assertEqual(parser.push(valid), [valid])

    def test_v4l2_header_preserves_exact_frame_boundary(self) -> None:
        first = b"\xff\xd8one\xff\xd9"
        second = b"\xff\xd8two\xff\xd9"
        wire = (
            struct.pack(">II", V4L2_FILE_HEADER_ID, len(first))
            + first
            + struct.pack(">II", V4L2_FILE_HEADER_ID, len(second))
            + second
        )
        parser = V4l2FramedJpegParser()
        output = []
        for index in range(0, len(wire), 3):
            output.extend(parser.push(wire[index : index + 3]))
        self.assertEqual(output, [first, second])

    def test_v4l2_header_trims_uvc_alignment_padding(self) -> None:
        jpeg = b"\xff\xd8padded-camera-frame\xff\xd9"
        payload = b"\x00\x00" + jpeg + b"\x00" * 6
        wire = struct.pack(
            ">II",
            V4L2_FILE_HEADER_ID,
            len(payload),
        ) + payload
        parser = V4l2FramedJpegParser()
        self.assertEqual(parser.push(wire), [jpeg])


if __name__ == "__main__":
    unittest.main()
