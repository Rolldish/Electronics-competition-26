from __future__ import annotations

import unittest

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None

from hball.common.config import DetectorConfig, MappingConfig, TubePoseConfig

if cv2 is not None:
    from hball.algorithms.rail_context_detector import RailContextBallDetector
    from hball.algorithms.tube_pose import TubePose


@unittest.skipUnless(cv2 is not None, "OpenCV is an optional Pi dependency")
class RailContextBallDetectorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.detector = RailContextBallDetector(
            DetectorConfig(
                min_radius_px=8,
                max_radius_px=17,
                gradient_threshold=42,
            ),
            TubePoseConfig(),
            MappingConfig(),
            0.010,
        )
        self.pose = TubePose(
            negative_px=(560.0, 240.0),
            positive_px=(80.0, 240.0),
            width_px=80.0,
            confidence=0.9,
            timestamp_ns=1_000_000_000,
            measured=True,
        )
        empty = self._scene(False)
        self.detector.set_background(
            [
                self.detector.reference_sample(empty, self.pose)
                for _ in range(5)
            ]
        )

    @staticmethod
    def _scene(with_ball: bool) -> np.ndarray:
        image = np.full((480, 640, 3), 25, dtype=np.uint8)
        cv2.rectangle(image, (40, 195), (600, 285), (40, 170, 50), -1)
        if with_ball:
            cv2.circle(image, (320, 240), 12, (185, 185, 185), -1, cv2.LINE_AA)
            cv2.circle(image, (316, 236), 3, (245, 245, 245), -1, cv2.LINE_AA)
        return image

    def test_empty_green_rail_has_no_accepted_candidate(self) -> None:
        result = self.detector.detect(self._scene(False), self.pose)
        self.assertEqual(result.accepted, ())

    def test_silver_ball_is_accepted_near_the_axis(self) -> None:
        result = self.detector.detect(self._scene(True), self.pose)
        self.assertTrue(result.accepted)
        best = result.accepted[0]
        self.assertAlmostEqual(best.x_px, 320.0, delta=3.0)
        self.assertAlmostEqual(best.y_px, 240.0, delta=3.0)
        self.assertAlmostEqual(best.radius_px, 12.0, delta=3.0)
        self.assertLess(abs(best.cross_axis_px), 3.0)
        self.assertAlmostEqual(best.axis_fraction, 0.5, delta=0.03)
        roi = result.seed_diagnostics["analysis_roi"]
        self.assertLess(roi["pixel_ratio"], 0.35)
        self.assertLessEqual(roi["x"], int(round(best.x_px)))
        self.assertGreater(roi["x"] + roi["width"], int(round(best.x_px)))

    def test_low_light_contrast_path_keeps_ball_detectable(self) -> None:
        detector = RailContextBallDetector(
            DetectorConfig(
                min_radius_px=8,
                max_radius_px=17,
                gradient_threshold=42,
                low_light_contrast_floor=80,
            ),
            TubePoseConfig(green_s_min=130),
            MappingConfig(),
            0.010,
        )
        empty = np.full((480, 640, 3), 10, dtype=np.uint8)
        cv2.rectangle(empty, (40, 195), (320, 285), (20, 34, 23), -1)
        cv2.rectangle(empty, (321, 195), (600, 285), (30, 48, 33), -1)
        detector.set_background(
            [detector.reference_sample(empty, self.pose) for _ in range(5)]
        )
        ball = empty.copy()
        cv2.circle(ball, (320, 240), 12, (66, 66, 66), -1, cv2.LINE_AA)
        cv2.circle(ball, (316, 236), 3, (92, 92, 92), -1, cv2.LINE_AA)
        result = detector.detect(ball, self.pose)
        self.assertTrue(result.accepted)
        self.assertTrue(
            result.seed_diagnostics["low_light_contrast_enhanced"]
        )
        self.assertAlmostEqual(result.accepted[0].x_px, 320.0, delta=4.0)

    def test_broad_moving_shadow_is_not_a_ball(self) -> None:
        shadowed = self._scene(False)
        region = shadowed[190:291, 220:421].astype(np.float32)
        shadowed[190:291, 220:421] = np.clip(
            region * 0.45,
            0,
            255,
        ).astype(np.uint8)
        result = self.detector.detect(shadowed, self.pose)
        self.assertEqual(result.accepted, ())
        self.assertTrue(
            result.seed_diagnostics["shadow_compensation_active"]
        )

    def test_ball_inside_broad_moving_shadow_remains_detectable(self) -> None:
        shadowed = self._scene(True)
        region = shadowed[190:291, 220:421].astype(np.float32)
        shadowed[190:291, 220:421] = np.clip(
            region * 0.45,
            0,
            255,
        ).astype(np.uint8)
        result = self.detector.detect(shadowed, self.pose)
        self.assertTrue(result.accepted)
        self.assertAlmostEqual(result.accepted[0].x_px, 320.0, delta=4.0)

    def test_axis_fraction_increases_from_right_to_left(self) -> None:
        right = self._scene(False)
        left = self._scene(False)
        cv2.circle(right, (500, 240), 12, (185, 185, 185), -1, cv2.LINE_AA)
        cv2.circle(left, (140, 240), 12, (185, 185, 185), -1, cv2.LINE_AA)
        right_result = self.detector.detect(right, self.pose)
        left_result = self.detector.detect(left, self.pose)
        self.assertTrue(right_result.accepted)
        self.assertTrue(left_result.accepted)
        self.assertLess(
            right_result.accepted[0].axis_fraction,
            left_result.accepted[0].axis_fraction,
        )


if __name__ == "__main__":
    unittest.main()
