import unittest

from hball.tasks.panel import MENU


class PanelTests(unittest.TestCase):
    def test_h_problem_menu_contains_only_current_workflows(self) -> None:
        self.assertEqual(
            [entry.label for entry in MENU],
            [
                "VIDEO CHECK",
                "T2 O HOLD",
                "T3 +5>-5",
                "T4 AB@O",
                "T5 LAP@O",
                "T6 LAP@X",
                "FIELD TUNE",
                "READY CHECK",
                "LINK TEST",
            ],
        )
        self.assertEqual(MENU[0].command, "VIDEO")
        self.assertEqual(MENU[6].module, "hball.tasks.calibrate")
        self.assertEqual(MENU[6].arguments, ("--auto-start",))
        self.assertEqual(MENU[6].status_port, 8080)
        self.assertEqual(MENU[7].command, "CHECK")
        self.assertEqual(MENU[6].interaction, "setup")
        self.assertTrue(MENU[2].formal_task)
        self.assertEqual(MENU[5].interaction, "target")


if __name__ == "__main__":
    unittest.main()
