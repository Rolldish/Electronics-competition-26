import unittest
from pathlib import Path

from hball.common.config import load_config


class ConfigTests(unittest.TestCase):
    def test_pi_config_has_one_camera_tuning_path(self) -> None:
        project = Path(__file__).resolve().parents[1]
        config = load_config(project / "config" / "pi.toml")
        self.assertEqual(
            config.calibration.camera_controls_path,
            project / "calibration" / "camera_controls.json",
        )
        self.assertEqual(config.calibration.exposures, (64, 88, 120))
        self.assertEqual(config.calibration.gains, (0, 4, 8))
        self.assertEqual(
            config.calibration.white_balances,
            (4000, 4500, 5000),
        )
        self.assertEqual(config.calibration.verification_frames, 20)
        self.assertEqual(config.calibration.preview_port, 8080)
        self.assertEqual(config.preflight.min_vision_fps, 30.0)
        self.assertTrue(config.preflight.require_serial)
        self.assertEqual(config.target.ball_diameter_m, 0.010)
        self.assertGreater(
            config.mapping.negative_point_px[0],
            config.mapping.positive_point_px[0],
        )
        self.assertTrue(config.mapping.position_correction_enabled)
        self.assertEqual(
            len(config.mapping.position_correction_axis_fractions),
            5,
        )
        self.assertEqual(config.tube_pose.min_aspect_ratio, 3.5)
        self.assertEqual(config.tube_pose.low_light_green_s_min, 130)
        self.assertTrue(config.tube_pose.lock_after_background)
        self.assertEqual(config.tracker.measurement_median_window, 3)
        self.assertEqual(config.runtime.startup_background_frames, 30)
        self.assertEqual(config.serial.tx_hz, 50.0)
        self.assertEqual(config.serial.write_timeout_s, 0.02)
        self.assertEqual(config.video.fps, 20.0)
        self.assertEqual(config.runtime.status_update_hz, 5.0)
        self.assertEqual(config.runtime.max_publish_age_ms, 50.0)
        self.assertEqual(
            config.camera_controls_source,
            "CURRENT_ENVIRONMENT",
        )
        self.assertEqual(config.camera.exposure, 80)
        self.assertEqual(config.camera.white_balance_temperature, 4500)
        self.assertAlmostEqual(config.task.minimum_confidence, 180 / 255)


if __name__ == "__main__":
    unittest.main()
