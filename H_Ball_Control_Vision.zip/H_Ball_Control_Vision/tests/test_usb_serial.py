import tempfile
import unittest
from pathlib import Path

from hball.drivers.usb_serial import list_usb_serial_ports, resolve_usb_serial_port


class UsbSerialTests(unittest.TestCase):
    def test_explicit_port_is_not_changed(self) -> None:
        path = "/dev/serial/by-id/usb-team-balllink"
        self.assertEqual(resolve_usb_serial_port(path), path)

    def test_falls_back_to_single_ttyusb_device(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            device = root / "ttyUSB0"
            device.touch()
            self.assertEqual(
                list_usb_serial_ports(root / "missing", root),
                [str(device)],
            )

    def test_lists_usb_and_acm_devices(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "ttyUSB1").touch()
            (root / "ttyACM0").touch()
            (root / "ttyAMA0").touch()
            self.assertEqual(
                set(list_usb_serial_ports(root / "missing", root)),
                {str(root / "ttyUSB1"), str(root / "ttyACM0")},
            )


if __name__ == "__main__":
    unittest.main()
