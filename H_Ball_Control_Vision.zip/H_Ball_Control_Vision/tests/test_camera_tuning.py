from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None

if cv2 is not None:
    from hball.common.config import CalibrationConfig, load_config
    from hball.tasks.calibrate import (
        auto_camera_controls,
        _camera_candidate_is_safe,
        _camera_candidate_score,
        _camera_verification_is_safe,
        _select_best_safe_candidate,
    )


@unittest.skipUnless(cv2 is not None, "OpenCV is an optional Pi dependency")
class CameraTuningTests(unittest.TestCase):
    @staticmethod
    def _rail_frame(rail_bgr: tuple[int, int, int]) -> np.ndarray:
        frame = np.full((480, 640, 3), 22, dtype=np.uint8)
        cv2.rectangle(frame, (40, 195), (600, 285), rail_bgr, -1)
        return frame

    def test_camera_score_rewards_shadow_headroom_without_clipping(self) -> None:
        dim = self._rail_frame((18, 62, 22))
        visible = self._rail_frame((40, 150, 48))
        self.assertGreater(
            _camera_candidate_score([visible]),
            _camera_candidate_score([dim]),
        )

    def test_unsafe_high_score_can_never_override_publication_gate(self) -> None:
        tuning = CalibrationConfig(
            minimum_rail_shadow_value=24.0,
            maximum_green_clipping_ratio=0.08,
        )
        unsafe = {
            "exposure": 120,
            "gain": 4,
            "white_balance_temperature": 3500,
            "score": 0.81,
            "rail_found_rate": 1.0,
            "lower_rail_value": 87.0,
            "green_clipping_ratio": 0.2295,
        }
        safe = {
            "exposure": 88,
            "gain": 0,
            "white_balance_temperature": 5000,
            "score": 0.61,
            "rail_found_rate": 1.0,
            "lower_rail_value": 52.0,
            "green_clipping_ratio": 0.04,
        }
        selected = _select_best_safe_candidate(
            [unsafe, safe],
            tuning,
            stage="test",
        )
        self.assertIs(selected, safe)

    def test_all_unsafe_candidates_abort_instead_of_publishing(self) -> None:
        tuning = CalibrationConfig(maximum_green_clipping_ratio=0.08)
        unsafe = {
            "exposure": 120,
            "gain": 4,
            "white_balance_temperature": 3500,
            "score": 0.81,
            "rail_found_rate": 1.0,
            "lower_rail_value": 87.0,
            "green_clipping_ratio": 0.2295,
        }
        with self.assertRaisesRegex(RuntimeError, "拒绝覆盖"):
            _select_best_safe_candidate(
                [unsafe],
                tuning,
                stage="test",
            )

    def test_formal_pose_result_is_a_publication_gate(self) -> None:
        tuning = CalibrationConfig(
            minimum_pose_detection_rate=0.8,
            minimum_pose_confidence=0.45,
            maximum_pose_jitter_px=8.0,
            minimum_verification_pose_detection_rate=0.9,
        )
        candidate = {
            "rail_found_rate": 1.0,
            "lower_rail_value": 70.0,
            "green_clipping_ratio": 0.12,
            "pose_detection_rate": 0.6,
            "pose_confidence": 0.8,
            "pose_jitter_px": 2.0,
        }
        self.assertFalse(_camera_candidate_is_safe(candidate, tuning))
        candidate["pose_detection_rate"] = 0.85
        self.assertTrue(_camera_candidate_is_safe(candidate, tuning))
        self.assertFalse(_camera_verification_is_safe(candidate, tuning))
        candidate["pose_detection_rate"] = 0.95
        self.assertTrue(_camera_verification_is_safe(candidate, tuning))

    def test_three_level_path_keeps_zero_gain_when_rail_is_valid(self) -> None:
        config = load_config(
            Path(__file__).resolve().parents[1] / "config" / "pi.toml"
        )

        class Camera:
            capture_fps = 60.0

            def __init__(self) -> None:
                self.applied = []

            def set_manual_controls(self, **controls) -> bool:
                self.applied.append(dict(controls))
                return True

        def candidate(_frames, _config, **controls):
            exposure = controls["exposure"]
            return {
                **controls,
                "score": float(exposure),
                "rail_found_rate": 1.0,
                "lower_rail_value": 70.0,
                "green_clipping_ratio": 0.10,
                "pose_detection_rate": 1.0,
                "pose_confidence": 0.8,
                "pose_jitter_px": 1.0,
            }

        camera = Camera()
        with (
            patch(
                "hball.tasks.calibrate._sample_color_frames",
                return_value=[],
            ),
            patch(
                "hball.tasks.calibrate._evaluate_camera_candidate",
                side_effect=candidate,
            ),
        ):
            _selected, metrics = auto_camera_controls(camera, config, {})
        self.assertFalse(metrics["gain_fallback_used"])
        self.assertFalse(
            any(controls["gain"] > 0 for controls in camera.applied)
        )
        self.assertGreaterEqual(metrics["candidate_count"], 4)


if __name__ == "__main__":
    unittest.main()
