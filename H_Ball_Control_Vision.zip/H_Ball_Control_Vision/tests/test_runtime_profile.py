from pathlib import Path
import unittest

try:
    from hball.algorithms.runtime_profile import resolve_runtime_vision_profile
except ImportError:
    resolve_runtime_vision_profile = None

from hball.common.config import load_config


@unittest.skipUnless(resolve_runtime_vision_profile is not None, "requires OpenCV")
class RuntimeProfileTests(unittest.TestCase):
    def test_profile_uses_merged_config_without_second_loader(self) -> None:
        project = Path(__file__).resolve().parents[1]
        config = load_config(project / "config" / "pi.toml")
        profile = resolve_runtime_vision_profile(config)
        self.assertEqual(profile.mode, "runtime_adaptive")
        self.assertTrue(profile.runtime_geometry_allowed)
        self.assertIs(profile.vision_config, config)
        self.assertIs(profile.camera_config, config.camera)
        self.assertEqual(profile.camera_config.exposure, 80)
        self.assertEqual(profile.camera_config.gain, 0)
        self.assertEqual(profile.camera_config.white_balance_temperature, 4500)


if __name__ == "__main__":
    unittest.main()
