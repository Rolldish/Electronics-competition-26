import unittest

from hball.drivers.protocol import (
    ControlFlags,
    Flags,
    PACKET_SIZE,
    PacketFramer,
    SnapshotTooOldError,
    TaskId,
    Telemetry,
    TxSnapshot,
    crc16_ccitt_false,
    decode_packet,
    encode_packet,
    make_telemetry,
)


class ProtocolTests(unittest.TestCase):
    def test_crc_known_vector(self) -> None:
        self.assertEqual(crc16_ccitt_false(b"123456789"), 0x29B1)

    def test_documented_32_byte_vector(self) -> None:
        source = Telemetry(
            session_id=0x12345678,
            sequence=0x2A,
            capture_timestamp_ms=0x01020304,
            capture_to_send_delay_us=15_000,
            x_0p1mm=500,
            v_mmps=-250,
            confidence_u8=220,
            flags=(
                Flags.BALL_VALID
                | Flags.VELOCITY_VALID
                | Flags.CAMERA_CALIBRATED
            ),
            target_x_0p1mm=500,
            task_id=TaskId.T3,
            control_flags=(
                ControlFlags.CONTROL_ENABLED | ControlFlags.RUN_ACTIVE
            ),
            run_id=42,
        )
        expected = bytes.fromhex(
            "A5 5A 02 10 2A 18 "
            "78 56 34 12 04 03 02 01 98 3A 00 00 "
            "F4 01 06 FF DC 07 F4 01 03 03 2A 00 F0 68"
        )
        packet = encode_packet(source)
        self.assertEqual(len(packet), PACKET_SIZE)
        self.assertEqual(packet, expected)
        self.assertEqual(decode_packet(packet), source)

    def test_round_trip_exposes_physical_unit_properties(self) -> None:
        source = Telemetry(
            session_id=7,
            sequence=255,
            capture_timestamp_ms=99,
            capture_to_send_delay_us=2_500,
            x_0p1mm=-512,
            v_mmps=327,
            confidence_u8=232,
            flags=Flags.BALL_VALID | Flags.VELOCITY_VALID,
            target_x_0p1mm=-500,
            task_id=TaskId.T6,
            control_flags=ControlFlags.CONTROL_ENABLED,
            run_id=0xA55A,
        )
        decoded = decode_packet(encode_packet(source))
        self.assertAlmostEqual(decoded.x_m, -0.0512)
        self.assertAlmostEqual(decoded.v_mps, 0.327)
        self.assertAlmostEqual(decoded.confidence, 232 / 255.0)
        self.assertAlmostEqual(decoded.target_x_m, -0.05)

    def test_make_telemetry_never_sends_prediction_as_measurement(self) -> None:
        source = TxSnapshot(
            capture_timestamp_ns=1_000_000_000,
            flags=Flags.CAMERA_CALIBRATED,
            x_m=0.04,
            v_mps=0.5,
            confidence=0.9,
            target_x_m=0.0,
            task_id=TaskId.T4,
            control_flags=ControlFlags.CONTROL_ENABLED,
            run_id=8,
        )
        message = make_telemetry(
            source,
            session_id=1,
            sequence=2,
            send_timestamp_ns=1_010_000_000,
        )
        self.assertEqual(message.x_0p1mm, 0)
        self.assertEqual(message.v_mmps, 0)
        self.assertEqual(message.confidence_u8, 0)
        self.assertFalse(message.flags & Flags.BALL_VALID)

    def test_old_measurement_becomes_invalid_heartbeat_without_tx_pause(self) -> None:
        source = TxSnapshot(
            capture_timestamp_ns=1_000_000_000,
            flags=(
                Flags.BALL_VALID
                | Flags.VELOCITY_VALID
                | Flags.CAMERA_CALIBRATED
            ),
            x_m=0.01,
            v_mps=0.1,
            confidence=0.9,
            target_x_m=0.0,
            task_id=TaskId.T4,
            control_flags=ControlFlags.CONTROL_ENABLED,
            run_id=8,
        )
        stale = make_telemetry(
            source,
            session_id=1,
            sequence=2,
            send_timestamp_ns=1_071_000_000,
        )
        self.assertFalse(stale.flags & Flags.BALL_VALID)
        self.assertTrue(stale.flags & Flags.PROCESSING_DEGRADED)
        self.assertEqual(stale.x_0p1mm, 0)

        heartbeat = make_telemetry(
            source,
            session_id=1,
            sequence=3,
            send_timestamp_ns=1_078_000_000,
        )
        self.assertEqual(heartbeat.capture_timestamp_ms, 1_000)
        self.assertEqual(heartbeat.capture_to_send_delay_us, 78_000)
        self.assertEqual(heartbeat.x_0p1mm, 0)
        self.assertEqual(heartbeat.v_mmps, 0)
        self.assertEqual(heartbeat.confidence_u8, 0)
        self.assertEqual(
            heartbeat.flags,
            Flags.CAMERA_CALIBRATED | Flags.PROCESSING_DEGRADED,
        )
        self.assertEqual(decode_packet(encode_packet(heartbeat)), heartbeat)
        with self.assertRaises(SnapshotTooOldError):
            make_telemetry(
                source,
                session_id=1,
                sequence=4,
                send_timestamp_ns=1_201_000_000,
            )

    def test_measurement_at_40_ms_keeps_exact_units_and_valid_flags(self) -> None:
        source = TxSnapshot(
            capture_timestamp_ns=1_000_000_000,
            flags=(
                Flags.BALL_VALID
                | Flags.VELOCITY_VALID
                | Flags.CAMERA_CALIBRATED
            ),
            x_m=-0.01004,
            v_mps=0.1236,
            confidence=180 / 255.0,
            target_x_m=0.0,
            task_id=TaskId.T2,
            control_flags=ControlFlags.CONTROL_ENABLED,
            run_id=19,
        )
        message = make_telemetry(
            source,
            session_id=1,
            sequence=2,
            send_timestamp_ns=1_040_000_000,
        )
        self.assertEqual(message.capture_timestamp_ms, 1_000)
        self.assertEqual(message.capture_to_send_delay_us, 40_000)
        self.assertEqual(message.x_0p1mm, -100)
        self.assertEqual(message.v_mmps, 124)
        self.assertEqual(message.confidence_u8, 180)
        self.assertEqual(
            message.flags,
            Flags.BALL_VALID
            | Flags.VELOCITY_VALID
            | Flags.CAMERA_CALIBRATED,
        )
        self.assertEqual(message.target_x_0p1mm, 0)
        self.assertEqual(message.control_flags, ControlFlags.CONTROL_ENABLED)
        self.assertEqual(message.run_id, 19)

    def test_stream_resynchronizes_after_noise_and_bad_crc(self) -> None:
        message = Telemetry(
            session_id=1,
            sequence=7,
            capture_timestamp_ms=99,
            capture_to_send_delay_us=1_000,
            x_0p1mm=0,
            v_mmps=0,
            confidence_u8=0,
            flags=Flags.CAMERA_CALIBRATED,
            target_x_0p1mm=0,
            task_id=TaskId.IDLE,
            control_flags=ControlFlags(0),
            run_id=1,
        )
        good = encode_packet(message)
        bad = bytearray(good)
        bad[15] ^= 0x80
        framer = PacketFramer()
        output = []
        for chunk in (
            b"\x00garbage\xA5",
            bytes(bad),
            b"\x13\x37",
            good[:8],
            good[8:],
        ):
            output.extend(framer.push(chunk))
        self.assertEqual([item.sequence for item in output], [7])


if __name__ == "__main__":
    unittest.main()
