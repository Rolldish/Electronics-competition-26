from dataclasses import dataclass
import unittest

from hball.algorithms.axis_tracker import AxisBallTracker, AxisTrackState
from hball.common.config import TrackerConfig


@dataclass(frozen=True)
class Candidate:
    axis_fraction: float
    radius_px: float = 12.0
    score: float = 0.85
    accepted: bool = True


class AxisBallTrackerTests(unittest.TestCase):
    def test_three_consistent_candidates_acquire(self) -> None:
        tracker = AxisBallTracker(TrackerConfig(acquire_confirm_frames=3))
        estimates = [
            tracker.update(
                (Candidate(0.30 + 0.005 * index),),
                1_000_000_000 + index * 16_666_667,
                600.0,
            )
            for index in range(3)
        ]
        self.assertFalse(estimates[0].track_valid)
        self.assertFalse(estimates[1].track_valid)
        self.assertTrue(estimates[2].track_valid)
        self.assertFalse(estimates[0].control_valid)
        self.assertFalse(estimates[1].control_valid)
        self.assertTrue(estimates[2].control_valid)
        self.assertEqual(estimates[2].state, AxisTrackState.TRACK)

    def test_jumping_candidates_never_acquire(self) -> None:
        tracker = AxisBallTracker(TrackerConfig(acquire_confirm_frames=3))
        estimate = None
        for index, position in enumerate((0.10, 0.80, 0.20, 0.70, 0.05)):
            estimate = tracker.update(
                (Candidate(position),),
                1_000_000_000 + index * 16_666_667,
                600.0,
            )
            self.assertFalse(estimate.track_valid)
        assert estimate is not None
        self.assertEqual(estimate.acquisition_frames, 1)

    def test_far_high_score_cannot_take_over_track(self) -> None:
        tracker = AxisBallTracker(TrackerConfig(acquire_confirm_frames=1))
        tracker.update((Candidate(0.40),), 1_000_000_000, 600.0)
        near = Candidate(0.41, score=0.65)
        far = Candidate(0.85, score=0.99)
        estimate = tracker.update(
            (far, near),
            1_016_666_667,
            600.0,
        )
        self.assertIs(estimate.selected, near)
        self.assertLess(estimate.axis_fraction, 0.50)

    def test_prediction_expires(self) -> None:
        tracker = AxisBallTracker(
            TrackerConfig(
                acquire_confirm_frames=1,
                max_predict_frames=2,
                max_predict_s=0.20,
            )
        )
        tracker.update((Candidate(0.50),), 1_000_000_000, 600.0)
        first = tracker.update((), 1_020_000_000, 600.0)
        second = tracker.update((), 1_040_000_000, 600.0)
        expired = tracker.update((), 1_060_000_000, 600.0)
        self.assertTrue(first.predicted)
        self.assertTrue(second.predicted)
        self.assertFalse(expired.track_valid)
        self.assertEqual(expired.state, AxisTrackState.SEARCH)

    def test_three_frame_median_rejects_one_frame_position_spike(self) -> None:
        tracker = AxisBallTracker(
            TrackerConfig(
                acquire_confirm_frames=1,
                measurement_median_window=3,
            )
        )
        tracker.update((Candidate(0.40),), 1_000_000_000, 600.0)
        tracker.update((Candidate(0.41),), 1_020_000_000, 600.0)
        spike = tracker.update(
            (Candidate(0.47),),
            1_040_000_000,
            600.0,
        )
        self.assertLess(spike.axis_fraction, 0.44)

    def test_large_innovation_waits_for_second_camera_frame(self) -> None:
        tracker = AxisBallTracker(
            TrackerConfig(
                acquire_confirm_frames=1,
                measurement_median_window=3,
                large_innovation_px=28.0,
                large_innovation_consistency_px=48.0,
            )
        )
        tracker.update((Candidate(0.40),), 1_000_000_000, 600.0)
        tracker.update((Candidate(0.41),), 1_020_000_000, 600.0)
        quarantined = tracker.update(
            (Candidate(0.50),),
            1_040_000_000,
            600.0,
        )
        self.assertTrue(quarantined.jump_quarantined)
        self.assertFalse(quarantined.measurement_valid)
        self.assertTrue(quarantined.predicted)

        confirmed = tracker.update(
            (Candidate(0.51),),
            1_060_000_000,
            600.0,
        )
        self.assertFalse(confirmed.jump_quarantined)
        self.assertTrue(confirmed.measurement_valid)
        self.assertGreater(confirmed.axis_fraction, 0.45)

        continuing = tracker.update(
            (Candidate(0.52),),
            1_080_000_000,
            600.0,
        )
        self.assertFalse(continuing.jump_quarantined)
        self.assertTrue(continuing.measurement_valid)

    def test_normal_fast_motion_does_not_enter_jump_quarantine(self) -> None:
        tracker = AxisBallTracker(
            TrackerConfig(
                acquire_confirm_frames=1,
                large_innovation_px=28.0,
            )
        )
        tracker.update((Candidate(0.40),), 1_000_000_000, 600.0)
        estimate = tracker.update(
            (Candidate(0.44),),
            1_033_333_333,
            600.0,
        )
        self.assertFalse(estimate.jump_quarantined)
        self.assertTrue(estimate.measurement_valid)
        for index, position in enumerate((0.48, 0.52, 0.56), start=2):
            estimate = tracker.update(
                (Candidate(position),),
                1_000_000_000 + index * 33_333_333,
                600.0,
            )
            self.assertFalse(estimate.jump_quarantined)
            self.assertTrue(estimate.measurement_valid)


if __name__ == "__main__":
    unittest.main()
