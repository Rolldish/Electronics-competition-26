import unittest

from hball.algorithms.mapping import AxisFractionMapper
from hball.common.config import MappingConfig


class MappingTests(unittest.TestCase):
    def test_fixed_right_negative_left_positive_mapping(self) -> None:
        mapper = AxisFractionMapper.from_config(MappingConfig())
        self.assertAlmostEqual(mapper.position_m(0.0), -0.125)
        self.assertAlmostEqual(mapper.position_m(0.5), 0.0)
        self.assertAlmostEqual(mapper.position_m(1.0), 0.125)
        self.assertAlmostEqual(mapper.velocity_mps(0.5, 1.0), 0.25)

    def test_team_five_point_data_corrects_position_only(self) -> None:
        fractions = (0.096111, 0.274281, 0.461220, 0.670166, 0.888223)
        positions = (-0.100, -0.050, 0.000, 0.050, 0.100)
        mapper = AxisFractionMapper.from_config(
            MappingConfig(
                position_correction_enabled=True,
                position_correction_axis_fractions=fractions,
                position_correction_positions_m=positions,
            )
        )
        for fraction, position in zip(fractions, positions, strict=True):
            with self.subTest(fraction=fraction):
                self.assertAlmostEqual(mapper.position_m(fraction), position)
        self.assertAlmostEqual(mapper.velocity_mps(0.5, 1.0), 0.25)


if __name__ == "__main__":
    unittest.main()
