import unittest
from unittest.mock import patch

from hball.common.config import NetworkConfig
from hball.drivers.network import check_hotspot


def _healthy_output(command: list[str]) -> str:
    if command[0] == "nmcli":
        return "H2026-CAR"
    if command[:2] == ["iw", "dev"]:
        return (
            "Interface wlan1\n"
            "\tssid never give up\n"
            "\ttype AP\n"
            "\tchannel 36 (5180 MHz), width: 80 MHz"
        )
    if command[:3] == ["iw", "reg", "get"]:
        return "global\ncountry CN: DFS-FCC"
    if command[0] == "ip":
        return "7: wlan1 inet 192.168.50.1/24 brd 192.168.50.255"
    raise AssertionError(command)


class NetworkTests(unittest.TestCase):
    @patch("hball.drivers.network._run_text", side_effect=_healthy_output)
    @patch("hball.drivers.network._driver_name", return_value="mt76x2u")
    @patch("hball.drivers.network.Path.exists", return_value=True)
    def test_expected_hotspot_is_ready(
        self,
        _exists,
        _driver,
        _run,
    ) -> None:
        status = check_hotspot(NetworkConfig())
        self.assertTrue(status.ready)
        self.assertTrue(status.ap_mode)
        self.assertTrue(status.address_matches)
        self.assertEqual(status.actual_channel, 36)

    @patch("hball.drivers.network._run_text", side_effect=_healthy_output)
    @patch("hball.drivers.network._driver_name", return_value="mt76x2u")
    @patch("hball.drivers.network.Path.exists", return_value=True)
    def test_wrong_ssid_fails_readiness(
        self,
        _exists,
        _driver,
        _run,
    ) -> None:
        status = check_hotspot(NetworkConfig(ssid="wrong"))
        self.assertFalse(status.ready)
        self.assertFalse(status.ssid_matches)

    @patch("hball.drivers.network._run_text")
    def test_disabled_check_does_not_run_commands(self, run_text) -> None:
        status = check_hotspot(NetworkConfig(enabled=False))
        self.assertTrue(status.ready)
        run_text.assert_not_called()


if __name__ == "__main__":
    unittest.main()
