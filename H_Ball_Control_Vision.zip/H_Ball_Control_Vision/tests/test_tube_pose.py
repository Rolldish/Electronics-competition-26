import unittest

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None

from hball.common.config import MappingConfig, TubePoseConfig
if cv2 is not None:
    from hball.algorithms.tube_pose import (
        RailPoseEstimator,
        TubeRectifier,
        WhiteTubePoseEstimator,
    )


@unittest.skipUnless(cv2 is not None, "OpenCV is an optional Pi dependency")
class TubePoseTests(unittest.TestCase):
    def test_finds_green_u_channel_and_builds_perspective_corners(self) -> None:
        image = np.full((480, 640, 3), 25, dtype=np.uint8)
        box = cv2.boxPoints(((320.0, 240.0), (480.0, 42.0), -7.0)).astype(
            np.int32
        )
        cv2.fillConvexPoly(image, box, (35, 185, 55))
        mapping = MappingConfig(
            negative_point_px=(80.0, 240.0),
            positive_point_px=(560.0, 240.0),
        )
        config = TubePoseConfig(
            method="green_contour",
            update_fps=30.0,
            min_confidence=0.35,
            expected_width_px=42.0,
        )
        pose = RailPoseEstimator(config, mapping).update(
            image, 1_000_000_000, force=True
        )
        self.assertIsNotNone(pose)
        assert pose is not None
        self.assertEqual(pose.source, "GREEN")
        self.assertIsNotNone(pose.corners_px)
        self.assertAlmostEqual(pose.length_px, 480.0, delta=18.0)

        strip, _ = TubeRectifier(config, mapping).rectify(
            cv2.cvtColor(image, cv2.COLOR_BGR2GRAY),
            pose,
        )
        self.assertEqual(strip.shape, (config.rectified_height, 560))

    def test_finds_dark_desaturated_green_u_channel(self) -> None:
        image = np.full((480, 640, 3), 10, dtype=np.uint8)
        box = cv2.boxPoints(((320.0, 240.0), (480.0, 42.0), 5.0)).astype(
            np.int32
        )
        # S is below the normal competition threshold, but green retains a
        # real channel advantage over B/R and should enter the safe fallback.
        cv2.fillConvexPoly(image, box, (24, 40, 27))
        estimator = RailPoseEstimator(
            TubePoseConfig(
                method="green_contour",
                green_s_min=130,
                min_confidence=0.35,
                expected_width_px=42.0,
            ),
            MappingConfig(
                negative_point_px=(80.0, 240.0),
                positive_point_px=(560.0, 240.0),
            ),
        )
        pose = estimator.update(image, 1_000_000_000, force=True)
        self.assertIsNotNone(pose)
        assert pose is not None
        self.assertAlmostEqual(pose.length_px, 480.0, delta=18.0)

    def test_bridges_fixed_bracket_shadow_across_green_rail(self) -> None:
        image = np.full((480, 640, 3), 22, dtype=np.uint8)
        cv2.rectangle(image, (80, 219), (560, 261), (35, 185, 55), -1)
        # Wider than the normal one-ball-diameter close, matching the hard
        # vertical bracket shadow observed on the installed camera image.
        cv2.rectangle(image, (292, 205), (352, 275), (8, 8, 8), -1)
        estimator = RailPoseEstimator(
            TubePoseConfig(
                method="green_contour",
                update_fps=30.0,
                min_confidence=0.35,
                expected_width_px=42.0,
            ),
            MappingConfig(
                negative_point_px=(80.0, 240.0),
                positive_point_px=(560.0, 240.0),
            ),
        )

        pose = estimator.update(image, 1_000_000_000, force=True)

        self.assertIsNotNone(pose)
        assert pose is not None
        self.assertEqual(pose.source, "GREEN_SHADOW_BRIDGE")
        self.assertAlmostEqual(pose.length_px, 480.0, delta=18.0)
        self.assertTrue(estimator.last_diagnostics["shadow_bridge_used"])

    def test_shadow_bridge_does_not_join_short_green_objects(self) -> None:
        image = np.full((480, 640, 3), 22, dtype=np.uint8)
        cv2.rectangle(image, (180, 220), (290, 260), (35, 185, 55), -1)
        cv2.rectangle(image, (350, 220), (460, 260), (35, 185, 55), -1)
        estimator = RailPoseEstimator(
            TubePoseConfig(
                method="green_contour",
                update_fps=30.0,
                min_confidence=0.35,
                expected_width_px=42.0,
            ),
            MappingConfig(
                negative_point_px=(80.0, 240.0),
                positive_point_px=(560.0, 240.0),
            ),
        )

        pose = estimator.update(image, 1_000_000_000, force=True)

        self.assertIsNone(pose)
        self.assertFalse(estimator.last_diagnostics["shadow_bridge_used"])

    def test_finds_unmarked_white_tube_and_rectifies_axis(self) -> None:
        image = np.full((480, 640), 25, dtype=np.uint8)
        box = cv2.boxPoints(((320.0, 240.0), (480.0, 24.0), 8.0)).astype(
            np.int32
        )
        cv2.fillConvexPoly(image, box, 235)
        mapping = MappingConfig(
            negative_point_px=(80.0, 240.0),
            positive_point_px=(560.0, 240.0),
        )
        config = TubePoseConfig(
            update_fps=30.0,
            min_brightness=150,
            min_confidence=0.35,
        )
        estimator = WhiteTubePoseEstimator(config, mapping)
        pose = estimator.update(image, 1_000_000_000, force=True)
        self.assertIsNotNone(pose)
        assert pose is not None
        self.assertGreater(pose.confidence, 0.35)
        self.assertAlmostEqual(pose.length_px, 480.0, delta=12.0)

        rectifier = TubeRectifier(config, mapping)
        strip, _ = rectifier.rectify(image, pose)
        self.assertEqual(strip.shape[0], config.rectified_height)
        center_row = strip[config.rectified_height // 2]
        self.assertGreater(float(np.mean(center_row[50:-50])), 180.0)

    def test_rejects_short_white_object(self) -> None:
        image = np.full((480, 640), 20, dtype=np.uint8)
        cv2.rectangle(image, (250, 200), (390, 235), 240, -1)
        estimator = WhiteTubePoseEstimator(
            TubePoseConfig(min_confidence=0.35),
            MappingConfig(),
        )
        self.assertIsNone(
            estimator.update(image, 1_000_000_000, force=True)
        )


if __name__ == "__main__":
    unittest.main()
