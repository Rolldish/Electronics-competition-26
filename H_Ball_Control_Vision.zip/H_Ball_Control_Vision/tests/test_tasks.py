import unittest

from hball.common.config import TaskConfig
from hball.drivers.protocol import ControlFlags, TaskId
from hball.tasks.controller import BallTaskController, TaskPhase


class TaskTests(unittest.TestCase):
    def test_t3_requires_ready_and_completes_after_negative_settle(self) -> None:
        config = TaskConfig(
            positive_reached_hold_s=0.02,
            final_hold_s=0.05,
            ready_hold_s=0.02,
        )
        task = BallTaskController(config, TaskId.T3, run_id=7)
        base = 1_000_000_000
        preparing = task.update(
            base,
            x_m=0.0,
            v_mps=0.0,
            track_valid=True,
            confidence=0.9,
        )
        self.assertEqual(preparing.phase, TaskPhase.PREPARE)
        ready = task.update(
            base + 30_000_000,
            x_m=0.0,
            v_mps=0.0,
            track_valid=True,
            confidence=0.9,
        )
        self.assertEqual(ready.phase, TaskPhase.READY)
        self.assertTrue(task.start(base + 30_000_000, track_valid=True))
        task.update(
            base + 40_000_000,
            x_m=0.046,
            v_mps=0.1,
            track_valid=True,
            confidence=0.9,
        )
        outbound = task.update(
            base + 70_000_000,
            x_m=0.047,
            v_mps=0.1,
            track_valid=True,
            confidence=0.9,
        )
        self.assertEqual(outbound.phase, TaskPhase.TO_NEGATIVE)
        task.update(
            base + 90_000_000,
            x_m=-0.049,
            v_mps=0.01,
            track_valid=True,
            confidence=0.9,
        )
        done = task.update(
            base + 150_000_000,
            x_m=-0.050,
            v_mps=0.0,
            track_valid=True,
            confidence=0.9,
        )
        self.assertEqual(done.phase, TaskPhase.DONE)
        self.assertTrue(done.control_flags & ControlFlags.TASK_DONE)
        self.assertTrue(done.control_flags & ControlFlags.CONTROL_ENABLED)

    def test_t6_uses_oled_selected_target_and_waits_for_ready(self) -> None:
        config = TaskConfig(ready_hold_s=0.10)
        task = BallTaskController(
            config,
            TaskId.T6,
            run_id=9,
            target_x_m=0.03,
        )
        base = 2_000_000_000
        status = None
        for index in range(8):
            status = task.update(
                base + index * 20_000_000,
                x_m=0.030 + (index % 2) * 0.0002,
                v_mps=0.005,
                track_valid=True,
                confidence=0.9,
            )
        assert status is not None
        self.assertEqual(status.phase, TaskPhase.READY)
        self.assertAlmostEqual(status.target_x_m, 0.03, places=4)
        self.assertTrue(status.control_flags & ControlFlags.TARGET_LATCHED)
        self.assertFalse(status.control_flags & ControlFlags.RUN_ACTIVE)
        self.assertTrue(
            task.start(base + 160_000_000, track_valid=True)
        )
        started = task.status(base + 160_000_000, 0.03)
        self.assertEqual(started.phase, TaskPhase.HOLD)
        self.assertTrue(started.control_flags & ControlFlags.RUN_ACTIVE)

    def test_idle_never_enables_control(self) -> None:
        task = BallTaskController(TaskConfig(), TaskId.IDLE, run_id=1)
        status = task.update(
            1,
            x_m=0.0,
            v_mps=0.0,
            track_valid=True,
            confidence=1.0,
        )
        self.assertEqual(status.control_flags, ControlFlags(0))


if __name__ == "__main__":
    unittest.main()
