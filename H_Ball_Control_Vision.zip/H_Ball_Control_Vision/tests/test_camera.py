import unittest

from hball.threads.camera import LatestMjpegCamera


class CameraFailureHintTests(unittest.TestCase):
    def test_busy_device_hint(self) -> None:
        hint = LatestMjpegCamera._failure_hint(
            "VIDIOC_STREAMON returned -1 (Device or resource busy)"
        )
        self.assertIn("其他进程占用", hint)

    def test_missing_device_hint(self) -> None:
        hint = LatestMjpegCamera._failure_hint("Cannot open device /dev/video0")
        self.assertIn("设备不存在", hint)

    def test_unsupported_mode_hint(self) -> None:
        hint = LatestMjpegCamera._failure_hint("VIDIOC_S_FMT: Invalid argument")
        self.assertIn("分辨率", hint)

    def test_usb_io_hint(self) -> None:
        hint = LatestMjpegCamera._failure_hint("VIDIOC_DQBUF: Input/output error")
        self.assertIn("USB", hint)


if __name__ == "__main__":
    unittest.main()
