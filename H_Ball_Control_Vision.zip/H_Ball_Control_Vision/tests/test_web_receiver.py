import re
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = PROJECT_ROOT / "web"


class WebReceiverTests(unittest.TestCase):
    def test_field_page_contains_h_problem_admission_and_recording(self) -> None:
        html = (WEB_ROOT / "index.html").read_text(encoding="utf-8")
        for text in (
            "2026 电赛 H 题",
            "闭环",
            "发送时龄",
            "真实测量",
            "车尾为正 / 车头为负",
            "本机比赛录像",
            "只读接收端",
        ):
            with self.subTest(text=text):
                self.assertIn(text, html)

    def test_every_javascript_element_id_exists(self) -> None:
        html = (WEB_ROOT / "index.html").read_text(encoding="utf-8")
        script = (WEB_ROOT / "app.js").read_text(encoding="utf-8")
        ids = set(re.findall(r'byId\("([^"]+)"\)', script))
        missing = sorted(
            element_id
            for element_id in ids
            if f'id="{element_id}"' not in html
        )
        self.assertEqual(missing, [])

    def test_receiver_keeps_frozen_safety_thresholds_and_read_only_role(self) -> None:
        script = (WEB_ROOT / "app.js").read_text(encoding="utf-8")
        html = (WEB_ROOT / "index.html").read_text(encoding="utf-8")
        self.assertIn("const BALL_CONFIDENCE_MIN = 180 / 255;", script)
        self.assertIn("const MEASUREMENT_MAX_AGE_MS = 77;", script)
        self.assertIn('fetch(`/status.json?t=', script)
        self.assertNotRegex(script, r'fetch\([^)]*method\s*:\s*["\']POST')
        self.assertNotIn("/command", script)
        self.assertIn("不向小车发送任何控制命令", html)

    def test_hidden_record_canvas_only_runs_while_recording(self) -> None:
        script = (WEB_ROOT / "app.js").read_text(encoding="utf-8")
        initialize = script.split("async function initialize()", 1)[1]
        self.assertNotIn("beginCanvasDrawing();", initialize)
        self.assertIn("function endCanvasDrawing()", script)
        self.assertIn("endCanvasDrawing();", script)


if __name__ == "__main__":
    unittest.main()
