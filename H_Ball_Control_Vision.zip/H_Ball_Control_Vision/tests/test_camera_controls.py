import tempfile
import unittest
from pathlib import Path

from hball.common.camera_controls import (
    load_camera_controls,
    publish_camera_controls,
)
from hball.common.config import load_config


class CameraControlsTests(unittest.TestCase):
    def test_publish_and_load(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "camera_controls.json"
            expected = {
                "exposure": 140,
                "gain": 8,
                "white_balance_temperature": 4750,
            }
            publish_camera_controls(
                path,
                expected,
                created_at_utc="2026-08-01T00:00:00+00:00",
                metrics={"selected_score": 0.9},
            )
            self.assertEqual(load_camera_controls(path), expected)

    def test_load_config_applies_saved_controls_to_all_consumers(self) -> None:
        project = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_dir = root / "config"
            config_dir.mkdir()
            config_path = config_dir / "pi.toml"
            config_path.write_text(
                (project / "config" / "pi.toml").read_text(encoding="utf-8"),
                encoding="utf-8",
            )
            controls = {
                "exposure": 157,
                "gain": 12,
                "white_balance_temperature": 4250,
            }
            publish_camera_controls(
                root / "calibration" / "camera_controls.json",
                controls,
                created_at_utc="2026-08-01T00:00:00+00:00",
                metrics={},
            )
            loaded = load_config(config_path)
            self.assertEqual(loaded.camera.exposure, 157)
            self.assertEqual(loaded.camera.gain, 12)
            self.assertEqual(loaded.camera.white_balance_temperature, 4250)
            self.assertFalse(loaded.camera.auto_exposure)
            self.assertFalse(loaded.camera.auto_white_balance)
            self.assertEqual(
                loaded.camera_controls_source,
                "CURRENT_ENVIRONMENT",
            )


if __name__ == "__main__":
    unittest.main()
