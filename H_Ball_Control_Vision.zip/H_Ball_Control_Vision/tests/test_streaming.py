import json
import time
import unittest
import urllib.request

from hball.common.config import VideoConfig
from hball.threads.camera import MjpegSnapshot
from hball.threads.streaming import PassthroughVideoServer, PublishedVideoServer


class _FakeCamera:
    def __init__(self, snapshot: MjpegSnapshot) -> None:
        self.snapshot = snapshot

    def latest(self) -> MjpegSnapshot:
        return self.snapshot


class StreamingTests(unittest.TestCase):
    def test_video_backs_off_until_control_timing_recovers(self) -> None:
        jpeg = b"\xff\xd8camera-payload\xff\xd9"
        camera = _FakeCamera(MjpegSnapshot(1, 123, jpeg))
        status = {
            "node_mode": "TASK",
            "control_realtime_ready": False,
            "video_full_rate_safe": False,
        }
        server = PassthroughVideoServer(
            camera,  # type: ignore[arg-type]
            VideoConfig(
                enabled=True,
                bind="127.0.0.1",
                port=0,
                fps=20.0,
                degraded_fps=10.0,
                recovery_hold_s=0.05,
            ),
            lambda: dict(status),
        )
        server.start()
        try:
            deadline = time.monotonic() + 0.5
            while server.effective_fps != 10.0 and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertEqual(server.effective_fps, 10.0)

            status["control_realtime_ready"] = True
            status["video_full_rate_safe"] = True
            deadline = time.monotonic() + 0.6
            while server.effective_fps != 20.0 and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertEqual(server.effective_fps, 20.0)
        finally:
            server.close()

    def test_snapshot_is_original_jpeg_bytes(self) -> None:
        jpeg = b"\xff\xd8original-camera-payload\xff\xd9"
        camera = _FakeCamera(MjpegSnapshot(3, 123, jpeg))
        server = PassthroughVideoServer(
            camera,  # type: ignore[arg-type]
            VideoConfig(enabled=True, bind="127.0.0.1", port=0, fps=30.0),
            lambda: {"state": "TRACK"},
        )
        server.start()
        try:
            deadline = time.monotonic() + 1.0
            while server.hub.latest() is None and time.monotonic() < deadline:
                time.sleep(0.01)
            assert server.bound_port is not None
            base = f"http://127.0.0.1:{server.bound_port}"
            with urllib.request.urlopen(base + "/snapshot.jpg", timeout=2.0) as response:
                self.assertEqual(response.read(), jpeg)
            with urllib.request.urlopen(base + "/status.json", timeout=2.0) as response:
                self.assertEqual(json.loads(response.read()), {"state": "TRACK"})
            with urllib.request.urlopen(base + "/", timeout=2.0) as response:
                page = response.read().decode("utf-8")
                self.assertIn("2026 电赛 H 题 · 图像接收台", page)
                self.assertIn("/stream.mjpg", page)
                self.assertIn(
                    "default-src 'self'",
                    response.headers["Content-Security-Policy"],
                )
            with urllib.request.urlopen(base + "/app.js", timeout=2.0) as response:
                script = response.read().decode("utf-8")
                self.assertIn("reconcileAutomaticRecording", script)
                self.assertIn("indexedDB", script)
            with urllib.request.urlopen(
                base + "/manifest.webmanifest", timeout=2.0
            ) as response:
                manifest = json.loads(response.read())
                self.assertEqual(manifest["display"], "standalone")
        finally:
            server.close()

    def test_debug_publisher_serves_annotated_jpeg_and_status(self) -> None:
        jpeg = b"\xff\xd8debug-overlay-payload\xff\xd9"
        server = PublishedVideoServer(
            "127.0.0.1",
            0,
            lambda: {"state": "TRACK", "ball_diameter_m": 0.01},
        )
        server.start()
        try:
            server.publish(9, 456, jpeg)
            assert server.bound_port is not None
            base = f"http://127.0.0.1:{server.bound_port}"
            with urllib.request.urlopen(base + "/snapshot.jpg", timeout=2.0) as response:
                self.assertEqual(response.read(), jpeg)
            with urllib.request.urlopen(base + "/status.json", timeout=2.0) as response:
                self.assertEqual(
                    json.loads(response.read()),
                    {"state": "TRACK", "ball_diameter_m": 0.01},
                )
        finally:
            server.close()


if __name__ == "__main__":
    unittest.main()
