import unittest
from types import SimpleNamespace

from hball.drivers.protocol import Flags
from hball.threads.node import _flags


class NodeRealtimeFlagsTests(unittest.TestCase):
    def test_processing_over_budget_cannot_keep_ball_valid(self) -> None:
        estimate = SimpleNamespace(control_valid=True, confidence=0.9)
        flags = _flags(
            estimate,
            pose_valid=True,
            calibration_ready=True,
            minimum_confidence=180 / 255.0,
            processing_degraded=True,
        )
        self.assertTrue(flags & Flags.CAMERA_CALIBRATED)
        self.assertTrue(flags & Flags.PROCESSING_DEGRADED)
        self.assertFalse(flags & Flags.BALL_VALID)
        self.assertFalse(flags & Flags.VELOCITY_VALID)

    def test_fresh_result_keeps_normal_valid_flags(self) -> None:
        estimate = SimpleNamespace(control_valid=True, confidence=0.9)
        flags = _flags(
            estimate,
            pose_valid=True,
            calibration_ready=True,
            minimum_confidence=180 / 255.0,
            processing_degraded=False,
        )
        self.assertEqual(
            flags,
            Flags.BALL_VALID
            | Flags.VELOCITY_VALID
            | Flags.CAMERA_CALIBRATED,
        )


if __name__ == "__main__":
    unittest.main()
