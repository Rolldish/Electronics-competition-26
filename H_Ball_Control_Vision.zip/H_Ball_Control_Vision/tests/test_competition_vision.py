from __future__ import annotations

import unittest
from dataclasses import replace
from pathlib import Path

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None

from hball.common.config import load_config

if cv2 is not None:
    from hball.algorithms.competition_vision import CompetitionRailVision


@unittest.skipUnless(cv2 is not None, "requires OpenCV and NumPy")
class CompetitionRailVisionTests(unittest.TestCase):
    def setUp(self) -> None:
        project = Path(__file__).resolve().parents[1]
        base = load_config(project / "config" / "pi.toml")
        self.config = replace(
            base,
            runtime=replace(
                base.runtime,
                startup_background_frames=5,
                startup_background_max_attempts=30,
            ),
        )
        self.pipeline = CompetitionRailVision(self.config)

    @staticmethod
    def _scene(with_ball: bool) -> np.ndarray:
        image = np.full((480, 640, 3), 24, dtype=np.uint8)
        cv2.rectangle(image, (40, 198), (600, 282), (40, 170, 50), -1)
        if with_ball:
            cv2.circle(
                image,
                (320, 240),
                12,
                (220, 220, 220),
                -1,
                cv2.LINE_AA,
            )
            cv2.circle(
                image,
                (316, 236),
                3,
                (250, 250, 250),
                -1,
                cv2.LINE_AA,
            )
        return image

    def test_background_blocks_control_then_three_frames_acquire(self) -> None:
        timestamp = 1_000_000_000
        frame = None
        for index in range(5):
            frame = self.pipeline.process(
                self._scene(False),
                timestamp + index * 16_666_667,
            )
            self.assertFalse(frame.estimate.control_valid)
        assert frame is not None
        self.assertTrue(frame.background_ready)
        self.assertFalse(frame.pose_valid)

        empty = self.pipeline.process(
            self._scene(False),
            timestamp + 5 * 16_666_667,
        )
        self.assertTrue(empty.pose_valid)
        self.assertEqual(empty.pose.source, "BACKGROUND_LOCKED")
        self.assertEqual(
            0,
            0 if empty.result is None else len(empty.result.accepted),
        )
        self.assertFalse(empty.estimate.control_valid)

        estimates = []
        for index in range(6, 9):
            estimates.append(
                self.pipeline.process(
                    self._scene(True),
                    timestamp + index * 16_666_667,
                ).estimate
            )
        self.assertFalse(estimates[0].control_valid)
        self.assertFalse(estimates[1].control_valid)
        self.assertTrue(estimates[2].control_valid)

    def test_locked_geometry_survives_moving_shadow_and_tracks_ball(self) -> None:
        timestamp = 2_000_000_000
        for index in range(5):
            self.pipeline.process(
                self._scene(False),
                timestamp + index * 16_666_667,
            )

        shadowed = self._scene(True)
        region = shadowed[190:291, 255:386].astype(np.float32)
        shadowed[190:291, 255:386] = np.clip(
            region * 0.42,
            0,
            255,
        ).astype(np.uint8)
        frames = [
            self.pipeline.process(
                shadowed,
                timestamp + index * 16_666_667,
            )
            for index in range(5, 8)
        ]

        self.assertTrue(all(frame.pose_valid for frame in frames))
        self.assertTrue(
            all(frame.pose.source == "BACKGROUND_LOCKED" for frame in frames)
        )
        self.assertTrue(frames[-1].estimate.control_valid)

    def test_background_retries_without_weakening_pose_gate(self) -> None:
        config = replace(
            self.config,
            runtime=replace(
                self.config.runtime,
                startup_background_frames=5,
                startup_background_max_attempts=5,
                startup_background_retry_limit=1,
            ),
        )
        pipeline = CompetitionRailVision(config)
        blank = np.zeros((480, 640, 3), dtype=np.uint8)
        timestamp = 3_000_000_000
        for index in range(5):
            frame = pipeline.process(
                blank,
                timestamp + index * 16_666_667,
            )
        self.assertFalse(frame.background_failed)
        self.assertEqual(frame.background_retry_count, 1)
        self.assertEqual(frame.background_frames, 0)
        for index in range(5, 10):
            frame = pipeline.process(
                blank,
                timestamp + index * 16_666_667,
            )
        self.assertTrue(frame.background_failed)


if __name__ == "__main__":
    unittest.main()
