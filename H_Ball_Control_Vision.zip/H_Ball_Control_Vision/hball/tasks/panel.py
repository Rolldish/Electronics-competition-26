"""0.96-inch OLED and one-button supervisor for the persistent Pi node."""

from __future__ import annotations

import argparse
import json
import logging
import os
import queue
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from hball.common.config import AppConfig, load_config
from hball.drivers.oled import SSD1306


LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class MenuEntry:
    label: str
    kind: str
    command: str = ""
    module: str = ""
    arguments: tuple[str, ...] = ()
    status_port: int | None = 8080
    formal_task: bool = False
    interaction: str = "none"


MENU = (
    MenuEntry("VIDEO CHECK", "runtime", "VIDEO"),
    MenuEntry("T2 O HOLD", "runtime", "TASK T2", formal_task=True),
    MenuEntry("T3 +5>-5", "runtime", "TASK T3", formal_task=True),
    MenuEntry("T4 AB@O", "runtime", "TASK T4", formal_task=True),
    MenuEntry("T5 LAP@O", "runtime", "TASK T5", formal_task=True),
    MenuEntry(
        "T6 LAP@X",
        "runtime",
        "TASK T6",
        formal_task=True,
        interaction="target",
    ),
    MenuEntry(
        "FIELD TUNE",
        "exclusive",
        module="hball.tasks.calibrate",
        arguments=("--auto-start",),
        status_port=8080,
        interaction="setup",
    ),
    MenuEntry(
        "READY CHECK",
        "runtime",
        "CHECK",
        interaction="setup",
    ),
    MenuEntry("LINK TEST", "runtime", "IDLE", interaction="link"),
)


class OledMenuRenderer:
    def __init__(self, display: SSD1306) -> None:
        try:
            from PIL import Image, ImageDraw, ImageFont
        except ImportError as error:
            raise RuntimeError("OLED 菜单需要 Pillow") from error
        self.Image = Image
        self.ImageDraw = ImageDraw
        self.font = ImageFont.load_default()
        self.display = display

    def menu(self, selected: int) -> None:
        image = self.Image.new("1", (128, 64), 0)
        draw = self.ImageDraw.Draw(image)
        draw.text((2, 0), "H-BALL S:NEXT L:GO", fill=1, font=self.font)
        first = max(0, min(selected - 2, len(MENU) - 5))
        for row, index in enumerate(range(first, min(first + 5, len(MENU)))):
            marker = ">" if index == selected else " "
            draw.text(
                (2, 12 + row * 10),
                f"{marker}{index + 1:02d} {MENU[index].label[:15]}",
                fill=1,
                font=self.font,
            )
        self.display.show(image)

    def target(self, value_cm: int) -> None:
        image = self.Image.new("1", (128, 64), 0)
        draw = self.ImageDraw.Draw(image)
        draw.text((2, 2), "T6 TARGET POSITION", fill=1, font=self.font)
        draw.text((25, 21), f"{value_cm:+3d} cm", fill=1, font=self.font)
        draw.text((2, 43), "SHORT: +1 cm", fill=1, font=self.font)
        draw.text((2, 53), "HOLD: CONFIRM", fill=1, font=self.font)
        self.display.show(image)

    def running(
        self,
        entry: MenuEntry,
        elapsed_s: float,
        status: dict | None,
    ) -> None:
        image = self.Image.new("1", (128, 64), 0)
        draw = self.ImageDraw.Draw(image)
        draw.text((1, 0), entry.label[:19], fill=1, font=self.font)
        if status and entry.interaction == "setup":
            phase = str(status.get("setup_phase", "STARTING"))
            if phase == "CAMERA":
                draw.text((1, 13), "REMOVE STEEL BALL", fill=1, font=self.font)
                draw.text(
                    (1, 27),
                    str(status.get("setup_oled_display", "CAMERA AUTO"))[:20],
                    fill=1,
                    font=self.font,
                )
                draw.text((1, 42), "HANDS/LIGHT STILL", fill=1, font=self.font)
            elif phase == "BACKGROUND":
                captured = int(status.get("registered_background_frames", 0))
                required = int(status.get("registered_background_required", 30))
                retry = int(status.get("registered_background_retry_count", 0))
                retry_limit = int(status.get("registered_background_retry_limit", 0))
                draw.text((1, 13), "KEEP RAIL EMPTY", fill=1, font=self.font)
                draw.text((1, 27), f"BACKGROUND {captured:02d}/{required:02d}", fill=1, font=self.font)
                draw.text((1, 41), f"RETRY {retry}/{retry_limit}", fill=1, font=self.font)
            elif phase == "EMPTY_CHECK":
                current = int(status.get("setup_empty_consecutive", 0))
                required = int(status.get("setup_empty_required", 20))
                draw.text((1, 14), "KEEP RAIL EMPTY", fill=1, font=self.font)
                draw.text((1, 31), f"VERIFY {current:02d}/{required:02d}", fill=1, font=self.font)
            elif phase == "PLACE_BALL":
                current = int(status.get("setup_ball_consecutive", 0))
                required = int(status.get("setup_ball_required", 10))
                draw.text((1, 14), "PLACE STEEL BALL", fill=1, font=self.font)
                draw.text((1, 31), f"VALID {current:02d}/{required:02d}", fill=1, font=self.font)
            elif phase == "PASSED":
                draw.text((1, 15), "SETUP PASSED", fill=1, font=self.font)
                draw.text((1, 31), "VISION READY", fill=1, font=self.font)
            elif phase == "FAILED":
                draw.text((1, 15), "SETUP FAILED", fill=1, font=self.font)
                draw.text((1, 31), "CHECK IMAGE/LIGHT", fill=1, font=self.font)
            else:
                draw.text((1, 20), "SETUP STARTING", fill=1, font=self.font)
            draw.text((1, 53), "HOLD: BACK", fill=1, font=self.font)
        elif status and status.get("registered_background_failed"):
            draw.text((1, 13), "BACKGROUND FAILED", fill=1, font=self.font)
            draw.text((1, 27), "CHECK GREEN RAIL", fill=1, font=self.font)
            draw.text((1, 40), "REMOVE BALL/RESTART", fill=1, font=self.font)
            draw.text((1, 53), "HOLD: BACK", fill=1, font=self.font)
        elif status and not status.get(
            "registered_background_ready",
            True,
        ):
            captured = int(
                status.get("registered_background_frames", 0)
            )
            required = int(
                status.get("registered_background_required", 30)
            )
            draw.text((1, 13), "REMOVE STEEL BALL", fill=1, font=self.font)
            draw.text(
                (1, 28),
                f"BACKGROUND {captured:02d}/{required:02d}",
                fill=1,
                font=self.font,
            )
            draw.text((1, 43), "KEEP LIGHT STILL", fill=1, font=self.font)
            draw.text((1, 53), "HOLD: BACK", fill=1, font=self.font)
        elif status and status.get("calibration_ready") is False:
            draw.text((1, 15), "CALIBRATION NEEDED", fill=1, font=self.font)
            draw.text((1, 29), "RESTART BACKGROUND", fill=1, font=self.font)
            draw.text((1, 50), "HOLD: BACK", fill=1, font=self.font)
        elif status and "task_phase" in status:
            phase = str(status.get("task_phase", "--"))[:12]
            x_cm = float(status.get("x_m", 0.0)) * 100.0
            target_cm = float(status.get("target_x_m", 0.0)) * 100.0
            confidence = float(status.get("confidence", 0.0))
            pose = float(status.get("tube_pose_confidence", 0.0))
            uart_tx = "OK" if status.get("uart_tx_open") else "ERR"
            draw.text((1, 11), f"{phase} TX:{uart_tx}", fill=1, font=self.font)
            draw.text(
                (1, 21),
                f"X{x_cm:+5.1f} T{target_cm:+5.1f}",
                fill=1,
                font=self.font,
            )
            draw.text(
                (1, 31),
                f"BALL {confidence:.2f} RAIL {pose:.2f}",
                fill=1,
                font=self.font,
            )
            draw.text(
                (1, 41),
                f"TIME {float(status.get('task_elapsed_s', 0.0)):5.2f}s",
                fill=1,
                font=self.font,
            )
            if entry.formal_task:
                hint = (
                    "SHORT:START HOLD:BACK"
                    if phase == "READY"
                    else "WAIT READY  HOLD:BACK"
                )
            elif entry.interaction == "link":
                count = int(
                    status.get("balllink_serial_packet_count", 0)
                )
                hint = f"TX FRAMES {count}"
            else:
                hint = "HOLD: BACK"
            draw.text((1, 52), hint[:21], fill=1, font=self.font)
        elif status:
            state = str(status.get("state", "RUNNING"))[:19]
            stage = str(
                status.get(
                    "oled_display",
                    status.get("group", status.get("display", "")),
                )
            )[:19]
            draw.text((1, 15), state, fill=1, font=self.font)
            draw.text((1, 29), stage, fill=1, font=self.font)
            hint = (
                "SHORT:NEXT HOLD:STOP"
                if entry.interaction == "next"
                else "HOLD:STOP"
            )
            draw.text((1, 50), hint, fill=1, font=self.font)
        else:
            draw.text((2, 20), f"RUN {elapsed_s:6.1f}s", fill=1, font=self.font)
            draw.text((2, 48), "HOLD: STOP/BACK", fill=1, font=self.font)
        self.display.show(image)

    def message(self, line1: str, line2: str = "") -> None:
        image = self.Image.new("1", (128, 64), 0)
        draw = self.ImageDraw.Draw(image)
        draw.text((2, 12), line1[:20], fill=1, font=self.font)
        draw.text((2, 30), line2[:20], fill=1, font=self.font)
        self.display.show(image)


def _put_latest(events: queue.Queue[str], value: str) -> None:
    try:
        if events.full():
            events.get_nowait()
        events.put_nowait(value)
    except queue.Full:
        pass


def _open_button(config: AppConfig, events: queue.Queue[str]):
    try:
        from gpiozero import Button
    except ImportError as error:
        raise RuntimeError(
            "OLED 面板按键需要 gpiozero: sudo apt install python3-gpiozero"
        ) from error
    button = Button(
        config.panel.button_gpio,
        pull_up=True,
        hold_time=config.panel.button_hold_s,
        bounce_time=config.panel.button_bounce_s,
    )
    state = {"held": False}

    def pressed() -> None:
        state["held"] = False

    def held() -> None:
        state["held"] = True
        _put_latest(events, "long")

    def released() -> None:
        if not state["held"]:
            _put_latest(events, "short")

    button.when_pressed = pressed
    button.when_held = held
    button.when_released = released
    return button


def _start_process(
    module: str,
    arguments: tuple[str, ...],
    config_path: Path,
) -> subprocess.Popen:
    command = [
        sys.executable,
        "-m",
        module,
        *arguments,
        "--config",
        str(config_path),
    ]
    LOG.info("starting: %s", command)
    return subprocess.Popen(
        command,
        cwd=str(config_path.parent.parent),
        stdin=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )


def _start_node(config_path: Path) -> subprocess.Popen:
    return _start_process("hball.threads.node", ("--task", "idle"), config_path)


def _send_command(process: subprocess.Popen | None, command: str) -> bool:
    if process is None or process.stdin is None or process.poll() is not None:
        return False
    try:
        process.stdin.write(command + "\n")
        process.stdin.flush()
        return True
    except (BrokenPipeError, OSError):
        return False


def _fetch_status(port: int | None) -> dict | None:
    if port is None:
        return None
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/status.json",
            timeout=0.08,
        ) as response:
            value = json.loads(response.read().decode("utf-8"))
        return value if isinstance(value, dict) else None
    except (
        OSError,
        ValueError,
        urllib.error.URLError,
        TimeoutError,
    ):
        return None


def _stop_process(process: subprocess.Popen | None) -> None:
    if process is None or process.poll() is not None:
        return
    try:
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGINT)
        else:
            process.send_signal(signal.CTRL_BREAK_EVENT)
        process.wait(timeout=3.0)
        return
    except (ProcessLookupError, subprocess.TimeoutExpired, ValueError):
        pass
    try:
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            process.terminate()
        process.wait(timeout=2.0)
        return
    except (ProcessLookupError, subprocess.TimeoutExpired):
        pass
    if os.name == "posix":
        os.killpg(process.pid, signal.SIGKILL)
    else:
        process.kill()
    process.wait(timeout=1.0)


def run(config_path: str) -> None:
    config = load_config(config_path)
    display = SSD1306(
        bus_index=config.panel.i2c_bus,
        address=config.panel.oled_address,
    )
    renderer = OledMenuRenderer(display)
    events: queue.Queue[str] = queue.Queue(maxsize=5)
    button = _open_button(config, events)
    selected = 0
    active_entry: MenuEntry | None = None
    exclusive: subprocess.Popen | None = None
    node: subprocess.Popen | None = None
    task_started = 0.0
    next_render = 0.0
    t6_target_cm: int | None = None
    awaiting_node_restart = False

    renderer.message("REMOVE STEEL BALL", "BG STARTS IN 2S")
    time.sleep(2.0)
    renderer.message("STARTING", "CAMERA / UART")
    node = _start_node(config.path)
    time.sleep(0.4)
    renderer.menu(selected)
    try:
        while True:
            now = time.monotonic()
            if node is not None and node.poll() is not None and exclusive is None:
                LOG.error("persistent node exited with %s", node.returncode)
                node = None

            if exclusive is not None and exclusive.poll() is not None:
                code = exclusive.returncode
                calibration_completed = (
                    active_entry is not None
                    and active_entry.module == "hball.tasks.calibrate"
                )
                if calibration_completed and code == 0:
                    # Camera tuning is atomically saved and read back. Restart
                    # immediately so adaptive runtime applies it before the
                    # 30-frame empty-rail background is sampled.
                    renderer.message("CAMERA READY", "RESTART VISION")
                    LOG.info("field tuning passed; restarting adaptive vision")
                    exclusive = None
                    active_entry = None
                    node = _start_node(config.path)
                    time.sleep(0.4)
                    awaiting_node_restart = False
                    renderer.menu(selected)
                    continue
                else:
                    renderer.message(
                        "TASK PASSED" if code == 0 else "TASK FAILED",
                        f"EXIT {code}",
                    )
                LOG.info("exclusive task exit=%s", code)
                exclusive = None
                active_entry = None
                time.sleep(0.8)
                awaiting_node_restart = True
                renderer.message("REMOVE STEEL BALL", "PRESS: RESTART")
            elif active_entry is not None and now >= next_render:
                status = _fetch_status(active_entry.status_port)
                renderer.running(active_entry, now - task_started, status)
                next_render = now + 0.25

            try:
                event = events.get(timeout=0.08)
            except queue.Empty:
                continue

            if awaiting_node_restart:
                renderer.message("REMOVE STEEL BALL", "PRESS: RESTART")
                if event in {"short", "long"}:
                    renderer.message("RESTARTING", "BACKGROUND 30F")
                    node = _start_node(config.path)
                    time.sleep(0.4)
                    awaiting_node_restart = False
                    renderer.menu(selected)
                continue

            if t6_target_cm is not None:
                if event == "short":
                    maximum_cm = round(config.task.t6_max_target_m * 100)
                    minimum_cm = round(config.task.t6_min_target_m * 100)
                    step_cm = max(1, round(config.task.t6_step_m * 100))
                    t6_target_cm += step_cm
                    if t6_target_cm > maximum_cm:
                        t6_target_cm = minimum_cm
                    renderer.target(t6_target_cm)
                elif event == "long":
                    active_entry = MENU[5]
                    if node is None:
                        node = _start_node(config.path)
                        time.sleep(0.4)
                    _send_command(node, f"TASK T6 {t6_target_cm}")
                    task_started = time.monotonic()
                    next_render = 0.0
                    t6_target_cm = None
                continue

            if active_entry is None:
                if event == "short":
                    selected = (selected + 1) % len(MENU)
                    renderer.menu(selected)
                elif event == "long":
                    entry = MENU[selected]
                    if entry.interaction == "target":
                        t6_target_cm = 0
                        renderer.target(t6_target_cm)
                        continue
                    active_entry = entry
                    task_started = time.monotonic()
                    next_render = 0.0
                    if entry.kind == "runtime":
                        if node is None:
                            renderer.message("RESTARTING", "CAMERA / UART")
                            node = _start_node(config.path)
                            time.sleep(0.4)
                        if not _send_command(node, entry.command):
                            renderer.message("NODE ERROR", "CHECK LOG")
                    else:
                        renderer.message("PAUSING NODE", entry.label)
                        _stop_process(node)
                        node = None
                        exclusive = _start_process(
                            entry.module,
                            entry.arguments,
                            config.path,
                        )
            elif event == "long":
                if exclusive is not None:
                    renderer.message("STOPPING", active_entry.label)
                    _stop_process(exclusive)
                    exclusive = None
                    awaiting_node_restart = True
                    renderer.message("REMOVE STEEL BALL", "PRESS: RESTART")
                else:
                    _send_command(node, "IDLE")
                active_entry = None
                if not awaiting_node_restart:
                    renderer.menu(selected)
            elif event == "short":
                if exclusive is not None and active_entry.interaction == "next":
                    _send_command(exclusive, "")
                elif active_entry.formal_task:
                    status = _fetch_status(active_entry.status_port)
                    if status and status.get("task_phase") == "READY":
                        _send_command(node, "START")
                    else:
                        renderer.message("NOT READY", "WAIT BALL HOLD")
                        time.sleep(0.5)
                        next_render = 0.0
    finally:
        _stop_process(exclusive)
        _stop_process(node)
        button.close()
        display.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="0.96寸 OLED H题任务栏：短按选择/启动，长按进入/退出"
    )
    parser.add_argument(
        "--config", default=str(PROJECT_ROOT / "config" / "pi.toml")
    )
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    try:
        run(args.config)
    except KeyboardInterrupt:
        LOG.info("panel stopped")


if __name__ == "__main__":
    main()
