"""Tune only camera controls; geometry stays runtime-adaptive."""

from __future__ import annotations

import argparse
import json
import logging
import time
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

import cv2
import numpy as np

from hball.algorithms.tube_pose import RailPoseEstimator
from hball.common.camera_controls import publish_camera_controls
from hball.common.config import AppConfig, CalibrationConfig, load_config
from hball.threads.camera import LatestMjpegCamera
from hball.threads.streaming import PassthroughVideoServer


LOG = logging.getLogger(__name__)


class ProgressSink(Protocol):
    def update(self, **values: Any) -> None: ...


def _report_progress(
    state: ProgressSink,
    *,
    display: str,
    oled_display: str,
) -> None:
    """Publish progress for both standalone and persistent-node UIs."""

    state.update(
        display=display,
        oled_display=oled_display,
        setup_display=display,
        setup_oled_display=oled_display,
    )


def _shadow_reserve_score(
    value: np.ndarray,
    excess: np.ndarray,
    likely_green: np.ndarray,
) -> float:
    if not np.any(likely_green):
        return 0.0
    attenuation = 0.45
    survives = (
        (value.astype(np.float32) * attenuation >= 18.0)
        & (excess.astype(np.float32) * attenuation >= 5.0)
        & likely_green
    )
    return float(np.count_nonzero(survives)) / int(np.count_nonzero(likely_green))


def _camera_candidate_metrics(
    frames: list[np.ndarray],
    tuning: CalibrationConfig | None = None,
) -> dict[str, float]:
    tuning = tuning or CalibrationConfig()
    frame_scores: list[float] = []
    lower_rail_values: list[float] = []
    green_clipping: list[float] = []
    rail_found = 0
    for frame in frames:
        sample = frame[::2, ::2]
        hsv = cv2.cvtColor(sample, cv2.COLOR_BGR2HSV)
        b, g, r = cv2.split(sample)
        excess = g.astype(np.int16) - np.maximum(
            b.astype(np.int16), r.astype(np.int16)
        )
        likely_green = (
            (hsv[:, :, 0] >= 22)
            & (hsv[:, :, 0] <= 110)
            & (hsv[:, :, 1] >= 45)
            & (excess >= 5)
        )
        value = hsv[:, :, 2]
        count = int(np.count_nonzero(likely_green))
        if count < 80:
            global_value = float(np.percentile(value, 75.0))
            visibility = float(np.exp(-0.5 * ((global_value - 135.0) / 60.0) ** 2))
            clipping = float(np.mean((value <= 8) | (value >= 248)))
            frame_scores.append(-1.0 + visibility - 1.5 * clipping)
            continue

        coverage = count / likely_green.size
        separation = float(np.clip(np.median(excess[likely_green]) / 70.0, 0.0, 1.0))
        gray = cv2.cvtColor(sample, cv2.COLOR_BGR2GRAY)
        sharpness = float(
            np.clip(cv2.Laplacian(gray, cv2.CV_32F).var() / 700.0, 0.0, 1.0)
        )
        clipping = float(np.mean(value[likely_green] >= 248))
        green_clipping.append(clipping)
        green_value = float(np.median(value[likely_green]))
        brightness = float(np.exp(-0.5 * ((green_value - 155.0) / 52.0) ** 2))
        dark_green = float(
            np.clip((55.0 - np.percentile(value[likely_green], 3.0)) / 55.0, 0.0, 1.0)
        )
        shadow_reserve = _shadow_reserve_score(value, excess, likely_green)

        mask = likely_green.astype(np.uint8) * 255
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (61, 5)),
        )
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        horizontal: list[tuple[int, int, int, int]] = []
        for contour in contours:
            x, y, width, height = cv2.boundingRect(contour)
            if width >= sample.shape[1] * 0.30 and width / max(height, 1) >= 3.0:
                horizontal.append((x, y, width, height))
        rail_shadow = 0.0
        if horizontal:
            rail_found += 1
            x, y, width, height = max(horizontal, key=lambda rectangle: rectangle[2])
            rail_value = value[y : y + height, x : x + width]
            lower_value = float(np.percentile(rail_value, 15.0))
            lower_rail_values.append(lower_value)
            rail_shadow = float(
                np.clip(
                    (lower_value - tuning.minimum_rail_shadow_value) / 72.0,
                    0.0,
                    1.0,
                )
            )
        frame_scores.append(
            0.25 * separation
            + 0.14 * sharpness
            + 0.20 * float(np.clip(coverage / 0.08, 0.0, 1.0))
            + 0.31 * brightness
            + 0.18 * shadow_reserve
            + 0.30 * rail_shadow
            - 0.80 * dark_green
            - 1.20 * clipping
        )
    return {
        "score": float(np.mean(frame_scores)) if frame_scores else -2.0,
        "rail_found_rate": rail_found / max(len(frames), 1),
        "lower_rail_value": float(np.median(lower_rail_values)) if lower_rail_values else 0.0,
        "green_clipping_ratio": float(np.mean(green_clipping)) if green_clipping else 1.0,
    }


def _camera_candidate_score(frames: list[np.ndarray]) -> float:
    """Compatibility helper kept for the focused camera-score unit tests."""
    return _camera_candidate_metrics(frames)["score"]


def _rail_pose_metrics(
    frames: list[np.ndarray],
    config: AppConfig,
) -> dict[str, float]:
    """Measure a candidate with the same rail estimator used in competition.

    Only freshly measured poses count.  A held pose must never make a camera
    setting look reliable during field tuning.
    """

    estimator = RailPoseEstimator(config.tube_pose, config.mapping)
    measured = []
    started_ns = time.monotonic_ns()
    frame_period_ns = int(1e9 / max(config.camera.fps, 1))
    for index, frame in enumerate(frames):
        pose = estimator.update(
            frame,
            started_ns + index * frame_period_ns,
            force=True,
        )
        if pose is not None and pose.measured:
            measured.append(pose)

    if not measured:
        return {
            "pose_detection_rate": 0.0,
            "pose_confidence": 0.0,
            "pose_jitter_px": 1_000.0,
            "pose_length_error_ratio": 1.0,
            "pose_center_error_px": 1_000.0,
        }

    endpoints = np.asarray(
        [
            (
                pose.negative_px[0],
                pose.negative_px[1],
                pose.positive_px[0],
                pose.positive_px[1],
            )
            for pose in measured
        ],
        dtype=np.float32,
    )
    median_endpoints = np.median(endpoints, axis=0)
    endpoint_error = np.maximum(
        np.linalg.norm(endpoints[:, :2] - median_endpoints[:2], axis=1),
        np.linalg.norm(endpoints[:, 2:] - median_endpoints[2:], axis=1),
    )
    reference_length = max(estimator.reference_length, 1.0)
    reference_center = np.asarray(
        estimator.reference_pose.center_px,
        dtype=np.float32,
    )
    length_errors = [
        abs(pose.length_px - reference_length) / reference_length
        for pose in measured
    ]
    center_errors = [
        float(
            np.linalg.norm(
                np.asarray(pose.center_px, dtype=np.float32)
                - reference_center
            )
        )
        for pose in measured
    ]
    return {
        "pose_detection_rate": len(measured) / max(len(frames), 1),
        "pose_confidence": float(
            np.median([pose.confidence for pose in measured])
        ),
        "pose_jitter_px": float(np.percentile(endpoint_error, 95.0)),
        "pose_length_error_ratio": float(np.median(length_errors)),
        "pose_center_error_px": float(np.median(center_errors)),
    }


def _evaluate_camera_candidate(
    frames: list[np.ndarray],
    config: AppConfig,
    *,
    exposure: int,
    gain: int,
    white_balance_temperature: int,
) -> dict[str, Any]:
    metrics: dict[str, Any] = _camera_candidate_metrics(
        frames,
        config.calibration,
    )
    metrics.update(_rail_pose_metrics(frames, config))
    # The competition estimator is the primary evidence. Appearance terms
    # only choose between settings that already establish the same rail.
    metrics["appearance_score"] = metrics["score"]
    metrics["score"] = (
        2.40 * metrics["pose_detection_rate"]
        + 0.85 * metrics["pose_confidence"]
        - 0.035 * min(metrics["pose_jitter_px"], 30.0)
        - 0.60 * metrics["pose_length_error_ratio"]
        - 0.006 * min(metrics["pose_center_error_px"], 50.0)
        + 0.20 * metrics["appearance_score"]
        - 0.004 * gain
    )
    return {
        "exposure": int(exposure),
        "gain": int(gain),
        "white_balance_temperature": int(white_balance_temperature),
        **metrics,
    }


def _sample_color_frames(
    camera: LatestMjpegCamera,
    *,
    count: int,
    sample_fps: float,
) -> list[np.ndarray]:
    frames: list[np.ndarray] = []
    sequence = -1
    for _ in range(count):
        snapshot = camera.wait_next(sequence, timeout_s=1.0)
        if snapshot is None:
            raise RuntimeError("等待相机新帧超时")
        sequence = snapshot.sequence
        frame = cv2.imdecode(np.frombuffer(snapshot.jpeg, dtype=np.uint8), cv2.IMREAD_COLOR)
        if frame is not None:
            frames.append(frame)
        time.sleep(1.0 / sample_fps)
    if not frames:
        raise RuntimeError("没有取得可用彩色帧")
    return frames


def _camera_candidate_is_safe(
    candidate: dict[str, Any],
    tuning: CalibrationConfig,
) -> bool:
    """Hard publication gate; score can never override these limits."""
    return bool(
        candidate["rail_found_rate"] >= 0.5
        and candidate["lower_rail_value"]
        >= tuning.minimum_rail_shadow_value
        and candidate["green_clipping_ratio"]
        <= tuning.maximum_green_clipping_ratio
        and candidate.get(
            "pose_detection_rate",
            candidate["rail_found_rate"],
        )
        >= tuning.minimum_pose_detection_rate
        and candidate.get("pose_confidence", 1.0)
        >= tuning.minimum_pose_confidence
        and candidate.get("pose_jitter_px", 0.0)
        <= tuning.maximum_pose_jitter_px
    )


def _camera_verification_is_safe(
    candidate: dict[str, Any],
    tuning: CalibrationConfig,
) -> bool:
    return bool(
        _camera_candidate_is_safe(candidate, tuning)
        and candidate["pose_detection_rate"]
        >= tuning.minimum_verification_pose_detection_rate
    )


def _select_best_safe_candidate(
    candidates: list[dict[str, Any]],
    tuning: CalibrationConfig,
    *,
    stage: str,
) -> dict[str, Any]:
    safe = [
        candidate
        for candidate in candidates
        if _camera_candidate_is_safe(candidate, tuning)
    ]
    if safe:
        return max(safe, key=lambda candidate: candidate["score"])
    if not candidates:
        raise RuntimeError(f"FIELD TUNE {stage}阶段没有摄像头候选结果")
    closest = min(
        candidates,
        key=lambda candidate: (
            max(
                0.0,
                candidate["green_clipping_ratio"]
                - tuning.maximum_green_clipping_ratio,
            ),
            max(
                0.0,
                tuning.minimum_rail_shadow_value
                - candidate["lower_rail_value"],
            ),
            -candidate["rail_found_rate"],
            -candidate["score"],
        ),
    )
    raise RuntimeError(
        f"FIELD TUNE {stage}阶段没有安全候选，拒绝覆盖camera_controls.json；"
        f"最接近候选 E{closest['exposure']} G{closest['gain']} "
        f"WB{closest['white_balance_temperature']}，"
        f"导轨检出={closest['rail_found_rate']:.2f}，"
        f"阴影亮度={closest['lower_rail_value']:.1f}/"
        f">={tuning.minimum_rail_shadow_value:.1f}，"
        f"绿色过曝={closest['green_clipping_ratio']:.3f}/"
        f"<={tuning.maximum_green_clipping_ratio:.3f}，"
        f"正式导轨检出={closest.get('pose_detection_rate', 0.0):.2f}/"
        f">={tuning.minimum_pose_detection_rate:.2f}"
    )


def auto_camera_controls(
    camera: LatestMjpegCamera,
    config: AppConfig,
    state: ProgressSink,
) -> tuple[dict[str, int], dict[str, Any]]:
    """Fast field search around the known-good competition baseline.

    The ordinary path tests three exposure levels at zero gain, then three
    white-balance levels. Gain is a fallback only when no zero-gain setting
    can establish the rail. The current merged controls are always included,
    so a later field run can keep the last verified result instead of
    needlessly replacing it.
    """

    tuning = config.calibration
    exposures = tuple(sorted(set(tuning.exposures)))
    gains = tuple(sorted(set(tuning.gains)))
    white_balances = tuple(sorted(set(tuning.white_balances)))
    baseline = {
        "exposure": int(config.camera.exposure),
        "gain": int(config.camera.gain),
        "white_balance_temperature": int(
            config.camera.white_balance_temperature
        ),
    }
    neutral_wb = baseline["white_balance_temperature"]
    candidates: list[dict[str, Any]] = []
    tested: set[tuple[int, int, int]] = set()

    def evaluate(
        exposure: int,
        gain: int,
        white_balance: int,
        *,
        display: str,
        oled_display: str,
    ) -> dict[str, Any] | None:
        key = (int(exposure), int(gain), int(white_balance))
        if key in tested:
            return next(
                (
                    candidate
                    for candidate in candidates
                    if (
                        candidate["exposure"],
                        candidate["gain"],
                        candidate["white_balance_temperature"],
                    )
                    == key
                ),
                None,
            )
        tested.add(key)
        _report_progress(
            state,
            display=display,
            oled_display=oled_display,
        )
        if not camera.set_manual_controls(
            exposure=exposure,
            gain=gain,
            white_balance_temperature=white_balance,
        ):
            return None
        time.sleep(tuning.control_settle_s)
        frames = _sample_color_frames(
            camera,
            count=tuning.frames_per_candidate,
            sample_fps=tuning.sample_fps,
        )
        candidate = _evaluate_camera_candidate(
            frames,
            config,
            exposure=exposure,
            gain=gain,
            white_balance_temperature=white_balance,
        )
        candidates.append(candidate)
        return candidate

    brightness_controls = [baseline]
    brightness_controls.extend(
        {
            "exposure": exposure,
            "gain": 0,
            "white_balance_temperature": neutral_wb,
        }
        for exposure in exposures
    )
    unique_brightness: list[dict[str, int]] = []
    brightness_keys: set[tuple[int, int, int]] = set()
    for controls in brightness_controls:
        key = (
            controls["exposure"],
            controls["gain"],
            controls["white_balance_temperature"],
        )
        if key not in brightness_keys:
            brightness_keys.add(key)
            unique_brightness.append(controls)

    brightness_candidates: list[dict[str, Any]] = []
    for index, controls in enumerate(unique_brightness, 1):
        candidate = evaluate(
            controls["exposure"],
            controls["gain"],
            controls["white_balance_temperature"],
            display=(
                f"三档曝光 {index}/{len(unique_brightness)}: "
                f"E{controls['exposure']} G{controls['gain']} "
                f"WB{controls['white_balance_temperature']}"
            ),
            oled_display=f"LIGHT {index}/{len(unique_brightness)}",
        )
        if candidate is not None:
            brightness_candidates.append(candidate)

    safe_brightness = [
        candidate
        for candidate in brightness_candidates
        if _camera_candidate_is_safe(candidate, tuning)
    ]
    gain_fallback_used = False
    if not safe_brightness:
        gain_fallback_used = True
        darkest_exposure = max(exposures)
        fallback_gains = [gain for gain in gains if gain > 0]
        for index, gain in enumerate(fallback_gains, 1):
            candidate = evaluate(
                darkest_exposure,
                gain,
                neutral_wb,
                display=(
                    f"低光增益 {index}/{len(fallback_gains)}: "
                    f"E{darkest_exposure} G{gain} WB{neutral_wb}"
                ),
                oled_display=f"DARK GAIN {index}/{len(fallback_gains)}",
            )
            if candidate is not None:
                brightness_candidates.append(candidate)

    brightness_best = _select_best_safe_candidate(
        brightness_candidates,
        tuning,
        stage="亮度",
    )

    for index, white_balance in enumerate(white_balances, 1):
        exposure = int(brightness_best["exposure"])
        gain = int(brightness_best["gain"])
        candidate = evaluate(
            exposure,
            gain,
            white_balance,
            display=(
                f"三档色温 {index}/{len(white_balances)}: "
                f"E{exposure} G{gain} WB{white_balance}"
            ),
            oled_display=f"COLOR {index}/{len(white_balances)}",
        )
    best = _select_best_safe_candidate(
        candidates,
        tuning,
        stage="白平衡",
    )
    selected = {
        "exposure": int(best["exposure"]),
        "gain": int(best["gain"]),
        "white_balance_temperature": int(best["white_balance_temperature"]),
    }
    if not camera.set_manual_controls(**selected):
        camera.set_manual_controls(**baseline)
        raise RuntimeError("FIELD TUNE无法应用最终候选，已恢复原相机参数")
    time.sleep(tuning.control_settle_s)
    _report_progress(
        state,
        display=(
            f"最终复核 {tuning.verification_frames}帧: "
            f"E{selected['exposure']} G{selected['gain']} "
            f"WB{selected['white_balance_temperature']}"
        ),
        oled_display="VERIFY RAIL",
    )
    verification_frames = _sample_color_frames(
        camera,
        count=tuning.verification_frames,
        sample_fps=tuning.sample_fps,
    )
    verification = _evaluate_camera_candidate(
        verification_frames,
        config,
        **selected,
    )
    if (
        not _camera_verification_is_safe(verification, tuning)
        or camera.capture_fps < config.preflight.min_camera_fps
    ):
        camera.set_manual_controls(**baseline)
        raise RuntimeError(
            "FIELD TUNE最终复核失败，已恢复原参数且没有覆盖文件；"
            f"导轨检出={verification['pose_detection_rate']:.2f}/"
            f">={tuning.minimum_verification_pose_detection_rate:.2f}，"
            f"置信度={verification['pose_confidence']:.2f}/"
            f">={tuning.minimum_pose_confidence:.2f}，"
            f"抖动={verification['pose_jitter_px']:.1f}/"
            f"<={tuning.maximum_pose_jitter_px:.1f}px，"
            f"相机={camera.capture_fps:.1f}/"
            f">={config.preflight.min_camera_fps:.1f}fps"
        )

    safe_candidates = [
        candidate
        for candidate in candidates
        if _camera_candidate_is_safe(candidate, tuning)
    ]
    return selected, {
        "supported": True,
        "strategy": "THREE_LEVEL_RAIL_ESTIMATOR",
        "baseline": baseline,
        "candidate_count": len(candidates),
        "safe_candidate_count": len(safe_candidates),
        "gain_fallback_used": gain_fallback_used,
        "publication_gate_passed": True,
        "selected": best,
        "verification": verification,
        "verification_frames": tuning.verification_frames,
        "camera_fps_after_verification": round(camera.capture_fps, 2),
        "exposure_range": list(exposures),
        "gain_range": list(gains),
        "white_balance_range": list(white_balances),
        "top_candidates": sorted(
            candidates,
            key=lambda item: item["score"],
            reverse=True,
        )[:8],
        "top_safe_candidates": sorted(
            safe_candidates,
            key=lambda item: item["score"],
            reverse=True,
        )[:8],
    }


def tune_and_publish_camera_controls(
    camera: LatestMjpegCamera,
    config: AppConfig,
    state: ProgressSink,
    *,
    wait_for_operator_clear: bool = True,
) -> dict[str, Any]:
    """Tune an already-running camera and atomically publish one result."""

    if wait_for_operator_clear:
        _report_progress(
            state,
            display="移走钢球，保持轨道、灯光和双手静止",
            oled_display="EMPTY / HANDS OFF",
        )
        time.sleep(config.calibration.operator_clear_s)
    controls, metrics = auto_camera_controls(camera, config, state)
    publish_camera_controls(
        config.calibration.camera_controls_path,
        controls,
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        metrics=metrics,
    )
    result = {
        "camera_controls_path": str(
            config.calibration.camera_controls_path
        ),
        "camera_controls": controls,
        "metrics": metrics,
        "next_step": "运行背景采集和连续钢球检查",
    }
    _report_progress(
        state,
        display=(
            f"已保存 E{controls['exposure']} G{controls['gain']} "
            f"WB{controls['white_balance_temperature']}"
        ),
        oled_display="CAMERA SAVED",
    )
    return result


def run_camera_tune(
    config: AppConfig,
    *,
    wait_for_confirm: bool = True,
) -> dict[str, Any]:
    camera = LatestMjpegCamera(config.camera)
    preview_config = replace(
        config.video,
        enabled=True,
        bind=config.calibration.preview_bind,
        port=config.calibration.preview_port,
        fps=config.calibration.preview_fps,
        annotate=False,
    )
    state: dict[str, Any] = {
        "state": "FIELD_TUNE_WAIT",
        "node_mode": "FIELD_TUNE",
        "setup_phase": "CAMERA",
        "display": "移走钢球，轨道水平；确认后只校准相机参数",
        "oled_display": "EMPTY + PRESS",
    }
    preview = PassthroughVideoServer(camera, preview_config, lambda: dict(state))
    preview_host = config.network.ipv4_cidr.split("/", 1)[0]
    try:
        camera.start()
        preview.start()
        print(
            "\nFIELD TUNE只调整曝光、增益、白平衡；不修改坐标。"
            f"\n预览: http://{preview_host}:{config.calibration.preview_port}/stream.mjpg"
            "\n移走钢球，轨道水平，双手离开画面。",
            flush=True,
        )
        if wait_for_confirm:
            print("确认后按 Enter...", flush=True)
            input()
        else:
            print(
                f"{config.calibration.operator_clear_s:.1f}秒后自动开始...",
                flush=True,
            )
        state.update(
            state="FIELD_TUNE_RUNNING",
            setup_phase="CAMERA",
            oled_display="HANDS OFF",
        )
        result = tune_and_publish_camera_controls(camera, config, state)
        state.update(
            state="FIELD_TUNE_PASSED",
            setup_phase="PASSED",
            oled_display="CAM SAVED",
            display=json.dumps(result, ensure_ascii=False),
        )
        print("\n相机参数已原子保存；下次启动所有任务会经 load_config() 自动使用：")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return result
    finally:
        preview.close()
        camera.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="比赛相机参数自校准（仅曝光、增益、白平衡）"
    )
    parser.add_argument("--config", type=Path, default=Path("config/pi.toml"))
    parser.add_argument(
        "--auto-start",
        action="store_true",
        help="空轨等待operator_clear_s后自动开始，供OLED一键任务使用",
    )
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    run_camera_tune(
        load_config(args.config),
        wait_for_confirm=not args.auto_start,
    )


if __name__ == "__main__":
    main()
