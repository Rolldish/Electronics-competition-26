"""Competition, calibration, debug, and system-check task entry points."""
