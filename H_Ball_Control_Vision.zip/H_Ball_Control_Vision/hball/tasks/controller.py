"""Competition task state machine and target generation."""

from __future__ import annotations

import secrets
from dataclasses import dataclass
from enum import Enum

from ..common.config import TaskConfig
from ..drivers.protocol import ControlFlags, TaskId


class TaskPhase(str, Enum):
    WAIT_TRACK = "WAIT_TRACK"
    PREPARE = "PREPARE"
    READY = "READY"
    HOLD = "HOLD"
    TO_POSITIVE = "TO_POSITIVE"
    TO_NEGATIVE = "TO_NEGATIVE"
    DONE = "DONE"
    TIMEOUT = "TIMEOUT"


@dataclass(frozen=True)
class TaskStatus:
    task_id: TaskId
    phase: TaskPhase
    target_x_m: float
    control_flags: ControlFlags
    run_id: int
    elapsed_s: float
    error_m: float | None


def new_run_id() -> int:
    value = secrets.randbelow(0xFFFF) + 1
    return value


class BallTaskController:
    """Pi-side high-level task logic; the C board remains the fast controller."""

    def __init__(
        self,
        config: TaskConfig,
        task_id: TaskId,
        *,
        run_id: int | None = None,
        target_x_m: float | None = None,
        minimum_position_m: float = -0.125,
        maximum_position_m: float = 0.125,
    ) -> None:
        self.config = config
        self.task_id = task_id
        self.run_id = new_run_id() if run_id is None else int(run_id) & 0xFFFF
        self.minimum_position_m = minimum_position_m
        self.maximum_position_m = maximum_position_m
        self.phase = TaskPhase.WAIT_TRACK
        requested_target = (
            0.0
            if task_id != TaskId.T6 or target_x_m is None
            else float(target_x_m)
        )
        self.target_x_m = min(
            maximum_position_m,
            max(minimum_position_m, requested_target),
        )
        self.started_ns: int | None = None
        self.completed_elapsed_s: float | None = None
        self._condition_since_ns: int | None = None

    def start(self, now_ns: int, *, track_valid: bool) -> bool:
        if (
            self.task_id == TaskId.IDLE
            or self.phase != TaskPhase.READY
            or not track_valid
        ):
            return False
        if self.task_id == TaskId.T3:
            self.phase = TaskPhase.TO_POSITIVE
            self.target_x_m = self.config.positive_target_m
        else:
            self.phase = TaskPhase.HOLD
        self.started_ns = now_ns
        self._condition_since_ns = None
        return True

    def update(
        self,
        now_ns: int,
        *,
        x_m: float,
        v_mps: float,
        track_valid: bool,
        confidence: float,
    ) -> TaskStatus:
        usable = track_valid and confidence >= self.config.minimum_confidence
        if self.task_id == TaskId.IDLE:
            return self.status(now_ns, x_m if usable else None)
        if self.phase == TaskPhase.WAIT_TRACK and usable:
            self.phase = TaskPhase.PREPARE
            self._condition_since_ns = None
        if self.phase in {TaskPhase.PREPARE, TaskPhase.READY}:
            if not usable:
                self.phase = TaskPhase.WAIT_TRACK
                self._condition_since_ns = None
            else:
                settled = (
                    abs(x_m - self.target_x_m) <= self.config.ready_error_m
                    and abs(v_mps) <= self.config.ready_speed_mps
                )
                if self._held(now_ns, settled, self.config.ready_hold_s):
                    self.phase = TaskPhase.READY

        if self.task_id == TaskId.T3 and self.started_ns is not None:
            elapsed = (now_ns - self.started_ns) * 1e-9
            if self.phase == TaskPhase.TO_POSITIVE:
                reached = usable and x_m >= self.config.positive_reached_m
                if self._held(
                    now_ns, reached, self.config.positive_reached_hold_s
                ):
                    self.phase = TaskPhase.TO_NEGATIVE
                    self.target_x_m = self.config.negative_target_m
            elif self.phase == TaskPhase.TO_NEGATIVE:
                settled = (
                    usable
                    and abs(x_m - self.config.negative_target_m)
                    <= self.config.final_error_m
                    and abs(v_mps) <= self.config.final_speed_mps
                )
                if self._held(now_ns, settled, self.config.final_hold_s):
                    self.phase = TaskPhase.DONE
                    self.completed_elapsed_s = elapsed
            if (
                self.phase in {TaskPhase.TO_POSITIVE, TaskPhase.TO_NEGATIVE}
                and elapsed >= self.config.timeout_s
            ):
                self.phase = TaskPhase.TIMEOUT
                self.target_x_m = self.config.negative_target_m
                self.completed_elapsed_s = elapsed

        return self.status(now_ns, x_m if usable else None)

    def _held(self, now_ns: int, condition: bool, duration_s: float) -> bool:
        if not condition:
            self._condition_since_ns = None
            return False
        if self._condition_since_ns is None:
            self._condition_since_ns = now_ns
            return False
        if (now_ns - self._condition_since_ns) * 1e-9 >= duration_s:
            self._condition_since_ns = None
            return True
        return False

    def status(self, now_ns: int, x_m: float | None) -> TaskStatus:
        flags = ControlFlags(0)
        target_available = self.task_id != TaskId.IDLE
        if target_available:
            flags |= ControlFlags.CONTROL_ENABLED
        if self.started_ns is not None and self.phase not in {
            TaskPhase.READY,
            TaskPhase.PREPARE,
            TaskPhase.WAIT_TRACK,
        }:
            flags |= ControlFlags.RUN_ACTIVE
        if self.phase == TaskPhase.DONE:
            flags |= ControlFlags.TASK_DONE
        if self.phase == TaskPhase.TIMEOUT:
            flags |= ControlFlags.TASK_TIMEOUT
        if self.task_id == TaskId.T6 and target_available:
            flags |= ControlFlags.TARGET_LATCHED
        elapsed = 0.0
        if self.completed_elapsed_s is not None:
            elapsed = self.completed_elapsed_s
        elif self.started_ns is not None:
            elapsed = max(0.0, (now_ns - self.started_ns) * 1e-9)
        error = None if x_m is None else x_m - self.target_x_m
        return TaskStatus(
            self.task_id,
            self.phase,
            self.target_x_m,
            flags,
            self.run_id,
            elapsed,
            error,
        )
