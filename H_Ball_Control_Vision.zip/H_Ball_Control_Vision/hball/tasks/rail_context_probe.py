"""Independent raw-frame rail/ball vision probe.

This task never opens UART or UDP control links and never writes calibration
files.  It exists to validate the replacement visual chain before integration.
"""

from __future__ import annotations

import argparse
import logging
import math
import queue
import sys
import time
from collections import Counter, deque
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


from hball.algorithms.axis_tracker import (  # noqa: E402
    AxisBallTracker,
    AxisTrackEstimate,
)
from hball.algorithms.runtime_profile import (  # noqa: E402
    resolve_runtime_vision_profile,
)
from hball.algorithms.rail_context_detector import (  # noqa: E402
    RailBallCandidate,
    RailContextBallDetector,
    RailContextResult,
)
from hball.algorithms.tube_pose import RailPoseEstimator, TubePose  # noqa: E402
from hball.common.config import load_config  # noqa: E402
from hball.threads.camera import LatestMjpegCamera  # noqa: E402
from hball.threads.streaming import (  # noqa: E402
    PassthroughVideoServer,
    PublishedVideoServer,
)


LOG = logging.getLogger(__name__)
_ACTIONS = ("QUIT", "RESET", "BG", "SHOT", "FULL")


def _draw_toolbar(frame: np.ndarray) -> None:
    height, width = frame.shape[:2]
    top = max(0, height - 38)
    button_width = width / len(_ACTIONS)
    for index, label in enumerate(_ACTIONS):
        left = int(round(index * button_width))
        right = int(round((index + 1) * button_width)) - 1
        cv2.rectangle(frame, (left, top), (right, height - 1), (28, 28, 28), -1)
        cv2.rectangle(frame, (left, top), (right, height - 1), (190, 190, 190), 1)
        cv2.putText(
            frame,
            label,
            (left + 12, top + 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.52,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )


def _save_screenshot(config, frame: np.ndarray) -> None:
    config.debug.screenshot_dir.mkdir(parents=True, exist_ok=True)
    path = config.debug.screenshot_dir / (
        "rail_probe_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".jpg"
    )
    if cv2.imwrite(str(path), frame):
        LOG.info("probe screenshot: %s", path)


def _capture_registered_background(
    camera: LatestMjpegCamera,
    pose_estimator: RailPoseEstimator,
    detector: RailContextBallDetector,
    expected_shape: tuple[int, int],
    frame_count: int,
    last_sequence: int,
) -> tuple[int, TubePose]:
    print(
        "\n请移走钢球并保持轨道、灯光静止，"
        f"正在采集 {frame_count} 帧轨道配准彩色背景……"
    )
    samples: list[np.ndarray] = []
    poses: list[TubePose] = []
    attempts = 0
    maximum_attempts = max(80, frame_count * 5)
    while len(samples) < frame_count and attempts < maximum_attempts:
        attempts += 1
        snapshot = camera.wait_next(last_sequence, timeout_s=0.75)
        if snapshot is None:
            if not camera.running:
                raise RuntimeError("camera stopped during background capture")
            continue
        last_sequence = snapshot.sequence
        frame = cv2.imdecode(
            np.frombuffer(snapshot.jpeg, dtype=np.uint8),
            cv2.IMREAD_COLOR,
        )
        if frame is None or frame.shape[:2] != expected_shape:
            continue
        pose = pose_estimator.update(
            frame,
            snapshot.timestamp_ns,
            force=True,
        )
        if pose is None:
            continue
        samples.append(detector.reference_sample(frame, pose))
        poses.append(pose)
    if len(samples) != frame_count:
        raise RuntimeError(
            "轨道配准背景采集失败："
            f"{len(samples)}/{frame_count} 帧，先解决绿色轨道定位"
        )
    detector.set_background(samples)
    locked_pose = _median_pose(poses)
    print(
        "轨道配准彩色背景已就绪；"
        f"静态锁定姿态 length={locked_pose.length_px:.1f}px, "
        f"width={locked_pose.width_px:.1f}px。现在可以放入钢球。\n"
    )
    return last_sequence, locked_pose


def _median_pose(poses: list[TubePose]) -> TubePose:
    if not poses:
        raise ValueError("cannot lock an empty rail pose sequence")

    def median_point(values: list[tuple[float, float]]) -> tuple[float, float]:
        array = np.asarray(values, dtype=np.float64)
        result = np.median(array, axis=0)
        return float(result[0]), float(result[1])

    corners = None
    valid_corners = [pose.corners_px for pose in poses if pose.corners_px is not None]
    if len(valid_corners) >= max(5, len(poses) // 2):
        corner_array = np.asarray(valid_corners, dtype=np.float64)
        median_corners = np.median(corner_array, axis=0)
        corners = tuple(
            (float(point[0]), float(point[1]))
            for point in median_corners
        )
    return TubePose(
        negative_px=median_point([pose.negative_px for pose in poses]),
        positive_px=median_point([pose.positive_px for pose in poses]),
        width_px=float(np.median([pose.width_px for pose in poses])),
        confidence=float(np.median([pose.confidence for pose in poses])),
        timestamp_ns=max(pose.timestamp_ns for pose in poses),
        measured=False,
        source="LOCKED",
        corners_px=corners,
    )


def _pose_drift(
    live: TubePose | None,
    locked: TubePose,
) -> dict[str, float] | None:
    if live is None:
        return None
    center_shift = math.hypot(
        live.center_px[0] - locked.center_px[0],
        live.center_px[1] - locked.center_px[1],
    )
    live_angle = math.degrees(math.atan2(live.axis[1], live.axis[0]))
    locked_angle = math.degrees(math.atan2(locked.axis[1], locked.axis[0]))
    angle_error = (live_angle - locked_angle + 180.0) % 360.0 - 180.0
    return {
        "center_shift_px": round(center_shift, 3),
        "angle_error_deg": round(angle_error, 4),
        "length_error_px": round(live.length_px - locked.length_px, 3),
        "width_error_px": round(live.width_px - locked.width_px, 3),
    }


def _candidate_payload(candidate: RailBallCandidate | None) -> dict | None:
    if candidate is None:
        return None
    return {
        "x_px": round(candidate.x_px, 2),
        "y_px": round(candidate.y_px, 2),
        "radius_px": round(candidate.radius_px, 2),
        "axis_fraction": round(candidate.axis_fraction, 5),
        "cross_axis_px": round(candidate.cross_axis_px, 2),
        "score": round(candidate.score, 4),
        "accepted": candidate.accepted,
        "rejection": candidate.rejection,
        "source": candidate.source,
        "circularity": round(candidate.circularity, 4),
        "fit_valid": candidate.fit_valid,
        "fit_error_ratio": round(candidate.fit_error_ratio, 4),
        "expected_radius_px": round(candidate.expected_radius_px, 2),
        "radius_error_ratio": round(candidate.radius_error_ratio, 4),
        "edge_coverage": round(candidate.edge_coverage, 4),
        "radial_score": round(candidate.radial_score, 4),
        "change_ratio": round(candidate.change_ratio, 4),
        "non_green_ratio": round(candidate.non_green_ratio, 4),
        "green_annulus_ratio": round(candidate.green_annulus_ratio, 4),
        "achromatic_ratio": round(candidate.achromatic_ratio, 4),
    }


def _render(
    frame: np.ndarray,
    pose: TubePose | None,
    result: RailContextResult | None,
    estimate: AxisTrackEstimate,
    *,
    camera_fps: float,
    detection_fps: float,
    decode_ms: float,
    pose_diagnostics: dict[str, object],
    history: deque[float],
) -> np.ndarray:
    display = frame.copy()
    overlay = display.copy()
    if result is not None:
        overlay[result.anomaly_mask > 0] = (210, 40, 210)
        display = cv2.addWeighted(display, 0.82, overlay, 0.18, 0.0)
        corridor_contours, _ = cv2.findContours(
            result.corridor_mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )
        cv2.drawContours(display, corridor_contours, -1, (255, 210, 0), 1)

    if pose is not None:
        negative = tuple(int(round(value)) for value in pose.negative_px)
        positive = tuple(int(round(value)) for value in pose.positive_px)
        cv2.line(display, negative, positive, (255, 255, 0), 2, cv2.LINE_AA)
        cv2.circle(display, negative, 5, (255, 120, 0), -1)
        cv2.circle(display, positive, 5, (0, 120, 255), -1)

        if len(history) >= 2:
            points = [
                tuple(int(round(value)) for value in pose.point_at_fraction(item))
                for item in history
            ]
            cv2.polylines(
                display,
                [np.asarray(points, dtype=np.int32)],
                False,
                (80, 240, 255),
                1,
                cv2.LINE_AA,
            )
        if estimate.track_valid:
            tracked = tuple(
                int(round(value))
                for value in pose.point_at_fraction(estimate.axis_fraction)
            )
            cv2.drawMarker(
                display,
                tracked,
                (255, 255, 255),
                cv2.MARKER_CROSS,
                22,
                2,
                cv2.LINE_AA,
            )

    if result is not None:
        selected = estimate.selected
        for rank, candidate in enumerate(result.candidates[:12], start=1):
            center = (int(round(candidate.x_px)), int(round(candidate.y_px)))
            radius = max(2, int(round(candidate.radius_px)))
            is_selected = selected is candidate
            color = (
                (40, 255, 40)
                if candidate.accepted
                else (40, 80, 255)
            )
            if is_selected:
                color = (255, 40, 255)
            cv2.circle(
                display,
                center,
                radius,
                color,
                3 if is_selected else 1,
                cv2.LINE_AA,
            )
            cv2.putText(
                display,
                str(rank),
                (center[0] + radius + 2, center[1] - 2),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.38,
                color,
                1,
                cv2.LINE_AA,
            )

    cv2.rectangle(display, (0, 0), (display.shape[1] - 1, 128), (0, 0, 0), -1)
    pose_text = (
        "NO RAIL"
        if pose is None
        else (
            f"RAIL {pose.source} conf={pose.confidence:.2f} "
            f"len={pose.length_px:.1f}px width={pose.width_px:.1f}px"
        )
    )
    accepted_count = 0 if result is None else len(result.accepted)
    candidate_count = 0 if result is None else len(result.candidates)
    processing_ms = 0.0 if result is None else result.processing_ms
    lines = [
        "RAW-BGR RAIL CONTEXT PROBE | NO UART | NO CALIBRATION WRITE",
        pose_text,
        (
            f"state={estimate.state.value} acquire="
            f"{estimate.acquisition_frames}/{estimate.acquisition_required} "
            f"u={estimate.axis_fraction:+.4f} "
            f"du={estimate.velocity_fraction_s:+.3f}/s "
            f"miss={estimate.missed_frames}"
        ),
        (
            f"candidates={candidate_count} accepted={accepted_count} "
            f"camera={camera_fps:.1f}fps detect={detection_fps:.1f}fps "
            f"decode={decode_ms:.1f}ms probe={processing_ms:.1f}ms"
        ),
    ]
    best = None if result is None or not result.candidates else result.candidates[0]
    if best is not None:
        decision = "PASS" if best.accepted else best.rejection
        fit_text = (
            f"{best.fit_error_ratio:.2f}"
            if best.fit_valid
            else "N/A"
        )
        lines.append(
            f"best={decision} score={best.score:.3f} "
            f"r={best.radius_px:.1f}/{best.expected_radius_px:.1f} "
            f"fit={fit_text} edge={best.edge_coverage:.2f} "
            f"rad={best.radial_score:.2f} diff={best.change_ratio:.2f} "
            f"nonG={best.non_green_ratio:.2f} "
            f"greenCtx={best.green_annulus_ratio:.2f} ach={best.achromatic_ratio:.2f}"
        )
    else:
        diagnostics_result = pose_diagnostics.get("result", "NOT_RUN")
        lines.append(f"best=NONE pose_diagnostics={diagnostics_result}")

    colors = (
        (0, 255, 255),
        (255, 255, 0) if pose is not None else (0, 80, 255),
        (0, 255, 0) if estimate.track_valid else (0, 180, 255),
        (230, 230, 230),
        (255, 180, 255),
    )
    for index, line in enumerate(lines):
        cv2.putText(
            display,
            line,
            (10, 22 + index * 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            colors[index],
            1,
            cv2.LINE_AA,
        )
    return display


def run(
    config_path: str,
    mode: str,
    *,
    lock_rail: bool,
    rail_diagnostics: bool = False,
) -> None:
    config = load_config(config_path)
    cv2.setNumThreads(config.runtime.opencv_threads)
    profile = resolve_runtime_vision_profile(config)
    vision_config = profile.vision_config
    camera_config = profile.camera_config
    profile_id = profile.profile_id
    local_enabled = mode in {"local", "both"}
    server_enabled = mode in {"server", "both"}
    camera = LatestMjpegCamera(camera_config)
    pose_estimator = RailPoseEstimator(
        vision_config.tube_pose,
        vision_config.mapping,
    )
    detector = RailContextBallDetector(
        vision_config.detector,
        vision_config.tube_pose,
        vision_config.mapping,
        vision_config.target.ball_diameter_m,
    )
    tracker = AxisBallTracker(
        config.tracker,
        max_track_jump_px=vision_config.detector.max_track_jump_px,
    )
    status: dict = {
        "state": "STARTING",
        "mode": mode,
        "probe": "RAW_BGR_RAIL_CONTEXT",
        "uart_enabled": False,
        "calibration_write_enabled": False,
        "vision_profile": profile_id,
        "registered_background_ready": False,
        "rail_pose_mode": (
            "DIAGNOSTIC_LIVE"
            if rail_diagnostics
            else ("LOCKED_STATIC" if lock_rail else "DYNAMIC")
        ),
    }
    debug_server = (
        PublishedVideoServer(
            config.debug.server_bind,
            config.debug.server_port,
            lambda: dict(status),
        )
        if server_enabled
        else None
    )
    raw_server = (
        PassthroughVideoServer(
            camera,
            config.video,
            lambda: dict(status),
        )
        if server_enabled and config.video.enabled
        else None
    )
    mouse_events: queue.SimpleQueue[str] = queue.SimpleQueue()
    fullscreen = False
    last_sequence = -1
    interval_started = time.monotonic()
    interval_frames = 0
    detection_fps = 0.0
    next_publish = time.monotonic()
    publish_period = 1.0 / config.debug.server_fps
    history: deque[float] = deque(maxlen=180)
    recent_best_candidate: dict | None = None
    recent_best_sequence: int | None = None
    recent_accepted_candidate: dict | None = None
    recent_accepted_sequence: int | None = None

    try:
        camera.start()
        locked_pose: TubePose | None = None
        if rail_diagnostics:
            print(
                "\n导轨诊断模式：跳过配准背景和钢球检测，"
                "持续显示原始画面、绿色导轨定位和拒绝原因。"
            )
        else:
            last_sequence, locked_pose = _capture_registered_background(
                camera,
                pose_estimator,
                detector,
                (config.camera.height, config.camera.width),
                30,
                last_sequence,
            )
            status["registered_background_ready"] = True
        if raw_server is not None:
            raw_server.start()
        if debug_server is not None:
            debug_server.start()
        host = config.network.ipv4_cidr.split("/", 1)[0]
        print("\n独立视觉验证已启动：不发送 UART/UDP，不写标定文件。")
        print(
            "轨道姿态模式："
            + (
                "LOCKED_STATIC（当前静态调试，不使用实时四边形做差分）"
                if lock_rail
                else "DYNAMIC（仅供最终机械完成后的对照测试）"
            )
        )
        if raw_server is not None:
            print(f"原始视频： http://{host}:{raw_server.bound_port}/")
        if debug_server is not None:
            print(f"诊断画面： http://{host}:{debug_server.bound_port}/stream.mjpg")
            print(f"诊断数据： http://{host}:{debug_server.bound_port}/status.json")
        print("先空轨运行 30 秒；只有 accepted=0 且 state=SEARCH 才算通过。\n")

        if local_enabled:
            cv2.namedWindow("H Ball Raw Rail Probe", cv2.WINDOW_NORMAL)
            cv2.resizeWindow(
                "H Ball Raw Rail Probe",
                config.camera.width,
                config.camera.height,
            )

            def on_mouse(event, x, y, flags, userdata) -> None:
                del flags, userdata
                if event != cv2.EVENT_LBUTTONUP:
                    return
                if y < config.camera.height - 45:
                    return
                index = min(
                    len(_ACTIONS) - 1,
                    max(0, int(x * len(_ACTIONS) / config.camera.width)),
                )
                mouse_events.put(_ACTIONS[index])

            cv2.setMouseCallback("H Ball Raw Rail Probe", on_mouse)

        while True:
            snapshot = camera.wait_next(last_sequence, timeout_s=0.5)
            if snapshot is None:
                if not camera.running:
                    raise RuntimeError("camera capture process stopped")
                continue
            last_sequence = snapshot.sequence
            decode_started = time.perf_counter()
            frame = cv2.imdecode(
                np.frombuffer(snapshot.jpeg, dtype=np.uint8),
                cv2.IMREAD_COLOR,
            )
            decode_ms = (time.perf_counter() - decode_started) * 1000.0
            if frame is None or frame.shape[:2] != (
                config.camera.height,
                config.camera.width,
            ):
                continue

            live_pose = pose_estimator.update(frame, snapshot.timestamp_ns)
            if lock_rail and locked_pose is not None:
                pose = TubePose(
                    negative_px=locked_pose.negative_px,
                    positive_px=locked_pose.positive_px,
                    width_px=locked_pose.width_px,
                    confidence=locked_pose.confidence,
                    timestamp_ns=snapshot.timestamp_ns,
                    measured=False,
                    source="LOCKED",
                    corners_px=locked_pose.corners_px,
                )
            else:
                pose = live_pose
            result = (
                None
                if pose is None or not status["registered_background_ready"]
                else detector.detect(frame, pose)
            )
            accepted = () if result is None else result.accepted
            rail_length = math.hypot(
                vision_config.mapping.positive_point_px[0]
                - vision_config.mapping.negative_point_px[0],
                vision_config.mapping.positive_point_px[1]
                - vision_config.mapping.negative_point_px[1],
            )
            if pose is not None:
                rail_length = pose.length_px
            estimate = tracker.update(
                accepted,
                snapshot.timestamp_ns,
                abs(rail_length),
            )
            if estimate.track_valid:
                history.append(estimate.axis_fraction)
            elif estimate.state.value == "SEARCH":
                history.clear()

            interval_frames += 1
            now = time.monotonic()
            elapsed = now - interval_started
            if elapsed >= 0.5:
                detection_fps = interval_frames / elapsed
                interval_frames = 0
                interval_started = now

            rejections = (
                {}
                if result is None
                else dict(Counter(item.rejection for item in result.candidates))
            )
            best = (
                None
                if result is None or not result.candidates
                else result.candidates[0]
            )
            if best is not None:
                recent_best_candidate = _candidate_payload(best)
                recent_best_sequence = snapshot.sequence
            if result is not None and result.accepted:
                recent_accepted_candidate = _candidate_payload(result.accepted[0])
                recent_accepted_sequence = snapshot.sequence
            status.update(
                {
                    "state": estimate.state.value,
                    "camera_sequence": snapshot.sequence,
                    "rail_valid": pose is not None,
                    "rail_confidence": (
                        0.0 if pose is None else round(pose.confidence, 4)
                    ),
                    "rail_source": None if pose is None else pose.source,
                    "rail_length_px": (
                        None if pose is None else round(pose.length_px, 2)
                    ),
                    "rail_width_px": (
                        None if pose is None else round(pose.width_px, 2)
                    ),
                    "rail_diagnostics": pose_estimator.last_diagnostics,
                    "live_rail_valid": live_pose is not None,
                    "live_rail_confidence": (
                        0.0
                        if live_pose is None
                        else round(live_pose.confidence, 4)
                    ),
                    "live_rail_source": (
                        None if live_pose is None else live_pose.source
                    ),
                    "live_rail_length_px": (
                        None
                        if live_pose is None
                        else round(live_pose.length_px, 2)
                    ),
                    "live_rail_width_px": (
                        None
                        if live_pose is None
                        else round(live_pose.width_px, 2)
                    ),
                    "live_vs_locked_drift": (
                        _pose_drift(live_pose, locked_pose)
                        if lock_rail and locked_pose is not None
                        else None
                    ),
                    "candidate_count": 0 if result is None else len(result.candidates),
                    "accepted_count": 0 if result is None else len(result.accepted),
                    "rejections": rejections,
                    "seed_diagnostics": (
                        {}
                        if result is None
                        else result.seed_diagnostics
                    ),
                    "best_candidate": _candidate_payload(best),
                    "recent_best_candidate": recent_best_candidate,
                    "recent_best_age_frames": (
                        None
                        if recent_best_sequence is None
                        else snapshot.sequence - recent_best_sequence
                    ),
                    "recent_accepted_candidate": recent_accepted_candidate,
                    "recent_accepted_age_frames": (
                        None
                        if recent_accepted_sequence is None
                        else snapshot.sequence - recent_accepted_sequence
                    ),
                    "selected_candidate": _candidate_payload(estimate.selected),
                    "track_valid": estimate.track_valid,
                    "measurement_valid": estimate.measurement_valid,
                    "predicted": estimate.predicted,
                    "acquisition_frames": estimate.acquisition_frames,
                    "acquisition_required": estimate.acquisition_required,
                    "jump_quarantined": estimate.jump_quarantined,
                    "axis_fraction": (
                        round(estimate.axis_fraction, 6)
                        if estimate.track_valid
                        else None
                    ),
                    "velocity_fraction_s": (
                        round(estimate.velocity_fraction_s, 6)
                        if estimate.track_valid
                        else None
                    ),
                    "camera_fps": round(camera.capture_fps, 2),
                    "detection_fps": round(detection_fps, 2),
                    "decode_ms": round(decode_ms, 2),
                    "probe_ms": (
                        0.0 if result is None else round(result.processing_ms, 2)
                    ),
                }
            )

            publish_due = debug_server is not None and now >= next_publish
            display = None
            if local_enabled or publish_due:
                display = _render(
                    frame,
                    pose,
                    result,
                    estimate,
                    camera_fps=camera.capture_fps,
                    detection_fps=detection_fps,
                    decode_ms=decode_ms,
                    pose_diagnostics=pose_estimator.last_diagnostics,
                    history=history,
                )
            if publish_due and display is not None and debug_server is not None:
                next_publish = max(next_publish + publish_period, now)
                ok, encoded = cv2.imencode(
                    ".jpg",
                    display,
                    [cv2.IMWRITE_JPEG_QUALITY, config.debug.jpeg_quality],
                )
                if ok:
                    debug_server.publish(
                        snapshot.sequence,
                        snapshot.timestamp_ns,
                        encoded.tobytes(),
                    )

            if local_enabled and display is not None:
                _draw_toolbar(display)
                cv2.imshow("H Ball Raw Rail Probe", display)
                key = cv2.waitKey(1) & 0xFF
                action = ""
                try:
                    action = mouse_events.get_nowait()
                except queue.Empty:
                    pass
                if key in (ord("q"), ord("Q"), 27) or action == "QUIT":
                    break
                if key in (ord("r"), ord("R")) or action == "RESET":
                    pose_estimator.reset()
                    tracker.reset()
                    history.clear()
                elif key in (ord("b"), ord("B")) or action == "BG":
                    tracker.reset()
                    history.clear()
                    last_sequence, locked_pose = _capture_registered_background(
                        camera,
                        pose_estimator,
                        detector,
                        (config.camera.height, config.camera.width),
                        30,
                        last_sequence,
                    )
                    status["registered_background_ready"] = True
                elif key in (ord("s"), ord("S")) or action == "SHOT":
                    _save_screenshot(config, display)
                elif key in (ord("f"), ord("F")) or action == "FULL":
                    fullscreen = not fullscreen
                    cv2.setWindowProperty(
                        "H Ball Raw Rail Probe",
                        cv2.WND_PROP_FULLSCREEN,
                        cv2.WINDOW_FULLSCREEN if fullscreen else cv2.WINDOW_NORMAL,
                    )
    finally:
        status["state"] = "STOPPING"
        if debug_server is not None:
            debug_server.close()
        if raw_server is not None:
            raw_server.close()
        camera.close()
        if local_enabled:
            cv2.destroyAllWindows()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="原始 BGR 轨道上下文钢球视觉验证（无控制输出）"
    )
    parser.add_argument(
        "--mode",
        choices=("local", "server", "both"),
        default="server",
    )
    parser.add_argument(
        "--config",
        default=str(PROJECT_ROOT / "config" / "pi.toml"),
    )
    parser.add_argument(
        "--dynamic-rail",
        action="store_true",
        help="use live rail quadrilateral; default locks the 30-frame median pose",
    )
    parser.add_argument(
        "--rail-diagnostics",
        action="store_true",
        help=(
            "start raw/debug servers without requiring a registered background; "
            "only diagnose live green-rail pose"
        ),
    )
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    try:
        run(
            args.config,
            args.mode,
            lock_rail=not args.dynamic_rail and not args.rail_diagnostics,
            rail_diagnostics=args.rail_diagnostics,
        )
    except KeyboardInterrupt:
        LOG.info("rail context probe stopped")


if __name__ == "__main__":
    main()
