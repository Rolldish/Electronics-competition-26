"""Read-only competition preflight with an empty rail."""

from __future__ import annotations

import argparse
import json
import logging
import subprocess
import time
from pathlib import Path

import cv2
import numpy as np

from hball.algorithms.competition_vision import CompetitionRailVision
from hball.algorithms.runtime_profile import resolve_runtime_vision_profile
from hball.common.config import load_config
from hball.drivers.network import check_hotspot
from hball.drivers.usb_serial import resolve_usb_serial_port
from hball.threads.camera import LatestMjpegCamera


LOG = logging.getLogger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _percentile95(values: list[float]) -> float:
    return float(np.percentile(values, 95.0)) if values else float("inf")


def _platform_realtime_status() -> dict[str, object]:
    governor_paths = sorted(
        Path("/sys/devices/system/cpu/cpufreq").glob(
            "policy*/scaling_governor"
        )
    )
    governors: list[str] = []
    for path in governor_paths:
        try:
            governors.append(path.read_text(encoding="ascii").strip())
        except OSError:
            governors.append("UNREADABLE")

    temperature_c: float | None = None
    try:
        raw_temperature = Path(
            "/sys/class/thermal/thermal_zone0/temp"
        ).read_text(encoding="ascii")
        temperature_c = float(raw_temperature.strip()) / 1_000.0
    except (OSError, ValueError):
        pass

    throttled_mask: int | None = None
    throttled_error: str | None = None
    try:
        result = subprocess.run(
            ["vcgencmd", "get_throttled"],
            check=False,
            capture_output=True,
            text=True,
            timeout=1.0,
        )
        if result.returncode != 0:
            throttled_error = result.stderr.strip() or f"exit={result.returncode}"
        else:
            value = result.stdout.strip().split("=", 1)[-1]
            throttled_mask = int(value, 16)
    except (FileNotFoundError, OSError, ValueError, subprocess.TimeoutExpired) as error:
        throttled_error = str(error)

    return {
        "governors": governors,
        "performance_governor": bool(governors)
        and all(value == "performance" for value in governors),
        "cpu_temperature_c": (
            None if temperature_c is None else round(temperature_c, 1)
        ),
        "throttled_mask": throttled_mask,
        "throttled": throttled_mask is None or throttled_mask != 0,
        "throttled_error": throttled_error,
    }


def run(config_path: str) -> dict[str, object]:
    config = load_config(config_path)
    profile = resolve_runtime_vision_profile(config)
    expected_shape = (config.camera.height, config.camera.width)
    limits = config.preflight

    serial_port: str | None = None
    serial_error: str | None = None
    if config.serial.enabled:
        try:
            serial_port = resolve_usb_serial_port(config.serial.port)
        except (OSError, RuntimeError, ValueError) as error:
            serial_error = str(error)
    serial_ready = config.serial.enabled and serial_port is not None

    hotspot = check_hotspot(config.network)
    hotspot_ready = config.network.enabled and hotspot.ready
    platform = _platform_realtime_status()
    checks: dict[str, object] = {
        "profile": profile.profile_id,
        "instruction": "REMOVE_BALL_KEEP_RAIL_STILL",
        "camera_controls": {
            "source": config.camera_controls_source,
            "exposure": profile.camera_config.exposure,
            "gain": profile.camera_config.gain,
            "white_balance_temperature": (
                profile.camera_config.white_balance_temperature
            ),
        },
        "runtime_targets": {
            "camera_fps": config.camera.fps,
            "vision_fps": config.runtime.control_target_vision_fps,
            "minimum_vision_fps": config.runtime.control_min_vision_fps,
            "video_fps": config.video.fps,
            "balllink_tx_hz": config.serial.tx_hz,
        },
        "serial_ready": serial_ready,
        "serial_port": serial_port,
        "serial_error": serial_error,
        "hotspot_ready": hotspot_ready,
        "hotspot": hotspot.to_dict(),
        "platform": platform,
    }

    pipeline = CompetitionRailVision(profile.vision_config)
    camera = LatestMjpegCamera(profile.camera_config)
    processed = 0
    processing_ms: list[float] = []
    false_positive_frames = 0
    pose_confidences: list[float] = []
    measurement_started: float | None = None
    last_sequence = -1
    background_failed = False
    started = time.monotonic()
    deadline = started + limits.total_timeout_s
    try:
        camera.start()
        while time.monotonic() < deadline:
            snapshot = camera.wait_next(last_sequence, timeout_s=0.5)
            if snapshot is None:
                if not camera.running:
                    raise RuntimeError("摄像头采集进程已退出")
                continue
            last_sequence = snapshot.sequence
            frame = cv2.imdecode(
                np.frombuffer(snapshot.jpeg, dtype=np.uint8),
                cv2.IMREAD_COLOR,
            )
            if frame is None or frame.shape[:2] != expected_shape:
                continue
            vision = pipeline.process(frame, snapshot.timestamp_ns)
            if vision.background_failed:
                background_failed = True
                break
            if not vision.background_ready:
                continue
            if measurement_started is None:
                measurement_started = time.monotonic()
            processed += 1
            processing_ms.append(vision.processing_ms)
            if vision.result is not None and vision.result.accepted:
                false_positive_frames += 1
            if vision.pose is not None:
                pose_confidences.append(float(vision.pose.confidence))
            if time.monotonic() - measurement_started >= limits.empty_test_s:
                break
    finally:
        camera.close()

    duration_s = (
        0.0 if measurement_started is None else time.monotonic() - measurement_started
    )
    vision_fps = processed / duration_s if duration_s > 0.0 else 0.0
    false_positive_rate = false_positive_frames / max(processed, 1)
    pose_confidence = min(pose_confidences) if pose_confidences else 0.0
    p95_processing_ms = _percentile95(processing_ms)
    camera_fps = float(camera.capture_fps)

    checks.update(
        {
            "background_ready": pipeline.background_ready,
            "background_failed": background_failed,
            "background_frames": pipeline.background_frames,
            "background_required": pipeline.background_required,
            "camera_fps": round(camera_fps, 2),
            "vision_fps": round(vision_fps, 2),
            "p95_processing_ms": round(p95_processing_ms, 2),
            "empty_frames": processed,
            "empty_false_positive_frames": false_positive_frames,
            "empty_false_positive_rate": round(false_positive_rate, 4),
            "minimum_pose_confidence": round(pose_confidence, 4),
            "thresholds": {
                "min_camera_fps": limits.min_camera_fps,
                "min_vision_fps": limits.min_vision_fps,
                "max_p95_processing_ms": limits.max_p95_processing_ms,
                "max_empty_false_positive_rate": (
                    limits.max_empty_false_positive_rate
                ),
                "min_pose_confidence": limits.min_pose_confidence,
                "max_cpu_temperature_c": (
                    limits.max_cpu_temperature_c
                ),
            },
        }
    )
    gates = {
        "background": pipeline.background_ready and not background_failed,
        "camera_fps": camera_fps >= limits.min_camera_fps,
        "vision_fps": vision_fps >= limits.min_vision_fps,
        "processing": p95_processing_ms <= limits.max_p95_processing_ms,
        "empty_false_positive": (
            false_positive_rate <= limits.max_empty_false_positive_rate
        ),
        "pose": pose_confidence >= limits.min_pose_confidence,
        "serial": not limits.require_serial or serial_ready,
        "hotspot": not limits.require_hotspot or hotspot_ready,
        "cpu_governor": (
            not limits.require_performance_governor
            or bool(platform["performance_governor"])
        ),
        "cpu_temperature": (
            platform["cpu_temperature_c"] is not None
            and float(platform["cpu_temperature_c"])
            <= limits.max_cpu_temperature_c
        ),
        "not_throttled": (
            not limits.reject_throttled
            or not bool(platform["throttled"])
        ),
    }
    checks["gates"] = gates
    checks["passed"] = all(gates.values())
    checks["next_step"] = (
        "BALL CHECK: place ball and verify continuous position"
        if checks["passed"]
        else "fix failed gates and rerun PREFLIGHT"
    )
    print(json.dumps(checks, ensure_ascii=False, indent=2))
    return checks


def main() -> None:
    parser = argparse.ArgumentParser(
        description="上机前空轨校验：背景、帧率、耗时、误检、轨道、串口和热点"
    )
    parser.add_argument("--config", default=str(PROJECT_ROOT / "config" / "pi.toml"))
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    if not run(args.config)["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
