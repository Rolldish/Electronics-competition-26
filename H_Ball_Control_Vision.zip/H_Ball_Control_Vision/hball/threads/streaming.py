"""Low-rate MJPEG HTTP publishing workers."""

from __future__ import annotations

import json
import logging
import mimetypes
import threading
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable

from .camera import LatestMjpegCamera, MjpegSnapshot
from ..common.config import VideoConfig


LOG = logging.getLogger(__name__)
WEB_ROOT = Path(__file__).resolve().parents[2] / "web"
WEB_ROUTES = {
    "/": "index.html",
    "/index.html": "index.html",
    "/app.js": "app.js",
    "/style.css": "style.css",
    "/manifest.webmanifest": "manifest.webmanifest",
    "/icon.svg": "icon.svg",
}


class JpegHub:
    def __init__(self) -> None:
        self._condition = threading.Condition()
        self._latest: MjpegSnapshot | None = None
        self._closed = False

    def publish(self, snapshot: MjpegSnapshot) -> None:
        with self._condition:
            self._latest = snapshot
            self._condition.notify_all()

    def latest(self) -> MjpegSnapshot | None:
        with self._condition:
            return self._latest

    def wait_next(self, after_sequence: int, timeout_s: float) -> MjpegSnapshot | None:
        deadline = time.monotonic() + timeout_s
        with self._condition:
            while not self._closed:
                if self._latest is not None and self._latest.sequence != after_sequence:
                    return self._latest
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)
        return None

    def close(self) -> None:
        with self._condition:
            self._closed = True
            self._condition.notify_all()

    @property
    def closed(self) -> bool:
        with self._condition:
            return self._closed


class _MjpegServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        address: tuple[str, int],
        hub: JpegHub,
        status_provider: Callable[[], dict],
    ) -> None:
        super().__init__(address, _MjpegHandler)
        self.hub = hub
        self.status_provider = status_provider


class _MjpegHandler(BaseHTTPRequestHandler):
    server: _MjpegServer
    protocol_version = "HTTP/1.1"

    def do_GET(self) -> None:
        path = self.path.split("?", 1)[0]
        if path in WEB_ROUTES:
            self._send_static(WEB_ROUTES[path])
        elif path == "/healthz":
            self._send_bytes(b"ok\n", "text/plain; charset=utf-8")
        elif path == "/status.json":
            payload = json.dumps(
                self.server.status_provider(), ensure_ascii=False
            ).encode("utf-8")
            self._send_bytes(payload, "application/json; charset=utf-8")
        elif path == "/snapshot.jpg":
            snapshot = self.server.hub.latest()
            if snapshot is None:
                self.send_error(HTTPStatus.SERVICE_UNAVAILABLE, "No frame")
            else:
                self._send_bytes(snapshot.jpeg, "image/jpeg")
        elif path == "/stream.mjpg":
            self._stream()
        else:
            self.send_error(HTTPStatus.NOT_FOUND)

    def _send_static(self, relative_path: str) -> None:
        path = WEB_ROOT / relative_path
        try:
            payload = path.read_bytes()
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content_type = mimetypes.guess_type(path.name)[0]
        if path.suffix in {".js", ".webmanifest"}:
            content_type = {
                ".js": "text/javascript; charset=utf-8",
                ".webmanifest": "application/manifest+json; charset=utf-8",
            }[path.suffix]
        elif content_type and content_type.startswith("text/"):
            content_type += "; charset=utf-8"
        self._send_bytes_with_options(
            payload,
            content_type or "application/octet-stream",
            content_security_policy=True,
        )

    def _send_bytes(self, payload: bytes, content_type: str) -> None:
        self._send_bytes_with_options(payload, content_type)

    def _send_bytes_with_options(
        self,
        payload: bytes,
        content_type: str,
        *,
        content_security_policy: bool = False,
    ) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if content_security_policy:
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; img-src 'self' data:; "
                "media-src 'self' blob:; script-src 'self'; "
                "style-src 'self'; connect-src 'self'; "
                "object-src 'none'; base-uri 'none'",
            )
        self.end_headers()
        self.wfile.write(payload)

    def _stream(self) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.end_headers()
        sequence = -1
        try:
            while True:
                snapshot = self.server.hub.wait_next(sequence, 2.0)
                if snapshot is None:
                    if self.server.hub.closed:
                        return
                    continue
                sequence = snapshot.sequence
                self.wfile.write(b"--frame\r\n")
                self.wfile.write(b"Content-Type: image/jpeg\r\n")
                self.wfile.write(f"Content-Length: {len(snapshot.jpeg)}\r\n\r\n".encode("ascii"))
                self.wfile.write(snapshot.jpeg)
                self.wfile.write(b"\r\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            return

    def log_message(self, format: str, *args) -> None:
        LOG.debug("HTTP %s - %s", self.client_address[0], format % args)


class PassthroughVideoServer:
    """Sample original camera JPEGs at a lower FPS and wrap them as HTTP MJPEG."""

    def __init__(
        self,
        camera: LatestMjpegCamera,
        config: VideoConfig,
        status_provider: Callable[[], dict],
    ) -> None:
        self.camera = camera
        self.config = config
        self.status_provider = status_provider
        self.hub = JpegHub()
        self._stop = threading.Event()
        self._sampler_thread: threading.Thread | None = None
        self._server: _MjpegServer | None = None
        self._server_thread: threading.Thread | None = None
        self._rate_lock = threading.Lock()
        self._effective_fps = float(config.fps)
        self._ready_since: float | None = None

    @property
    def bound_port(self) -> int | None:
        return None if self._server is None else int(self._server.server_port)

    @property
    def effective_fps(self) -> float:
        with self._rate_lock:
            return self._effective_fps

    def start(self) -> None:
        if not self.config.enabled:
            return
        if self.config.annotate:
            LOG.warning("video.annotate ignored: raw JPEG passthrough is enabled")
        self._server = _MjpegServer(
            (self.config.bind, self.config.port),
            self.hub,
            self.status_provider,
        )
        self._stop.clear()
        self._server_thread = threading.Thread(
            target=self._server.serve_forever,
            name="mjpeg-http",
            daemon=True,
        )
        self._sampler_thread = threading.Thread(
            target=self._sample_loop,
            name="mjpeg-sampler",
            daemon=True,
        )
        self._server_thread.start()
        self._sampler_thread.start()
        LOG.info(
            "raw MJPEG passthrough: http://%s:%d/stream.mjpg at %.1f fps",
            self.config.bind,
            self._server.server_port,
            self.config.fps,
        )

    def _sample_loop(self) -> None:
        deadline = time.monotonic()
        last_sequence = -1
        while not self._stop.is_set():
            target_fps = self._target_fps()
            with self._rate_lock:
                previous_fps = self._effective_fps
                self._effective_fps = target_fps
            if abs(target_fps - previous_fps) >= 0.5:
                LOG.info(
                    "video sampling changed %.1f -> %.1f fps (%s)",
                    previous_fps,
                    target_fps,
                    "control priority"
                    if target_fps < self.config.fps
                    else "vision recovered",
                )
            period = 1.0 / target_fps
            now = time.monotonic()
            if now < deadline:
                self._stop.wait(deadline - now)
                continue
            deadline = max(deadline + period, now)
            snapshot = self.camera.latest()
            if snapshot is not None and snapshot.sequence != last_sequence:
                self.hub.publish(snapshot)
                last_sequence = snapshot.sequence

    def _target_fps(self) -> float:
        if not self.config.control_priority:
            self._ready_since = None
            return float(self.config.fps)
        status = self.status_provider()
        node_mode = str(status.get("node_mode", ""))
        control_active = node_mode in {
            "TASK",
            "VISION",
            "BACKGROUND",
            "SETUP",
        }
        if not control_active:
            self._ready_since = None
            return float(self.config.fps)

        now = time.monotonic()
        if status.get("video_full_rate_safe") is True:
            if self._ready_since is None:
                self._ready_since = now
            if now - self._ready_since >= self.config.recovery_hold_s:
                return float(self.config.fps)
        else:
            self._ready_since = None
        return float(self.config.degraded_fps)

    def close(self) -> None:
        self._stop.set()
        self.hub.close()
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        for thread in (self._sampler_thread, self._server_thread):
            if thread is not None:
                thread.join(timeout=1.0)
        self._sampler_thread = None
        self._server_thread = None


class PublishedVideoServer:
    """Serve JPEG frames supplied by a producer, used only by the debug viewer."""

    def __init__(
        self,
        bind: str,
        port: int,
        status_provider: Callable[[], dict],
    ) -> None:
        self.bind = bind
        self.port = port
        self.status_provider = status_provider
        self.hub = JpegHub()
        self._server: _MjpegServer | None = None
        self._server_thread: threading.Thread | None = None

    @property
    def bound_port(self) -> int | None:
        return None if self._server is None else int(self._server.server_port)

    def start(self) -> None:
        if self._server is not None:
            return
        self._server = _MjpegServer(
            (self.bind, self.port),
            self.hub,
            self.status_provider,
        )
        self._server_thread = threading.Thread(
            target=self._server.serve_forever,
            name="debug-mjpeg-http",
            daemon=True,
        )
        self._server_thread.start()
        LOG.info(
            "debug MJPEG: http://%s:%d/stream.mjpg",
            self.bind,
            self._server.server_port,
        )

    def publish(self, sequence: int, timestamp_ns: int, jpeg: bytes) -> None:
        self.hub.publish(MjpegSnapshot(sequence, timestamp_ns, jpeg))

    def close(self) -> None:
        self.hub.close()
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._server_thread is not None:
            self._server_thread.join(timeout=1.0)
            self._server_thread = None
