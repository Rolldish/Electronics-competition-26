"""Latest-frame USB MJPEG camera acquisition worker."""

from __future__ import annotations

import logging
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass

from ..common.config import CameraConfig
from ..drivers.mjpeg import V4l2FramedJpegParser


LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class MjpegSnapshot:
    sequence: int
    timestamp_ns: int
    jpeg: bytes


class LatestMjpegCamera:
    """Own one V4L2 stream and publish only the newest original JPEG frame.

    `v4l2-ctl` performs MMAP capture. The bytes from stdout are the UVC camera's
    JPEG payloads, so the network branch never decodes or re-encodes them.
    """

    def __init__(self, config: CameraConfig) -> None:
        self.config = config
        self._condition = threading.Condition()
        self._latest: MjpegSnapshot | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._stderr_thread: threading.Thread | None = None
        self._process: subprocess.Popen[bytes] | None = None
        self._stderr_tail = bytearray()
        self._capture_fps = 0.0
        self._average_jpeg_bytes = 0.0

    @property
    def device_path(self) -> str:
        return f"/dev/video{self.config.device}"

    @property
    def running(self) -> bool:
        return self._process is not None and self._process.poll() is None

    @property
    def capture_fps(self) -> float:
        with self._condition:
            return self._capture_fps

    @property
    def average_jpeg_bytes(self) -> float:
        with self._condition:
            return self._average_jpeg_bytes

    def start(self) -> None:
        if self._thread is not None:
            return
        if not self.config.raw_mjpeg_passthrough:
            raise RuntimeError(
                "本工程的生产链路要求 camera.raw_mjpeg_passthrough=true；"
                "否则 OpenCV 会先解码，无法原始 MJPEG 直通"
            )
        executable = shutil.which("v4l2-ctl")
        if executable is None:
            raise RuntimeError("缺少 v4l2-ctl，请安装: sudo apt install v4l-utils")

        with self._condition:
            self._latest = None
            self._stderr_tail.clear()
        self._apply_controls(executable)
        command = [
            executable,
            f"--device={self.device_path}",
            (
                "--set-fmt-video="
                f"width={self.config.width},height={self.config.height},"
                f"pixelformat={self.config.fourcc}"
            ),
            f"--set-parm={self.config.fps}",
            f"--stream-mmap={self.config.mmap_buffers}",
            "--stream-to-hdr=-",
        ]
        self._process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,
        )
        self._stop.clear()
        assert self._process.stderr is not None
        self._stderr_thread = threading.Thread(
            target=self._stderr_loop,
            args=(self._process.stderr,),
            name="mjpeg-camera-stderr",
            daemon=True,
        )
        self._stderr_thread.start()
        self._thread = threading.Thread(target=self._capture_loop, name="mjpeg-camera", daemon=True)
        self._thread.start()

        deadline = time.monotonic() + 3.0
        with self._condition:
            while self._latest is None and time.monotonic() < deadline:
                if self._process.poll() is not None:
                    break
                self._condition.wait(0.1)
        if self._latest is None:
            process = self._process
            self.close()
            code = process.returncode
            detail = self._stderr_text()
            hint = self._failure_hint(detail)
            raise RuntimeError(
                f"未从 {self.device_path} 收到 MJPEG 帧，"
                f"v4l2-ctl exit={code}; {hint}; stderr={detail or '无输出'}"
            )
        LOG.info(
            "raw MJPEG camera ready: %s %dx%d@%d requested",
            self.device_path,
            self.config.width,
            self.config.height,
            self.config.fps,
        )

    def _apply_controls(self, executable: str) -> None:
        controls: list[tuple[tuple[str, ...], int]] = [
            (("auto_exposure", "exposure_auto"), 3 if self.config.auto_exposure else 1),
            (
                ("exposure_dynamic_framerate",),
                1 if self.config.exposure_dynamic_framerate else 0,
            ),
            (("gain",), self.config.gain),
            (
                ("white_balance_automatic", "white_balance_temperature_auto"),
                1 if self.config.auto_white_balance else 0,
            ),
        ]
        if not self.config.auto_exposure:
            controls.append(
                (("exposure_time_absolute", "exposure_absolute"), self.config.exposure)
            )
        if not self.config.auto_white_balance:
            controls.append(
                (("white_balance_temperature",), self.config.white_balance_temperature)
            )

        for names, value in controls:
            errors: list[str] = []
            for name in names:
                control = f"{name}={value}"
                result = subprocess.run(
                    [executable, f"--device={self.device_path}", "-c", control],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if result.returncode == 0:
                    break
                errors.append(result.stderr.strip())
            else:
                LOG.warning(
                    "v4l2 controls %s rejected: %s",
                    "/".join(names),
                    errors[-1] if errors else "unknown error",
                )

    def set_manual_controls(
        self,
        *,
        exposure: int,
        gain: int,
        white_balance_temperature: int,
    ) -> bool:
        """Best-effort live UVC control update used by field auto-calibration.

        Cameras use slightly different V4L2 control names, so every logical
        setting has a short alias list.  Returning ``False`` means at least one
        required control was unsupported; callers must keep the configured
        values and report that automatic camera tuning was skipped.
        """

        executable = shutil.which("v4l2-ctl")
        if executable is None:
            return False
        controls: list[tuple[tuple[str, ...], int]] = [
            (("auto_exposure", "exposure_auto"), 1),
            (("exposure_dynamic_framerate",), 0),
            (("exposure_time_absolute", "exposure_absolute"), int(exposure)),
            (("gain",), int(gain)),
            (
                ("white_balance_automatic", "white_balance_temperature_auto"),
                0,
            ),
            (("white_balance_temperature",), int(white_balance_temperature)),
        ]
        all_applied = True
        for names, value in controls:
            applied = False
            for name in names:
                result = subprocess.run(
                    [
                        executable,
                        f"--device={self.device_path}",
                        "-c",
                        f"{name}={value}",
                    ],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if result.returncode == 0:
                    applied = True
                    break
            all_applied &= applied
        return all_applied

    def _capture_loop(self) -> None:
        assert self._process is not None and self._process.stdout is not None
        stream = self._process.stdout
        parser = V4l2FramedJpegParser()
        sequence = 0
        warmup_remaining = self.config.warmup_frames
        interval_start = time.monotonic()
        interval_frames = 0
        interval_bytes = 0
        while not self._stop.is_set():
            chunk = stream.read(65536)
            if not chunk:
                break
            for jpeg in parser.push(chunk):
                if warmup_remaining > 0:
                    warmup_remaining -= 1
                    continue
                sequence = (sequence + 1) & 0xFFFFFFFF
                snapshot = MjpegSnapshot(sequence, time.monotonic_ns(), jpeg)
                interval_frames += 1
                interval_bytes += len(jpeg)
                now = time.monotonic()
                with self._condition:
                    self._latest = snapshot
                    if now - interval_start >= 1.0:
                        self._capture_fps = interval_frames / (now - interval_start)
                        self._average_jpeg_bytes = interval_bytes / interval_frames
                        interval_start = now
                        interval_frames = 0
                        interval_bytes = 0
                    self._condition.notify_all()
        with self._condition:
            self._condition.notify_all()

    def _stderr_loop(self, stream) -> None:
        """Drain v4l2 stderr so it cannot block, retaining only a short tail."""

        while True:
            chunk = stream.read(1024)
            if not chunk:
                break
            with self._condition:
                self._stderr_tail.extend(chunk)
                if len(self._stderr_tail) > 8192:
                    del self._stderr_tail[:-8192]

    def _stderr_text(self) -> str:
        with self._condition:
            raw = bytes(self._stderr_tail)
        return raw.decode("utf-8", errors="replace").strip()

    @staticmethod
    def _failure_hint(detail: str) -> str:
        lowered = detail.lower()
        if "busy" in lowered or "resource temporarily unavailable" in lowered:
            return "摄像头正被其他进程占用，请先停止主程序、视觉测试或旧的 v4l2-ctl"
        if "no such file" in lowered or "cannot open device" in lowered:
            return "摄像头设备不存在或已掉线，请检查 /dev/video0 和 USB 连接"
        if "invalid argument" in lowered or "not supported" in lowered:
            return "摄像头不接受当前分辨率、帧率或 MJPG 格式"
        if "input/output error" in lowered or "i/o error" in lowered:
            return "摄像头或 USB 链路发生 I/O 错误，请检查供电、接口和内核日志"
        return "请运行 lsof /dev/video0 并用 v4l2-ctl 单独采集以查看设备状态"

    def latest(self) -> MjpegSnapshot | None:
        with self._condition:
            return self._latest

    def wait_next(self, after_sequence: int, timeout_s: float = 0.5) -> MjpegSnapshot | None:
        deadline = time.monotonic() + timeout_s
        with self._condition:
            while not self._stop.is_set():
                if self._latest is not None and self._latest.sequence != after_sequence:
                    return self._latest
                if self._process is not None and self._process.poll() is not None:
                    return None
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)
        return None

    def close(self) -> None:
        self._stop.set()
        process = self._process
        if process is not None and process.poll() is None:
            process.terminate()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None
        if process is not None:
            try:
                process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1.0)
        if self._stderr_thread is not None:
            self._stderr_thread.join(timeout=1.0)
            self._stderr_thread = None
        self._process = None
        with self._condition:
            self._condition.notify_all()

    def __enter__(self) -> "LatestMjpegCamera":
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()
