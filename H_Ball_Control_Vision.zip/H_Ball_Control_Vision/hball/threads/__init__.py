"""Long-running camera, video, and real-time processing workers."""
