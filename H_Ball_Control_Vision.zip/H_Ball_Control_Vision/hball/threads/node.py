"""Real-time vision, telemetry, task, and video orchestration loop."""

from __future__ import annotations

import argparse
import gc
import logging
import queue
import sys
import threading
import time
from collections import Counter
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import cv2
import numpy as np

from hball.algorithms.axis_tracker import AxisTrackEstimate
from hball.algorithms.competition_vision import CompetitionRailVision
from hball.algorithms.rail_context_detector import (
    RailBallCandidate,
)
from hball.algorithms.runtime_profile import resolve_runtime_vision_profile
from hball.common.config import load_config
from hball.drivers.links import BallLinkPublisher, UdpPublisher
from hball.drivers.protocol import (
    MEASUREMENT_MAX_AGE_US,
    Flags,
    TaskId,
    TxSnapshot,
)
from hball.tasks.controller import BallTaskController
from hball.threads.camera import LatestMjpegCamera
from hball.threads.streaming import PassthroughVideoServer


LOG = logging.getLogger(__name__)


class StatusStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._value: dict = {"state": "STARTING"}

    def set(self, value: dict) -> None:
        with self._lock:
            self._value = value

    def get(self) -> dict:
        with self._lock:
            return dict(self._value)

    def update(self, **values: object) -> None:
        with self._lock:
            self._value.update(values)


def _flags(
    estimate: AxisTrackEstimate,
    pose_valid: bool,
    calibration_ready: bool,
    minimum_confidence: float,
    processing_degraded: bool = False,
) -> Flags:
    flags = Flags(0)
    if calibration_ready:
        flags |= Flags.CAMERA_CALIBRATED
    if (
        calibration_ready
        and estimate.control_valid
        and pose_valid
        and estimate.confidence >= minimum_confidence
        and not processing_degraded
    ):
        flags |= Flags.BALL_VALID | Flags.VELOCITY_VALID
    if processing_degraded or not calibration_ready or not pose_valid:
        flags |= Flags.PROCESSING_DEGRADED
    return flags


def _candidate_payload(
    candidate: RailBallCandidate | None,
) -> dict | None:
    if candidate is None:
        return None
    return {
        "x_px": round(candidate.x_px, 2),
        "y_px": round(candidate.y_px, 2),
        "radius_px": round(candidate.radius_px, 2),
        "expected_radius_px": round(candidate.expected_radius_px, 2),
        "radius_error_ratio": round(candidate.radius_error_ratio, 4),
        "axis_fraction": round(candidate.axis_fraction, 6),
        "cross_axis_px": round(candidate.cross_axis_px, 2),
        "score": round(candidate.score, 4),
        "accepted": candidate.accepted,
        "rejection": candidate.rejection,
        "source": candidate.source,
        "circularity": round(candidate.circularity, 4),
        "fit_valid": candidate.fit_valid,
        "fit_error_ratio": round(candidate.fit_error_ratio, 4),
        "edge_coverage": round(candidate.edge_coverage, 4),
        "radial_score": round(candidate.radial_score, 4),
        "change_ratio": round(candidate.change_ratio, 4),
        "non_green_ratio": round(candidate.non_green_ratio, 4),
        "green_annulus_ratio": round(
            candidate.green_annulus_ratio,
            4,
        ),
        "achromatic_ratio": round(candidate.achromatic_ratio, 4),
    }


def _read_commands(commands: queue.Queue[str]) -> None:
    try:
        for line in sys.stdin:
            command = line.strip().upper()
            if command:
                try:
                    commands.put_nowait(command)
                except queue.Full:
                    pass
    except (OSError, ValueError):
        return


def run(
    config_path: str,
    task_id: TaskId = TaskId.IDLE,
    run_id: int | None = None,
) -> None:
    config = load_config(config_path)
    cv2.setNumThreads(config.runtime.opencv_threads)
    expected_shape = (config.camera.height, config.camera.width)
    profile = resolve_runtime_vision_profile(config)
    vision_config = profile.vision_config
    camera_config = profile.camera_config
    profile_id = profile.profile_id
    pipeline = CompetitionRailVision(vision_config)
    calibration_ready = False
    task = BallTaskController(
        config.task,
        task_id,
        run_id=run_id,
        minimum_position_m=vision_config.mapping.negative_position_m,
        maximum_position_m=vision_config.mapping.positive_position_m,
    )
    node_mode = "TASK" if task_id != TaskId.IDLE else "IDLE"
    process_all_frames = task_id != TaskId.IDLE
    start_requested = False
    udp = UdpPublisher(config.telemetry_udp)
    packet_sinks = (udp.send,) if config.telemetry_udp.enabled else ()
    serial = BallLinkPublisher(config.serial, packet_sinks=packet_sinks)
    status = StatusStore()
    camera = LatestMjpegCamera(camera_config)
    video = PassthroughVideoServer(camera, config.video, status.get)
    commands: queue.Queue[str] = queue.Queue(maxsize=8)
    command_thread = threading.Thread(
        target=_read_commands,
        args=(commands,),
        name="panel-command",
        daemon=True,
    )

    last_camera_sequence = -1
    interval_start = time.monotonic()
    interval_frames = 0
    ewma_ms = 0.0
    vision_fps_ewma = 0.0
    last_processed_capture_ns: int | None = None
    next_idle_process = 0.0
    next_status_update = 0.0
    superseded_camera_frames = 0
    stale_before_decode_frames = 0
    maximum_frame_start_age_ms = 0.0
    maximum_result_age_ms = 0.0
    realtime_window_ready = False
    setup_phase = "IDLE"
    setup_empty_consecutive = 0
    setup_ball_consecutive = 0
    setup_error: str | None = None
    active_camera_controls = {
        "source": config.camera_controls_source,
        "exposure": camera_config.exposure,
        "gain": camera_config.gain,
        "white_balance_temperature": (
            camera_config.white_balance_temperature
        ),
    }
    gc_was_enabled = gc.isenabled()
    previous_switch_interval = sys.getswitchinterval()

    try:
        camera.start()
        sys.setswitchinterval(
            config.runtime.python_switch_interval_ms / 1_000.0
        )
        serial.start()
        video.start()
        command_thread.start()
        if config.runtime.disable_gc_during_realtime and gc_was_enabled:
            gc.collect()
            gc.disable()
            LOG.info("automatic cyclic GC disabled for deterministic vision timing")
        LOG.info(
            "runtime registered-rail vision task=%s run=%d; "
            "remove ball during %d-frame background capture",
            task_id.name,
            task.run_id,
            config.runtime.startup_background_frames,
        )
        while True:
            snapshot = camera.wait_next(last_camera_sequence, timeout_s=0.5)
            if snapshot is None:
                status.set(
                    {
                        "state": "CAMERA_TIMEOUT",
                        "task_id": int(task.task_id),
                        "run_id": task.run_id,
                    }
                )
                if not camera.running:
                    raise RuntimeError("v4l2-ctl 摄像头采集进程已退出")
                continue
            now = time.monotonic()
            while True:
                try:
                    command = commands.get_nowait()
                except queue.Empty:
                    break
                parts = command.split()
                verb = parts[0]
                if verb == "TASK" and len(parts) >= 2:
                    try:
                        selected = TaskId[parts[1]]
                    except KeyError:
                        LOG.warning("ignored unknown task command: %s", command)
                        continue
                    target_m = None
                    if selected == TaskId.T6 and len(parts) >= 3:
                        try:
                            target_m = float(parts[2]) / 100.0
                        except ValueError:
                            LOG.warning("ignored invalid T6 target: %s", command)
                            continue
                    task = BallTaskController(
                        config.task,
                        selected,
                        target_x_m=target_m,
                        minimum_position_m=(
                            vision_config.mapping.negative_position_m
                        ),
                        maximum_position_m=(
                            vision_config.mapping.positive_position_m
                        ),
                    )
                    pipeline.reset()
                    setup_phase = "IDLE"
                    node_mode = "TASK"
                    process_all_frames = True
                    start_requested = False
                    LOG.info(
                        "armed task=%s target=%+.1fcm run=%d",
                        selected.name,
                        task.target_x_m * 100.0,
                        task.run_id,
                    )
                elif verb in {"IDLE", "VIDEO"}:
                    task = BallTaskController(
                        config.task,
                        TaskId.IDLE,
                        minimum_position_m=(
                            vision_config.mapping.negative_position_m
                        ),
                        maximum_position_m=(
                            vision_config.mapping.positive_position_m
                        ),
                    )
                    pipeline.reset()
                    setup_phase = "IDLE"
                    node_mode = "VIDEO" if verb == "VIDEO" else "IDLE"
                    process_all_frames = False
                    start_requested = False
                    LOG.info("node returned to %s", node_mode)
                elif verb == "VISION":
                    task = BallTaskController(
                        config.task,
                        TaskId.IDLE,
                        minimum_position_m=(
                            vision_config.mapping.negative_position_m
                        ),
                        maximum_position_m=(
                            vision_config.mapping.positive_position_m
                        ),
                    )
                    pipeline.reset()
                    setup_phase = "IDLE"
                    node_mode = "VISION"
                    process_all_frames = True
                    start_requested = False
                    LOG.info("full-rate vision diagnostic mode")
                elif verb == "CHECK":
                    task = BallTaskController(
                        config.task,
                        TaskId.IDLE,
                        minimum_position_m=(
                            vision_config.mapping.negative_position_m
                        ),
                        maximum_position_m=(
                            vision_config.mapping.positive_position_m
                        ),
                    )
                    start_requested = False
                    setup_error = None
                    setup_empty_consecutive = 0
                    setup_ball_consecutive = 0
                    node_mode = "SETUP"
                    pipeline.restart_background()
                    calibration_ready = False
                    setup_phase = "BACKGROUND"
                    process_all_frames = True
                    status.update(setup_phase=setup_phase)
                    LOG.info(
                        "READY CHECK started with a fresh background"
                    )
                elif verb == "START":
                    start_requested = True
                elif verb == "RESET":
                    pipeline.reset()
                    LOG.info("vision tracker reset")
                elif verb in {"BACKGROUND", "BG"}:
                    task = BallTaskController(
                        config.task,
                        TaskId.IDLE,
                        minimum_position_m=(
                            vision_config.mapping.negative_position_m
                        ),
                        maximum_position_m=(
                            vision_config.mapping.positive_position_m
                        ),
                    )
                    pipeline.restart_background()
                    setup_phase = "IDLE"
                    calibration_ready = False
                    node_mode = "BACKGROUND"
                    process_all_frames = True
                    start_requested = False
                    LOG.warning(
                        "runtime background restarted; remove the steel ball"
                    )
                else:
                    LOG.warning("ignored node command: %s", command)

            if not process_all_frames:
                if now < next_idle_process:
                    last_camera_sequence = snapshot.sequence
                    continue
                next_idle_process = now + 1.0 / config.runtime.idle_vision_fps

            # Commands and the idle-rate decision can take place after the
            # camera wake-up. Latch the newest complete JPEG again immediately
            # before decode so an older notification is never processed while
            # a newer frame is already available.
            freshest = camera.latest()
            if freshest is not None and freshest.sequence != snapshot.sequence:
                sequence_delta = (
                    int(freshest.sequence) - int(snapshot.sequence)
                ) & 0xFFFFFFFF
                if 0 < sequence_delta < 0x80000000:
                    superseded_camera_frames += sequence_delta
                    snapshot = freshest
            last_camera_sequence = snapshot.sequence

            processing_started_ns = time.monotonic_ns()
            frame_start_age_ms = max(
                0.0,
                (processing_started_ns - snapshot.timestamp_ns) / 1_000_000.0,
            )
            maximum_frame_start_age_ms = max(
                maximum_frame_start_age_ms,
                frame_start_age_ms,
            )
            if frame_start_age_ms > config.runtime.max_frame_start_age_ms:
                stale_before_decode_frames += 1
                continue

            decode_started = time.perf_counter()
            frame = cv2.imdecode(
                np.frombuffer(snapshot.jpeg, dtype=np.uint8),
                cv2.IMREAD_COLOR,
            )
            decode_ms = (time.perf_counter() - decode_started) * 1000.0
            if frame is None or frame.shape[:2] != expected_shape:
                LOG.warning("JPEG decode failed or shape mismatch")
                continue

            vision = pipeline.process(
                frame,
                snapshot.timestamp_ns,
            )
            result_age_ms = max(
                0.0,
                (time.monotonic_ns() - snapshot.timestamp_ns) / 1_000_000.0,
            )
            maximum_result_age_ms = max(maximum_result_age_ms, result_age_ms)
            total_ms = decode_ms + vision.processing_ms
            ewma_ms = (
                total_ms
                if ewma_ms == 0.0
                else 0.90 * ewma_ms + 0.10 * total_ms
            )
            if last_processed_capture_ns is not None:
                capture_gap_s = (
                    snapshot.timestamp_ns - last_processed_capture_ns
                ) * 1e-9
                if capture_gap_s > 0.0:
                    instantaneous_fps = min(
                        float(camera_config.fps),
                        1.0 / capture_gap_s,
                    )
                    vision_fps_ewma = (
                        instantaneous_fps
                        if vision_fps_ewma == 0.0
                        else 0.90 * vision_fps_ewma
                        + 0.10 * instantaneous_fps
                    )
            last_processed_capture_ns = snapshot.timestamp_ns
            calibration_ready = (
                vision.background_ready
                and not vision.background_failed
                and profile.runtime_geometry_allowed
                and setup_phase not in {"CAMERA", "FAILED"}
            )
            if calibration_ready and not realtime_window_ready:
                # Startup pose/background work is intentionally heavier and
                # must not pollute the competition-window latency maxima.
                superseded_camera_frames = 0
                stale_before_decode_frames = 0
                maximum_frame_start_age_ms = frame_start_age_ms
                maximum_result_age_ms = result_age_ms
                realtime_window_ready = True
            elif not calibration_ready:
                realtime_window_ready = False
            processing_realtime_ok = (
                camera.capture_fps >= config.preflight.min_camera_fps
                and vision_fps_ewma
                >= config.runtime.control_min_vision_fps
                and ewma_ms <= config.runtime.control_max_processing_ms
                and result_age_ms <= config.runtime.max_publish_age_ms
            )
            real_measurement_valid = (
                calibration_ready
                and processing_realtime_ok
                and vision.estimate.control_valid
                and vision.pose_valid
                and vision.estimate.confidence
                >= config.task.minimum_confidence
            )
            if node_mode == "SETUP":
                if vision.background_failed:
                    setup_phase = "FAILED"
                    setup_error = (
                        "绿色轨道背景连续重试后仍未建立；"
                        "检查画面、移走钢球并保持轨道静止"
                    )
                    process_all_frames = False
                elif setup_phase == "BACKGROUND" and vision.background_ready:
                    setup_phase = "EMPTY_CHECK"
                    setup_empty_consecutive = 0
                    LOG.info("FIELD TUNE background ready; verifying empty rail")
                elif setup_phase == "EMPTY_CHECK":
                    empty_valid = (
                        vision.pose_valid
                        and vision.result is not None
                        and not vision.result.accepted
                    )
                    setup_empty_consecutive = (
                        setup_empty_consecutive + 1
                        if empty_valid
                        else 0
                    )
                    if (
                        setup_empty_consecutive
                        >= config.preflight.setup_empty_confirm_frames
                    ):
                        setup_phase = "PLACE_BALL"
                        setup_ball_consecutive = 0
                        LOG.info(
                            "FIELD TUNE empty rail passed; place the ball"
                        )
                elif setup_phase == "PLACE_BALL":
                    setup_ball_consecutive = (
                        setup_ball_consecutive + 1
                        if real_measurement_valid
                        else 0
                    )
                    if (
                        setup_ball_consecutive
                        >= config.preflight.setup_ball_confirm_frames
                    ):
                        setup_phase = "PASSED"
                        LOG.info(
                            "FIELD TUNE passed: %d consecutive valid ball frames",
                            setup_ball_consecutive,
                        )
            task_status = task.update(
                snapshot.timestamp_ns,
                x_m=vision.x_m,
                v_mps=vision.v_mps,
                track_valid=real_measurement_valid,
                confidence=vision.estimate.confidence,
            )
            if start_requested:
                if task.start(
                    snapshot.timestamp_ns,
                    track_valid=real_measurement_valid,
                ):
                    LOG.info("task %s started", task.task_id.name)
                else:
                    LOG.warning(
                        "START ignored: task=%s phase=%s track=%s",
                        task.task_id.name,
                        task.phase.value,
                        real_measurement_valid,
                    )
                start_requested = False
            task_status = task.status(
                snapshot.timestamp_ns,
                vision.x_m
                if real_measurement_valid
                else None,
            )

            serial.publish(
                TxSnapshot(
                    # Timestamped when the complete JPEG arrived. Repeated
                    # 50 Hz packets keep this timestamp until a new processed
                    # frame replaces the snapshot; never forge freshness.
                    capture_timestamp_ns=snapshot.timestamp_ns,
                    flags=_flags(
                        vision.estimate,
                        vision.pose_valid,
                        calibration_ready,
                        config.task.minimum_confidence,
                        processing_degraded=(
                            not processing_realtime_ok
                        ),
                    ),
                    x_m=vision.x_m,
                    v_mps=vision.v_mps,
                    confidence=vision.estimate.confidence,
                    target_x_m=task_status.target_x_m,
                    task_id=task_status.task_id,
                    control_flags=task_status.control_flags,
                    run_id=task_status.run_id,
                )
            )

            interval_frames += 1
            now = time.monotonic()
            interval_elapsed = now - interval_start
            fps = (
                interval_frames / interval_elapsed
                if interval_elapsed > 0
                else 0.0
            )
            pose = vision.pose
            if interval_elapsed >= config.runtime.log_interval_s:
                LOG.debug(
                    "task=%s/%s detect=%.1ffps camera=%.1ffps "
                    "proc=%.1fms age=%.1fms pose=%.2f x=%+.4fm "
                    "v=%+.3fm/s conf=%.2f uart=%s",
                    task_status.task_id.name,
                    task_status.phase.value,
                    fps,
                    camera.capture_fps,
                    ewma_ms,
                    result_age_ms,
                    0.0 if pose is None else pose.confidence,
                    vision.x_m,
                    vision.v_mps,
                    vision.estimate.confidence,
                    serial.connected,
                )
                interval_start = now
                interval_frames = 0

            # Web/status diagnostics are not part of the control path. Keep
            # them at a fixed low rate so candidate formatting, Counter and
            # HTTP JSON work cannot steal time from the next camera frame.
            if now < next_status_update:
                continue
            next_status_update = now + 1.0 / config.runtime.status_update_hz

            result = vision.result
            best_candidate = (
                None
                if result is None or not result.candidates
                else result.candidates[0]
            )
            selected_candidate = vision.estimate.selected
            rejections = (
                {}
                if result is None
                else dict(
                    Counter(
                        candidate.rejection
                        for candidate in result.candidates
                    )
                )
            )
            public_state = (
                f"SETUP_{setup_phase}"
                if node_mode == "SETUP"
                else (
                    "BACKGROUND_FAILED"
                    if vision.background_failed
                    else (
                        "BACKGROUND"
                        if not vision.background_ready
                        else vision.estimate.state.value
                    )
                )
            )
            last_tx = serial.last_telemetry
            last_tx_delay_us = (
                None
                if last_tx is None
                else last_tx.capture_to_send_delay_us
            )
            control_realtime_ready = (
                processing_realtime_ok
                and (
                    last_tx_delay_us is None
                    or last_tx_delay_us <= MEASUREMENT_MAX_AGE_US
                )
            )
            video_full_rate_safe = (
                vision_fps_ewma >= config.video.full_rate_min_vision_fps
                and ewma_ms <= config.video.full_rate_max_processing_ms
                and camera.capture_fps
                >= max(50.0, float(camera_config.fps) - 5.0)
                and result_age_ms
                <= config.video.full_rate_max_delay_us / 1_000.0
                and (
                    last_tx_delay_us is None
                    or last_tx_delay_us
                    <= config.video.full_rate_max_delay_us
                )
            )
            setup_overlay = status.get()
            status_payload = {
                    "state": public_state,
                    "vision_state": vision.estimate.state.value,
                    "vision_pipeline": "REGISTERED_RAIL_CONTEXT",
                    "node_mode": node_mode,
                    "task_id": int(task_status.task_id),
                    "task_name": task_status.task_id.name,
                    "task_phase": task_status.phase.value,
                    "run_id": task_status.run_id,
                    "target_x_m": round(task_status.target_x_m, 6),
                    "task_elapsed_s": round(task_status.elapsed_s, 3),
                    "task_error_m": (
                        None
                        if task_status.error_m is None
                        else round(task_status.error_m, 6)
                    ),
                    "control_flags": int(task_status.control_flags),
                    "camera_sequence": snapshot.sequence,
                    "telemetry_sequence": serial.last_sequence,
                    "telemetry_capture_timestamp_ms": (
                        None if last_tx is None else last_tx.capture_timestamp_ms
                    ),
                    "telemetry_capture_to_send_delay_us": (
                        None
                        if last_tx is None
                        else last_tx.capture_to_send_delay_us
                    ),
                    "telemetry_x_0p1mm": (
                        None if last_tx is None else last_tx.x_0p1mm
                    ),
                    "telemetry_v_mmps": (
                        None if last_tx is None else last_tx.v_mmps
                    ),
                    "telemetry_confidence_u8": (
                        None if last_tx is None else last_tx.confidence_u8
                    ),
                    "telemetry_vision_flags": (
                        None if last_tx is None else int(last_tx.flags)
                    ),
                    "telemetry_control_flags": (
                        None if last_tx is None else int(last_tx.control_flags)
                    ),
                    "telemetry_target_x_0p1mm": (
                        None if last_tx is None else last_tx.target_x_0p1mm
                    ),
                    "balllink_session_id": serial.session_id,
                    "balllink_packet_count": serial.packet_count,
                    "balllink_serial_packet_count": (
                        serial.serial_packet_count
                    ),
                    "vision_profile": profile_id,
                    "calibration_ready": calibration_ready,
                    "registered_background_ready": (
                        vision.background_ready
                    ),
                    "registered_background_failed": (
                        vision.background_failed
                    ),
                    "registered_background_frames": (
                        vision.background_frames
                    ),
                    "registered_background_required": (
                        vision.background_required
                    ),
                    "registered_background_attempts": (
                        vision.background_attempts
                    ),
                    "registered_background_max_attempts": (
                        vision.background_max_attempts
                    ),
                    "registered_background_retry_count": (
                        vision.background_retry_count
                    ),
                    "registered_background_retry_limit": (
                        vision.background_retry_limit
                    ),
                    "camera_controls": dict(active_camera_controls),
                    "setup_phase": setup_phase,
                    "setup_error": setup_error,
                    "setup_empty_consecutive": setup_empty_consecutive,
                    "setup_empty_required": (
                        config.preflight.setup_empty_confirm_frames
                    ),
                    "setup_ball_consecutive": setup_ball_consecutive,
                    "setup_ball_required": (
                        config.preflight.setup_ball_confirm_frames
                    ),
                    "measurement_valid": vision.estimate.measurement_valid,
                    "control_measurement_valid": (
                        real_measurement_valid
                    ),
                    "track_valid": vision.estimate.track_valid
                    and vision.pose_valid,
                    "predicted": vision.estimate.predicted,
                    "tube_pose_valid": vision.pose_valid,
                    "tube_pose_confidence": (
                        0.0 if pose is None else round(pose.confidence, 4)
                    ),
                    "tube_pose_source": (
                        "NONE" if pose is None else pose.source
                    ),
                    "tube_pose_diagnostics": (
                        pipeline.pose_diagnostics
                    ),
                    "x_m": round(vision.x_m, 6),
                    "v_mps": round(vision.v_mps, 6),
                    "confidence": round(vision.estimate.confidence, 4),
                    "x_px": round(vision.x_px, 2),
                    "y_px": round(vision.y_px, 2),
                    "radius_px": round(vision.radius_px, 2),
                    "axis_x_px": round(vision.axis_x_px, 2),
                    "axis_v_px_s": round(
                        vision.axis_v_px_s,
                        2,
                    ),
                    "axis_fraction": (
                        round(vision.estimate.axis_fraction, 6)
                        if vision.estimate.track_valid
                        else None
                    ),
                    "velocity_fraction_s": (
                        round(
                            vision.estimate.velocity_fraction_s,
                            6,
                        )
                        if vision.estimate.track_valid
                        else None
                    ),
                    "acquisition_frames": (
                        vision.estimate.acquisition_frames
                    ),
                    "acquisition_required": (
                        vision.estimate.acquisition_required
                    ),
                    "missed_frames": vision.estimate.missed_frames,
                    "jump_quarantined": (
                        vision.estimate.jump_quarantined
                    ),
                    "candidate_count": (
                        0 if result is None else len(result.candidates)
                    ),
                    "accepted_count": (
                        0 if result is None else len(result.accepted)
                    ),
                    "rejections": rejections,
                    "best_candidate": _candidate_payload(
                        best_candidate
                    ),
                    "selected_candidate": _candidate_payload(
                        selected_candidate
                    ),
                    "seed_diagnostics": (
                        {}
                        if result is None
                        else result.seed_diagnostics
                    ),
                    "decode_ms": round(decode_ms, 2),
                    "detect_ms": round(vision.processing_ms, 2),
                    "processing_ewma_ms": round(ewma_ms, 2),
                    "frame_start_age_ms": round(frame_start_age_ms, 2),
                    "result_age_ms": round(result_age_ms, 2),
                    "maximum_frame_start_age_ms": round(
                        maximum_frame_start_age_ms,
                        2,
                    ),
                    "maximum_result_age_ms": round(
                        maximum_result_age_ms,
                        2,
                    ),
                    "superseded_camera_frames": (
                        superseded_camera_frames
                    ),
                    "stale_before_decode_frames": (
                        stale_before_decode_frames
                    ),
                    "detection_fps": round(vision_fps_ewma, 2),
                    "control_realtime_ready": control_realtime_ready,
                    "processing_degraded": (
                        not processing_realtime_ok
                    ),
                    "max_publish_age_ms": (
                        config.runtime.max_publish_age_ms
                    ),
                    "video_full_rate_safe": video_full_rate_safe,
                    "control_target_vision_fps": (
                        config.runtime.control_target_vision_fps
                    ),
                    "control_min_vision_fps": (
                        config.runtime.control_min_vision_fps
                    ),
                    "control_max_processing_ms": (
                        config.runtime.control_max_processing_ms
                    ),
                    "camera_fps": round(camera.capture_fps, 2),
                    "average_jpeg_kib": round(
                        camera.average_jpeg_bytes / 1024.0, 2
                    ),
                    "video_configured_fps": config.video.fps,
                    "video_effective_fps": round(
                        video.effective_fps,
                        2,
                    ),
                    "video_control_throttled": (
                        video.effective_fps < config.video.fps
                    ),
                    "video_estimated_mbps": round(
                        camera.average_jpeg_bytes
                        * video.effective_fps
                        * 8.0
                        / 1_000_000.0,
                        3,
                    ),
                    "full_frame_search": False,
                    "uart_tx_open": serial.connected,
                }
            for key in (
                "setup_display",
                "setup_oled_display",
                "setup_camera_controls",
            ):
                if key in setup_overlay:
                    status_payload[key] = setup_overlay[key]
            status.set(status_payload)
    finally:
        status.set({"state": "STOPPING"})
        video.close()
        camera.close()
        serial.close()
        udp.close()
        if config.runtime.disable_gc_during_realtime and gc_was_enabled:
            gc.enable()
        sys.setswitchinterval(previous_switch_interval)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="H题树莓派固定绿色轨道、钢球视觉与任务节点"
    )
    parser.add_argument("--config", default=str(PROJECT_ROOT / "config" / "pi.toml"))
    parser.add_argument(
        "--task",
        choices=("idle", "t2", "t3", "t4", "t5", "t6"),
        default="idle",
    )
    parser.add_argument("--run-id", type=int)
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    try:
        run(args.config, TaskId[args.task.upper()], args.run_id)
    except KeyboardInterrupt:
        LOG.info("stopped by user")


if __name__ == "__main__":
    main()
