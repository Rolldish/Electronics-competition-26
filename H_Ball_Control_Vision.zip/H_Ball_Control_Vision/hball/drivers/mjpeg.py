"""MJPEG byte-stream parsers used by camera and laptop clients."""

from __future__ import annotations

import struct


JPEG_SOI = b"\xff\xd8"
JPEG_EOI = b"\xff\xd9"
V4L2_FILE_HEADER_ID = 0x72646856


class JpegByteStreamParser:
    """Extract complete JPEG images from raw UVC or multipart MJPEG byte chunks."""

    def __init__(self, max_frame_bytes: int = 4 * 1024 * 1024) -> None:
        self.max_frame_bytes = max_frame_bytes
        self._buffer = bytearray()

    def push(self, chunk: bytes) -> list[bytes]:
        self._buffer.extend(chunk)
        output: list[bytes] = []
        while True:
            start = self._buffer.find(JPEG_SOI)
            if start < 0:
                if len(self._buffer) > 2:
                    del self._buffer[:-2]
                return output
            if start:
                del self._buffer[:start]
            end = self._buffer.find(JPEG_EOI, 2)
            if end < 0:
                if len(self._buffer) > self.max_frame_bytes:
                    self._buffer.clear()
                return output
            end += 2
            output.append(bytes(self._buffer[:end]))
            del self._buffer[:end]


class V4l2FramedJpegParser:
    """Parse `v4l2-ctl --stream-to-hdr=-` single-plane compressed frames."""

    _HEADER = struct.Struct(">II")
    _MAGIC = struct.pack(">I", V4L2_FILE_HEADER_ID)

    def __init__(self, max_frame_bytes: int = 4 * 1024 * 1024) -> None:
        self.max_frame_bytes = max_frame_bytes
        self._buffer = bytearray()

    def push(self, chunk: bytes) -> list[bytes]:
        self._buffer.extend(chunk)
        output: list[bytes] = []
        while True:
            start = self._buffer.find(self._MAGIC)
            if start < 0:
                if len(self._buffer) > len(self._MAGIC):
                    del self._buffer[: -len(self._MAGIC)]
                return output
            if start:
                del self._buffer[:start]
            if len(self._buffer) < self._HEADER.size:
                return output
            magic, size = self._HEADER.unpack_from(self._buffer)
            if magic != V4L2_FILE_HEADER_ID or not 4 <= size <= self.max_frame_bytes:
                del self._buffer[0]
                continue
            frame_end = self._HEADER.size + size
            if len(self._buffer) < frame_end:
                return output
            payload = bytes(self._buffer[self._HEADER.size : frame_end])
            del self._buffer[:frame_end]
            # Some UVC drivers include alignment bytes after JPEG EOI in the
            # V4L2 bytes-used payload.  The V4L2 frame header is still the
            # authoritative frame boundary, but the network/decode branches
            # must receive the exact JPEG rather than reject padded frames.
            jpeg_start = payload.find(JPEG_SOI)
            jpeg_end = payload.find(JPEG_EOI, jpeg_start + len(JPEG_SOI))
            if jpeg_start >= 0 and jpeg_end >= 0:
                output.append(payload[jpeg_start : jpeg_end + len(JPEG_EOI)])
