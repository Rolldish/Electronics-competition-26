"""Read-only checks for the dedicated 5 GHz competition hotspot."""

from __future__ import annotations

import re
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path

from hball.common.config import NetworkConfig


@dataclass(frozen=True)
class HotspotStatus:
    enabled: bool
    ready: bool
    interface: str
    interface_present: bool
    driver_matches: bool
    connection_active: bool
    ap_mode: bool
    ssid_matches: bool
    address_matches: bool
    channel_matches: bool
    country_matches: bool
    actual_driver: str = ""
    actual_connection: str = ""
    actual_ssid: str = ""
    actual_addresses: tuple[str, ...] = ()
    actual_channel: int | None = None
    errors: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _run_text(command: list[str]) -> str:
    try:
        result = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=1.5,
        )
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired) as error:
        raise RuntimeError(f"{command[0]}不可用: {error}") from error
    if result.returncode != 0:
        message = result.stderr.strip() or f"退出码{result.returncode}"
        raise RuntimeError(f"{command[0]}检查失败: {message}")
    return result.stdout.strip()


def _driver_name(interface: str) -> str:
    link = Path("/sys/class/net") / interface / "device" / "driver"
    try:
        return link.resolve(strict=True).name
    except (FileNotFoundError, OSError):
        return ""


def check_hotspot(config: NetworkConfig) -> HotspotStatus:
    """Inspect hotspot state without changing NetworkManager configuration."""

    if not config.enabled:
        return HotspotStatus(
            enabled=False,
            ready=True,
            interface=config.interface,
            interface_present=True,
            driver_matches=True,
            connection_active=True,
            ap_mode=True,
            ssid_matches=True,
            address_matches=True,
            channel_matches=True,
            country_matches=True,
        )

    errors: list[str] = []
    interface_path = Path("/sys/class/net") / config.interface
    interface_present = interface_path.exists()
    actual_driver = _driver_name(config.interface) if interface_present else ""
    actual_connection = ""
    actual_ssid = ""
    actual_addresses: tuple[str, ...] = ()
    actual_channel: int | None = None
    ap_mode = False
    country_matches = False

    if not interface_present:
        errors.append(f"没有找到无线接口{config.interface}")
    else:
        try:
            actual_connection = _run_text(
                [
                    "nmcli",
                    "-g",
                    "GENERAL.CONNECTION",
                    "device",
                    "show",
                    config.interface,
                ]
            )
        except RuntimeError as error:
            errors.append(str(error))

        try:
            info = _run_text(["iw", "dev", config.interface, "info"])
            for raw_line in info.splitlines():
                line = raw_line.strip()
                if line == "type AP":
                    ap_mode = True
                elif line.startswith("ssid "):
                    actual_ssid = line[5:]
                elif line.startswith("channel "):
                    match = re.match(r"channel\s+(\d+)", line)
                    if match:
                        actual_channel = int(match.group(1))
        except RuntimeError as error:
            errors.append(str(error))

        try:
            address_text = _run_text(
                ["ip", "-4", "-o", "address", "show", "dev", config.interface]
            )
            actual_addresses = tuple(
                re.findall(r"\binet\s+([0-9.]+/\d+)", address_text)
            )
        except RuntimeError as error:
            errors.append(str(error))

        try:
            regulatory = _run_text(["iw", "reg", "get"])
            country_matches = bool(
                re.search(
                    rf"(?m)^\s*country\s+{re.escape(config.country_code)}:",
                    regulatory,
                    re.IGNORECASE,
                )
            )
        except RuntimeError as error:
            errors.append(str(error))

    driver_matches = actual_driver == config.driver
    connection_active = actual_connection == config.connection_name
    ssid_matches = actual_ssid == config.ssid
    address_matches = config.ipv4_cidr in actual_addresses
    channel_matches = actual_channel == config.channel
    ready = all(
        (
            interface_present,
            driver_matches,
            connection_active,
            ap_mode,
            ssid_matches,
            address_matches,
            channel_matches,
            country_matches,
        )
    )
    return HotspotStatus(
        enabled=True,
        ready=ready,
        interface=config.interface,
        interface_present=interface_present,
        driver_matches=driver_matches,
        connection_active=connection_active,
        ap_mode=ap_mode,
        ssid_matches=ssid_matches,
        address_matches=address_matches,
        channel_matches=channel_matches,
        country_matches=country_matches,
        actual_driver=actual_driver,
        actual_connection=actual_connection,
        actual_ssid=actual_ssid,
        actual_addresses=actual_addresses,
        actual_channel=actual_channel,
        errors=tuple(errors),
    )
