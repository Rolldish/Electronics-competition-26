"""Fixed-rate one-way UART and non-blocking UDP publisher drivers."""

from __future__ import annotations

import logging
import secrets
import socket
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass

from ..common.config import SerialConfig, UdpConfig
from .protocol import (
    ControlFlags,
    Flags,
    SnapshotTooOldError,
    Telemetry,
    TxSnapshot,
    encode_packet,
    make_telemetry,
)
from .usb_serial import resolve_usb_serial_port


LOG = logging.getLogger(__name__)

_SUMMARY_INTERVAL_NS = 10_000_000_000
_CBOARD_CONFIDENCE_MIN = 180
_CBOARD_TRANSPORT_MARGIN_US = 3_000
_CBOARD_MEASUREMENT_MAX_AGE_US = 80_000


def _u32_delta(newer: int, older: int) -> int:
    """Return a short forward uint32 millisecond delta across wraparound."""

    delta = (int(newer) - int(older)) & 0xFFFFFFFF
    return delta if delta < 0x80000000 else 0


@dataclass
class _BallLinkDiagnostics:
    """Low-overhead counters owned exclusively by the BallLink TX thread."""

    window_started_ns: int
    sent_frames: int = 0
    unique_capture_frames: int = 0
    repeated_capture_frames: int = 0
    valid_vision_frames: int = 0
    valid_unique_capture_frames: int = 0
    ball_invalid_frames: int = 0
    camera_uncalibrated_frames: int = 0
    processing_degraded_frames: int = 0
    low_confidence_frames: int = 0
    delay_over_40ms_frames: int = 0
    delay_over_77ms_frames: int = 0
    stale_paused_frames: int = 0
    stale_invalid_heartbeat_frames: int = 0
    max_delay_us: int = 0
    max_capture_gap_ms: int = 0
    max_valid_measurement_gap_ms: int = 0
    session_change_count: int = 0
    run_change_count: int = 0
    last_capture_ms: int | None = None
    last_valid_capture_ms: int | None = None
    last_valid_observed_ns: int | None = None
    last_session_id: int | None = None
    last_run_id: int | None = None
    last_message: Telemetry | None = None
    last_valid_message: Telemetry | None = None
    max_valid_gap_from: Telemetry | None = None
    max_valid_gap_to: Telemetry | None = None

    def observe_sent(self, message: Telemetry, observed_ns: int) -> None:
        self.sent_frames += 1
        is_unique = message.capture_timestamp_ms != self.last_capture_ms
        if is_unique:
            self.unique_capture_frames += 1
            if self.last_capture_ms is not None:
                self.max_capture_gap_ms = max(
                    self.max_capture_gap_ms,
                    _u32_delta(
                        message.capture_timestamp_ms,
                        self.last_capture_ms,
                    ),
                )
            self.last_capture_ms = message.capture_timestamp_ms
        else:
            self.repeated_capture_frames += 1

        flags = message.flags
        if not flags & Flags.BALL_VALID:
            self.ball_invalid_frames += 1
        if not flags & Flags.CAMERA_CALIBRATED:
            self.camera_uncalibrated_frames += 1
        if flags & Flags.PROCESSING_DEGRADED:
            self.processing_degraded_frames += 1
        if message.confidence_u8 < _CBOARD_CONFIDENCE_MIN:
            self.low_confidence_frames += 1
        if message.capture_to_send_delay_us > 40_000:
            self.delay_over_40ms_frames += 1
        if message.capture_to_send_delay_us > 77_000:
            self.delay_over_77ms_frames += 1
        if (
            message.capture_to_send_delay_us > 70_000
            and not flags & Flags.BALL_VALID
            and flags & Flags.PROCESSING_DEGRADED
        ):
            self.stale_invalid_heartbeat_frames += 1
        self.max_delay_us = max(
            self.max_delay_us,
            message.capture_to_send_delay_us,
        )

        valid = (
            bool(message.control_flags & ControlFlags.CONTROL_ENABLED)
            and bool(flags & Flags.BALL_VALID)
            and bool(flags & Flags.CAMERA_CALIBRATED)
            and not bool(flags & Flags.PROCESSING_DEGRADED)
            and message.confidence_u8 >= _CBOARD_CONFIDENCE_MIN
            and message.capture_to_send_delay_us
            + _CBOARD_TRANSPORT_MARGIN_US
            <= _CBOARD_MEASUREMENT_MAX_AGE_US
        )
        if valid:
            self.valid_vision_frames += 1
            if is_unique:
                self.valid_unique_capture_frames += 1
                if self.last_valid_capture_ms is not None:
                    valid_gap_ms = _u32_delta(
                        message.capture_timestamp_ms,
                        self.last_valid_capture_ms,
                    )
                    if valid_gap_ms > self.max_valid_measurement_gap_ms:
                        self.max_valid_measurement_gap_ms = valid_gap_ms
                        self.max_valid_gap_from = self.last_valid_message
                        self.max_valid_gap_to = message
                self.last_valid_capture_ms = message.capture_timestamp_ms
                self.last_valid_observed_ns = observed_ns
                self.last_valid_message = message

        if (
            self.last_session_id is not None
            and message.session_id != self.last_session_id
        ):
            self.session_change_count += 1
        if self.last_run_id is not None and message.run_id != self.last_run_id:
            self.run_change_count += 1
        self.last_session_id = message.session_id
        self.last_run_id = message.run_id
        self.last_message = message

    def emit_if_due(self, now_ns: int) -> None:
        if now_ns - self.window_started_ns < _SUMMARY_INTERVAL_NS:
            return
        message = self.last_message
        current_valid_age_ms = (
            None
            if self.last_valid_observed_ns is None
            else max(0, (now_ns - self.last_valid_observed_ns) // 1_000_000)
        )
        if self.valid_unique_capture_frames == 0:
            status = "NO_VALID_MEASUREMENT"
        elif current_valid_age_ms is not None and current_valid_age_ms >= 80:
            status = "VALID_GAP_OPEN"
        else:
            status = "OK"
        LOG.info(
            "BallLink 10s summary: status=%s sent_frames=%d "
            "unique_capture_frames=%d repeated_capture_frames=%d "
            "valid_vision_frames=%d valid_unique_capture_frames=%d "
            "ball_invalid_frames=%d "
            "camera_uncalibrated_frames=%d processing_degraded_frames=%d "
            "low_confidence_frames=%d delay_over_40ms_frames=%d "
            "delay_over_77ms_frames=%d "
            "stale_pause_count=%d stale_invalid_heartbeat_frames=%d "
            "max_delay_us=%d max_capture_gap_ms=%d "
            "max_valid_measurement_gap_ms=%d session_change_count=%d "
            "run_change_count=%d current_valid_measurement_age_ms=%s "
            "last_capture_timestamp_ms=%s "
            "last_x_0p1mm=%s last_v_mmps=%s "
            "last_confidence=%s last_vision_flags=%s last_control_flags=%s "
            "last_target_x_0p1mm=%s last_task_id=%s last_run_id=%s "
            "session_id=%s max_gap_from=%s max_gap_to=%s",
            status,
            self.sent_frames,
            self.unique_capture_frames,
            self.repeated_capture_frames,
            self.valid_vision_frames,
            self.valid_unique_capture_frames,
            self.ball_invalid_frames,
            self.camera_uncalibrated_frames,
            self.processing_degraded_frames,
            self.low_confidence_frames,
            self.delay_over_40ms_frames,
            self.delay_over_77ms_frames,
            self.stale_paused_frames,
            self.stale_invalid_heartbeat_frames,
            self.max_delay_us,
            self.max_capture_gap_ms,
            self.max_valid_measurement_gap_ms,
            self.session_change_count,
            self.run_change_count,
            "NONE" if current_valid_age_ms is None else current_valid_age_ms,
            "NONE" if message is None else message.capture_timestamp_ms,
            "NONE" if message is None else message.x_0p1mm,
            "NONE" if message is None else message.v_mmps,
            "NONE" if message is None else message.confidence_u8,
            "NONE" if message is None else f"0x{int(message.flags):02X}",
            (
                "NONE"
                if message is None
                else f"0x{int(message.control_flags):02X}"
            ),
            "NONE" if message is None else message.target_x_0p1mm,
            "NONE" if message is None else int(message.task_id),
            "NONE" if message is None else message.run_id,
            "NONE" if message is None else message.session_id,
            self._frame_marker(self.max_valid_gap_from),
            self._frame_marker(self.max_valid_gap_to),
        )
        self._reset_window(now_ns)

    def observe_stale(self, snapshot: TxSnapshot, send_ns: int) -> None:
        delay_us = max(
            0,
            (int(send_ns) - int(snapshot.capture_timestamp_ns)) // 1_000,
        )
        self.stale_paused_frames += 1
        if delay_us > 40_000:
            self.delay_over_40ms_frames += 1
        if delay_us > 77_000:
            self.delay_over_77ms_frames += 1
        self.max_delay_us = max(self.max_delay_us, delay_us)

    @staticmethod
    def _frame_marker(message: Telemetry | None) -> str:
        if message is None:
            return "NONE"
        return (
            f"capture:{message.capture_timestamp_ms},"
            f"delay:{message.capture_to_send_delay_us},"
            f"conf:{message.confidence_u8},"
            f"flags:0x{int(message.flags):02X},"
            f"x:{message.x_0p1mm},v:{message.v_mmps}"
        )

    def _reset_window(self, now_ns: int) -> None:
        self.window_started_ns = now_ns
        self.sent_frames = 0
        self.unique_capture_frames = 0
        self.repeated_capture_frames = 0
        self.valid_vision_frames = 0
        self.valid_unique_capture_frames = 0
        self.ball_invalid_frames = 0
        self.camera_uncalibrated_frames = 0
        self.processing_degraded_frames = 0
        self.low_confidence_frames = 0
        self.delay_over_40ms_frames = 0
        self.delay_over_77ms_frames = 0
        self.stale_paused_frames = 0
        self.stale_invalid_heartbeat_frames = 0
        self.max_delay_us = 0
        self.max_capture_gap_ms = 0
        self.max_valid_measurement_gap_ms = 0
        self.session_change_count = 0
        self.run_change_count = 0
        self.max_valid_gap_from = None
        self.max_valid_gap_to = None


class BallLinkPublisher:
    """Own the UART and broadcast the latest complete snapshot at fixed 50 Hz.

    There is deliberately no RX thread and no ACK handling.  Optional packet
    sinks mirror the exact UART frame to the laptop telemetry UDP channel.
    """

    def __init__(
        self,
        config: SerialConfig,
        packet_sinks: tuple[Callable[[bytes], object], ...] = (),
    ) -> None:
        self.config = config
        self.session_id = secrets.randbits(32)
        self._packet_sinks = packet_sinks
        self._serial = None
        self._opened_port: str | None = None
        self._next_reconnect = 0.0
        self._latest_lock = threading.Lock()
        self._latest: TxSnapshot | None = None
        self._last_telemetry: Telemetry | None = None
        self._sequence = 0
        self._packet_count = 0
        self._serial_packet_count = 0
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None

    @property
    def connected(self) -> bool:
        return self._serial is not None

    @property
    def opened_port(self) -> str | None:
        return self._opened_port

    @property
    def last_telemetry(self) -> Telemetry | None:
        with self._latest_lock:
            return self._last_telemetry

    @property
    def last_sequence(self) -> int | None:
        message = self.last_telemetry
        return None if message is None else message.sequence

    @property
    def packet_count(self) -> int:
        return self._packet_count

    @property
    def serial_packet_count(self) -> int:
        return self._serial_packet_count

    def start(self) -> None:
        if self._thread is not None:
            return
        if not self.config.enabled and not self._packet_sinks:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="balllink-tx",
            daemon=True,
        )
        self._thread.start()

    def publish(self, snapshot: TxSnapshot) -> None:
        with self._latest_lock:
            self._latest = snapshot
        self._wake.set()

    def _connect(self) -> bool:
        if not self.config.enabled:
            return False
        now = time.monotonic()
        if self._serial is not None:
            return True
        if now < self._next_reconnect:
            return False
        self._next_reconnect = now + self.config.reconnect_interval_s
        try:
            import serial

            port = resolve_usb_serial_port(self.config.port)
            self._serial = serial.Serial(
                port=port,
                baudrate=self.config.baudrate,
                bytesize=8,
                parity="N",
                stopbits=1,
                timeout=0,
                write_timeout=self.config.write_timeout_s,
                xonxoff=False,
                rtscts=False,
                dsrdtr=False,
                exclusive=True,
            )
            self._opened_port = port
            LOG.info(
                "BallLink TX opened: %s @ %d, session=0x%08X",
                port,
                self.config.baudrate,
                self.session_id,
            )
            return True
        except Exception as error:
            LOG.warning("BallLink USB TX open failed: %s", error)
            self._serial = None
            self._opened_port = None
            return False

    def _loop(self) -> None:
        period_ns = int(round(1_000_000_000 / self.config.tx_hz))
        next_tick_ns = time.monotonic_ns()
        # Competition INFO mode performs no per-frame diagnostic counting.
        # The existing 10 s accumulator remains available only when a developer
        # explicitly starts the node with DEBUG logging.
        diagnostics = (
            _BallLinkDiagnostics(next_tick_ns)
            if LOG.isEnabledFor(logging.DEBUG)
            else None
        )

        while not self._stop.is_set():
            now_ns = time.monotonic_ns()
            remaining_ns = next_tick_ns - now_ns
            if remaining_ns > 0:
                self._wake.wait(min(0.05, remaining_ns * 1e-9))
                self._wake.clear()
                continue

            # Preserve an absolute 20 ms cadence without bursting after a long
            # OS scheduling pause.
            if now_ns - next_tick_ns > period_ns * 2:
                next_tick_ns = now_ns
            next_tick_ns += period_ns

            # Reconnect/open can involve filesystem and USB work. Do it before
            # latching the snapshot, then age and encode the newest result as
            # close as possible to the actual UART write.
            uart_ready = self._connect()
            with self._latest_lock:
                snapshot = self._latest
            if snapshot is None:
                if diagnostics is not None:
                    diagnostics.emit_if_due(now_ns)
                continue

            send_ns = time.monotonic_ns()
            try:
                message = make_telemetry(
                    snapshot,
                    session_id=self.session_id,
                    sequence=self._sequence,
                    send_timestamp_ns=send_ns,
                )
                packet = encode_packet(message)
            except SnapshotTooOldError:
                if diagnostics is not None:
                    diagnostics.observe_stale(snapshot, send_ns)
                    diagnostics.emit_if_due(send_ns)
                continue
            except (TypeError, ValueError):
                LOG.exception("cannot encode BallLink snapshot")
                continue

            self._sequence = (self._sequence + 1) & 0xFF
            self._packet_count += 1
            with self._latest_lock:
                self._last_telemetry = message

            # UART is the real-time control path.  Write it before optional UDP
            # mirrors so network scheduling cannot add hidden wire latency.
            uart_sent = False
            if uart_ready:
                try:
                    assert self._serial is not None
                    written = self._serial.write(packet)
                    if written != len(packet):
                        raise IOError(f"short serial write {written}/{len(packet)}")
                    self._serial_packet_count += 1
                    uart_sent = True
                except Exception as error:
                    LOG.warning("BallLink TX write failed: %s", error)
                    self._next_reconnect = (
                        time.monotonic() + self.config.reconnect_interval_s
                    )
                    self._close_port()

            mirror_sent = False
            for sink in self._packet_sinks:
                try:
                    sink(packet)
                    mirror_sent = True
                except Exception:
                    LOG.exception("BallLink packet mirror failed")

            # In production sent_frames means a successful UART write.  The
            # sink-only branch keeps local tests and laptop diagnostics useful.
            if diagnostics is not None:
                if uart_sent or (not self.config.enabled and mirror_sent):
                    delivered_ns = time.monotonic_ns()
                    diagnostics.observe_sent(message, delivered_ns)
                diagnostics.emit_if_due(time.monotonic_ns())

    def close(self) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None
        self._close_port()

    def _close_port(self) -> None:
        if self._serial is not None:
            try:
                self._serial.close()
            finally:
                self._serial = None
                self._opened_port = None


class UdpPublisher:
    def __init__(self, config: UdpConfig) -> None:
        self.config = config
        self._socket: socket.socket | None = None
        if config.enabled:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._socket.setblocking(False)
            self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    def send(self, packet: bytes) -> bool:
        if self._socket is None:
            return False
        try:
            self._socket.sendto(packet, (self.config.host, self.config.port))
            return True
        except (BlockingIOError, OSError):
            return False

    def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None
