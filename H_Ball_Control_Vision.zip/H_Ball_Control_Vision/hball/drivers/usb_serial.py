"""USB-to-TTL serial-port discovery for the Raspberry Pi."""

from __future__ import annotations

from pathlib import Path


AUTO_USB_PORT = "auto-usb"
_AUTO_NAMES = {"auto", AUTO_USB_PORT}


def list_usb_serial_ports(
    by_id_dir: Path = Path("/dev/serial/by-id"),
    device_dir: Path = Path("/dev"),
) -> list[str]:
    """Return unique USB serial devices, preferring stable by-id aliases."""

    ports: list[str] = []
    targets: set[str] = set()

    if by_id_dir.is_dir():
        for entry in sorted(by_id_dir.iterdir()):
            if not entry.exists():
                continue
            target = str(entry.resolve())
            if target in targets:
                continue
            ports.append(str(entry))
            targets.add(target)

    for pattern in ("ttyUSB*", "ttyACM*"):
        for entry in sorted(device_dir.glob(pattern)):
            if not entry.exists():
                continue
            target = str(entry.resolve())
            if target in targets:
                continue
            ports.append(str(entry))
            targets.add(target)
    return ports


def resolve_usb_serial_port(requested: str) -> str:
    """Resolve ``auto-usb`` or return an explicitly configured device path."""

    value = requested.strip()
    if not value:
        raise ValueError("串口设备名不能为空")
    if value.lower() not in _AUTO_NAMES:
        return value

    ports = list_usb_serial_ports()
    if not ports:
        raise RuntimeError(
            "没有发现 USB 转串口设备；请检查模块和 USB 连接，然后运行："
            " ls -l /dev/serial/by-id /dev/ttyUSB* /dev/ttyACM*"
        )
    if len(ports) > 1:
        choices = "\n  ".join(ports)
        raise RuntimeError(
            "发现多个 USB 串口，程序拒绝猜测。请把 config/pi.toml 的 "
            f"serial.port 改为其中一个稳定路径：\n  {choices}"
        )
    return ports[0]
