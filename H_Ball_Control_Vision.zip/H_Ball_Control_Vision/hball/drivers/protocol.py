"""One-way BallLink protocol from Raspberry Pi 5B to the DJI C board."""

from __future__ import annotations

import math
import struct
import time
from dataclasses import dataclass
from enum import IntEnum, IntFlag


MAGIC_BYTES = b"\xA5\x5A"
VERSION = 0x02
VISION_CONTROL_SNAPSHOT = 0x10
PAYLOAD_SIZE = 24
PACKET_SIZE = 32
MAX_PAYLOAD_SIZE = 32

TX_HZ = 50.0
# Leave several milliseconds for UART transmission and C-board scheduling
# before its 80 ms receive-side freshness limit. A packet older than 70 ms
# remains a 50 Hz invalid heartbeat: it keeps the real capture timestamp but
# clears all measurement fields. Freshness is never forged.
MEASUREMENT_MAX_AGE_US = 70_000
# The current C-board parser accepts legal heartbeat fields up to 200 ms.
# Beyond that, pausing is safer than emitting a frame it will count as a range
# error. Measurement validity still ends much earlier at 70 ms.
CAPTURE_DELAY_LIMIT_US = 200_000
X_LIMIT_0P1MM = 1_300
V_LIMIT_MMPS = 5_000
TARGET_LIMIT_0P1MM = 1_200
DEFAULT_CONFIDENCE_MIN_U8 = 180

_HEADER = struct.Struct("<2sBBBB")
_PAYLOAD = struct.Struct("<IIIhhBBhBBH")
_CRC = struct.Struct("<H")

assert _HEADER.size == 6
assert _PAYLOAD.size == PAYLOAD_SIZE
assert _HEADER.size + _PAYLOAD.size + _CRC.size == PACKET_SIZE


class Flags(IntFlag):
    BALL_VALID = 1 << 0
    VELOCITY_VALID = 1 << 1
    CAMERA_CALIBRATED = 1 << 2
    PROCESSING_DEGRADED = 1 << 3


class TaskId(IntEnum):
    IDLE = 0
    T2 = 2
    T3 = 3
    T4 = 4
    T5 = 5
    T6 = 6


class ControlFlags(IntFlag):
    CONTROL_ENABLED = 1 << 0
    RUN_ACTIVE = 1 << 1
    TASK_DONE = 1 << 2
    TASK_TIMEOUT = 1 << 3
    TARGET_LATCHED = 1 << 4


class SnapshotTooOldError(ValueError):
    """No honest BallLink heartbeat can represent this old snapshot."""


@dataclass(frozen=True)
class TxSnapshot:
    """Latest vision/task state before wire-unit conversion.

    The serial worker owns the session, UART sequence and send-time delay.  The
    vision thread only replaces this latest snapshot and never waits for UART.
    """

    capture_timestamp_ns: int
    flags: Flags
    x_m: float
    v_mps: float
    confidence: float
    target_x_m: float
    task_id: TaskId
    control_flags: ControlFlags
    run_id: int


@dataclass(frozen=True)
class Telemetry:
    """Decoded VISION_CONTROL_SNAPSHOT in exact wire units."""

    session_id: int
    sequence: int
    capture_timestamp_ms: int
    capture_to_send_delay_us: int
    x_0p1mm: int
    v_mmps: int
    confidence_u8: int
    flags: Flags
    target_x_0p1mm: int
    task_id: TaskId
    control_flags: ControlFlags
    run_id: int
    version: int = VERSION
    frame_type: int = VISION_CONTROL_SNAPSHOT

    @property
    def timestamp_ms(self) -> int:
        return self.capture_timestamp_ms

    @property
    def x_m(self) -> float:
        return self.x_0p1mm / 10_000.0

    @property
    def v_mps(self) -> float:
        return self.v_mmps / 1_000.0

    @property
    def confidence(self) -> float:
        return self.confidence_u8 / 255.0

    @property
    def target_x_m(self) -> float:
        return self.target_x_0p1mm / 10_000.0

    @property
    def measurement_valid(self) -> bool:
        return bool(self.flags & Flags.BALL_VALID)

    @property
    def velocity_valid(self) -> bool:
        return bool(self.flags & Flags.VELOCITY_VALID)

    @property
    def track_valid(self) -> bool:
        return self.measurement_valid


def crc16_ccitt_false(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            crc = (
                ((crc << 1) ^ 0x1021) & 0xFFFF
                if crc & 0x8000
                else (crc << 1) & 0xFFFF
            )
    return crc


def _clamp(value: int, minimum: int, maximum: int) -> int:
    return min(maximum, max(minimum, value))


def make_telemetry(
    snapshot: TxSnapshot,
    *,
    session_id: int,
    sequence: int,
    send_timestamp_ns: int | None = None,
) -> Telemetry:
    """Convert the latest state into a safe, self-aged wire snapshot."""

    if send_timestamp_ns is None:
        send_timestamp_ns = time.monotonic_ns()
    if snapshot.capture_timestamp_ns < 0:
        raise ValueError("采集时间戳不能为负数")
    if not all(
        math.isfinite(value)
        for value in (
            snapshot.x_m,
            snapshot.v_mps,
            snapshot.confidence,
            snapshot.target_x_m,
        )
    ):
        raise ValueError("视觉和任务数据必须是有限值")

    raw_delay_us = max(
        0,
        (int(send_timestamp_ns) - int(snapshot.capture_timestamp_ns)) // 1_000,
    )
    if raw_delay_us > CAPTURE_DELAY_LIMIT_US:
        raise SnapshotTooOldError(
            f"视觉快照超过C板合法心跳范围: {raw_delay_us / 1000.0:.1f} ms"
        )
    delay_us = raw_delay_us

    flags = Flags(int(snapshot.flags) & 0x0F)
    x_0p1mm = int(round(snapshot.x_m * 10_000.0))
    v_mmps = int(round(snapshot.v_mps * 1_000.0))
    confidence_u8 = _clamp(
        int(round(snapshot.confidence * 255.0)),
        0,
        255,
    )
    target_x_0p1mm = _clamp(
        int(round(snapshot.target_x_m * 10_000.0)),
        -TARGET_LIMIT_0P1MM,
        TARGET_LIMIT_0P1MM,
    )

    if not -X_LIMIT_0P1MM <= x_0p1mm <= X_LIMIT_0P1MM:
        flags &= ~(Flags.BALL_VALID | Flags.VELOCITY_VALID)
    if not -V_LIMIT_MMPS <= v_mmps <= V_LIMIT_MMPS:
        flags &= ~Flags.VELOCITY_VALID

    # A stale result keeps only the communication heartbeat alive; it must
    # never remain a control candidate.
    if raw_delay_us > MEASUREMENT_MAX_AGE_US:
        flags &= ~(Flags.BALL_VALID | Flags.VELOCITY_VALID)
        flags |= Flags.PROCESSING_DEGRADED

    if not flags & Flags.BALL_VALID:
        flags &= ~Flags.VELOCITY_VALID
        x_0p1mm = 0
        v_mmps = 0
        confidence_u8 = 0
    elif not flags & Flags.VELOCITY_VALID:
        v_mmps = 0

    return Telemetry(
        session_id=int(session_id) & 0xFFFFFFFF,
        sequence=int(sequence) & 0xFF,
        capture_timestamp_ms=(
            int(snapshot.capture_timestamp_ns) // 1_000_000
        )
        & 0xFFFFFFFF,
        capture_to_send_delay_us=int(delay_us),
        x_0p1mm=x_0p1mm,
        v_mmps=v_mmps,
        confidence_u8=confidence_u8,
        flags=flags,
        target_x_0p1mm=target_x_0p1mm,
        task_id=TaskId(int(snapshot.task_id)),
        control_flags=ControlFlags(int(snapshot.control_flags) & 0x1F),
        run_id=int(snapshot.run_id) & 0xFFFF,
    )


def _validate_message(message: Telemetry) -> None:
    if message.version != VERSION:
        raise ValueError(f"协议版本必须为 {VERSION}")
    if message.frame_type != VISION_CONTROL_SNAPSHOT:
        raise ValueError("消息类型必须为 VISION_CONTROL_SNAPSHOT")
    if not 0 <= message.sequence <= 0xFF:
        raise ValueError("帧序号必须位于 0-255")
    if not 0 <= message.capture_to_send_delay_us <= CAPTURE_DELAY_LIMIT_US:
        raise ValueError("采集到发送延迟越界")
    if not -X_LIMIT_0P1MM <= message.x_0p1mm <= X_LIMIT_0P1MM:
        raise ValueError("钢球位置越界")
    if not -V_LIMIT_MMPS <= message.v_mmps <= V_LIMIT_MMPS:
        raise ValueError("钢球速度越界")
    if not 0 <= message.confidence_u8 <= 255:
        raise ValueError("置信度越界")
    if not -TARGET_LIMIT_0P1MM <= message.target_x_0p1mm <= TARGET_LIMIT_0P1MM:
        raise ValueError("目标位置越界")
    if int(message.flags) & ~0x0F:
        raise ValueError("视觉保留标志必须为 0")
    if int(message.control_flags) & ~0x1F:
        raise ValueError("控制保留标志必须为 0")
    if not message.flags & Flags.BALL_VALID:
        if (
            message.x_0p1mm != 0
            or message.v_mmps != 0
            or message.confidence_u8 != 0
            or message.flags & Flags.VELOCITY_VALID
        ):
            raise ValueError("无球帧必须清零 x/v/confidence 和速度有效标志")
    elif not message.flags & Flags.VELOCITY_VALID and message.v_mmps != 0:
        raise ValueError("速度无效时 v 必须为 0")
    TaskId(int(message.task_id))


def encode_packet(message: Telemetry) -> bytes:
    _validate_message(message)
    payload = _PAYLOAD.pack(
        int(message.session_id) & 0xFFFFFFFF,
        int(message.capture_timestamp_ms) & 0xFFFFFFFF,
        int(message.capture_to_send_delay_us) & 0xFFFFFFFF,
        int(message.x_0p1mm),
        int(message.v_mmps),
        int(message.confidence_u8),
        int(message.flags),
        int(message.target_x_0p1mm),
        int(message.task_id),
        int(message.control_flags),
        int(message.run_id) & 0xFFFF,
    )
    header = _HEADER.pack(
        MAGIC_BYTES,
        VERSION,
        VISION_CONTROL_SNAPSHOT,
        int(message.sequence),
        len(payload),
    )
    crc_data = header[2:] + payload
    return header + payload + _CRC.pack(crc16_ccitt_false(crc_data))


def decode_packet(packet: bytes) -> Telemetry:
    if len(packet) != PACKET_SIZE:
        raise ValueError(f"BallLink 帧长度应为 {PACKET_SIZE}，实际为 {len(packet)}")
    magic, version, frame_type, sequence, payload_length = _HEADER.unpack_from(packet)
    if magic != MAGIC_BYTES:
        raise ValueError("BallLink 帧头错误")
    if version != VERSION:
        raise ValueError(f"不支持的协议版本: {version}")
    if frame_type != VISION_CONTROL_SNAPSHOT:
        raise ValueError(f"不支持的消息类型: 0x{frame_type:02X}")
    if payload_length != PAYLOAD_SIZE:
        raise ValueError(f"载荷长度应为 {PAYLOAD_SIZE}")

    expected_crc = _CRC.unpack_from(packet, PACKET_SIZE - _CRC.size)[0]
    actual_crc = crc16_ccitt_false(packet[2:-_CRC.size])
    if actual_crc != expected_crc:
        raise ValueError(
            f"CRC 错误: expected=0x{expected_crc:04X}, actual=0x{actual_crc:04X}"
        )

    (
        session_id,
        capture_timestamp_ms,
        capture_to_send_delay_us,
        x_0p1mm,
        v_mmps,
        confidence_u8,
        raw_flags,
        target_x_0p1mm,
        raw_task,
        raw_control,
        run_id,
    ) = _PAYLOAD.unpack_from(packet, _HEADER.size)
    try:
        task_id = TaskId(raw_task)
    except ValueError as error:
        raise ValueError(f"未知任务号: {raw_task}") from error

    message = Telemetry(
        session_id=session_id,
        sequence=sequence,
        capture_timestamp_ms=capture_timestamp_ms,
        capture_to_send_delay_us=capture_to_send_delay_us,
        x_0p1mm=x_0p1mm,
        v_mmps=v_mmps,
        confidence_u8=confidence_u8,
        flags=Flags(raw_flags),
        target_x_0p1mm=target_x_0p1mm,
        task_id=task_id,
        control_flags=ControlFlags(raw_control),
        run_id=run_id,
        version=version,
        frame_type=frame_type,
    )
    _validate_message(message)
    return message


class PacketFramer:
    """Recover current BallLink frames from arbitrary byte-stream chunks."""

    def __init__(self) -> None:
        self._buffer = bytearray()

    def push(self, data: bytes) -> list[Telemetry]:
        self._buffer.extend(data)
        output: list[Telemetry] = []
        while True:
            start = self._buffer.find(MAGIC_BYTES)
            if start < 0:
                if self._buffer[-1:] == MAGIC_BYTES[:1]:
                    self._buffer[:] = self._buffer[-1:]
                else:
                    self._buffer.clear()
                return output
            if start:
                del self._buffer[:start]
            if len(self._buffer) < _HEADER.size:
                return output
            payload_length = self._buffer[5]
            if payload_length > MAX_PAYLOAD_SIZE:
                del self._buffer[0]
                continue
            required = _HEADER.size + payload_length + _CRC.size
            if len(self._buffer) < required:
                return output
            candidate = bytes(self._buffer[:required])
            try:
                output.append(decode_packet(candidate))
                del self._buffer[:required]
            except ValueError:
                del self._buffer[0]
