"""Low-level Raspberry Pi peripherals, links, and byte protocols."""
