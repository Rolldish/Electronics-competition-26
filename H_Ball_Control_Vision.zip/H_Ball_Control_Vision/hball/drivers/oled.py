"""Minimal SSD1306 OLED peripheral driver."""

from __future__ import annotations

from typing import Any


class SSD1306:
    width = 128
    height = 64

    def __init__(self, bus_index: int = 1, address: int = 0x3C) -> None:
        try:
            from smbus2 import SMBus
        except ImportError:
            try:
                from smbus import SMBus  # type: ignore[no-redef]
            except ImportError as error:
                raise RuntimeError(
                    "OLED 需要 smbus2：sudo apt install python3-smbus "
                    "或 pip install smbus2"
                ) from error
        try:
            self._bus: Any = SMBus(bus_index)
        except Exception as error:
            raise RuntimeError(
                f"无法打开 I2C-{bus_index}；请启用树莓派 I2C"
            ) from error
        self.address = address
        self._initialize()

    def _command(self, value: int) -> None:
        self._bus.write_byte_data(self.address, 0x00, value & 0xFF)

    def _initialize(self) -> None:
        commands = (
            0xAE,
            0x20,
            0x00,
            0xB0,
            0xC8,
            0x00,
            0x10,
            0x40,
            0x81,
            0xFF,
            0xA1,
            0xA6,
            0xA8,
            0x3F,
            0xA4,
            0xD3,
            0x00,
            0xD5,
            0xF0,
            0xD9,
            0x22,
            0xDA,
            0x12,
            0xDB,
            0x40,
            0x8D,
            0x14,
            0xAF,
        )
        for command in commands:
            self._command(command)
        self.clear()

    def show(self, image: Any) -> None:
        try:
            from PIL import Image
        except ImportError as error:
            raise RuntimeError("OLED 菜单需要 Pillow") from error
        if not isinstance(image, Image.Image):
            raise TypeError("OLED 输入必须是 Pillow Image")
        source = image.convert("1").resize((self.width, self.height))
        pixels = source.load()
        framebuffer = bytearray(self.width * self.height // 8)
        for page in range(8):
            for x in range(self.width):
                value = 0
                for bit in range(8):
                    if pixels[x, page * 8 + bit]:
                        value |= 1 << bit
                framebuffer[page * self.width + x] = value

        for page in range(8):
            self._command(0xB0 + page)
            self._command(0x00)
            self._command(0x10)
            start = page * self.width
            row = framebuffer[start : start + self.width]
            for offset in range(0, self.width, 32):
                self._bus.write_i2c_block_data(
                    self.address,
                    0x40,
                    list(row[offset : offset + 32]),
                )

    def clear(self) -> None:
        try:
            from PIL import Image
        except ImportError as error:
            raise RuntimeError("OLED 菜单需要 Pillow") from error
        self.show(Image.new("1", (self.width, self.height), 0))

    def close(self) -> None:
        try:
            self.clear()
        finally:
            self._bus.close()
