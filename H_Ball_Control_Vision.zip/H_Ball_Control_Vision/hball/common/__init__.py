"""Shared configuration, calibration persistence, and presentation helpers."""
