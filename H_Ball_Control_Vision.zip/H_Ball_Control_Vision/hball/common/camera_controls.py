"""Atomic persistence for the independent runtime camera tuning result."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .atomic_json import atomic_write_json


_CONTROL_LIMITS = {
    "exposure": (1, 157),
    "gain": (0, 100),
    "white_balance_temperature": (2800, 6500),
}


def _validated_controls(raw: object) -> dict[str, int]:
    if not isinstance(raw, dict):
        raise RuntimeError("camera_controls.json 缺少 controls")
    controls: dict[str, int] = {}
    for name, (lower, upper) in _CONTROL_LIMITS.items():
        value = raw.get(name)
        if not isinstance(value, int) or not lower <= value <= upper:
            raise RuntimeError(
                f"camera_controls.json 的 {name} 必须位于 {lower}-{upper}"
            )
        controls[name] = value
    return controls


def load_camera_controls(path: Path) -> dict[str, int] | None:
    if not path.is_file():
        return None
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"无法读取相机自校准结果 {path}: {error}") from error
    if not isinstance(document, dict) or document.get("version") != 1:
        raise RuntimeError("camera_controls.json 版本无效")
    return _validated_controls(document.get("controls"))


def publish_camera_controls(
    path: Path,
    controls: dict[str, int],
    *,
    created_at_utc: str,
    metrics: dict[str, Any],
) -> None:
    validated = _validated_controls(controls)
    atomic_write_json(
        path,
        {
            "version": 1,
            "scope": "CURRENT_ENVIRONMENT",
            "created_at_utc": created_at_utc,
            "controls": validated,
            "metrics": metrics,
        },
    )
    loaded = load_camera_controls(path)
    if loaded != validated:
        raise RuntimeError("相机参数发布后回读不一致")
