"""Typed application configuration and TOML loading."""

from __future__ import annotations

import ipaddress
import tomllib
from dataclasses import dataclass, fields, replace
from pathlib import Path
from typing import Any, TypeVar

from .camera_controls import load_camera_controls


T = TypeVar("T")


@dataclass(frozen=True)
class CameraConfig:
    device: int = 0
    raw_mjpeg_passthrough: bool = True
    width: int = 640
    height: int = 480
    fps: int = 120
    fourcc: str = "MJPG"
    mmap_buffers: int = 4
    auto_exposure: bool = False
    exposure: int = 85
    exposure_dynamic_framerate: bool = False
    gain: int = 0
    auto_white_balance: bool = False
    white_balance_temperature: int = 4500
    warmup_frames: int = 8


@dataclass(frozen=True)
class TargetConfig:
    ball_diameter_m: float = 0.010


@dataclass(frozen=True)
class DetectorConfig:
    diff_threshold: int = 24
    gradient_threshold: int = 42
    min_radius_px: int = 4
    max_radius_px: int = 14
    min_score: float = 0.42
    morph_radius: int = 2
    max_candidates: int = 12
    max_track_jump_px: float = 130.0
    low_light_contrast_floor: int = 80
    local_illumination_radius_px: int = 24
    local_illumination_compensation: float = 0.85


@dataclass(frozen=True)
class TrackerConfig:
    max_predict_frames: int = 12
    max_predict_s: float = 0.10
    confidence_decay: float = 0.82
    alpha_min: float = 0.48
    alpha_max: float = 0.78
    beta_min: float = 0.04
    beta_max: float = 0.16
    acquire_confirm_frames: int = 3
    acquire_max_jump_px: float = 70.0
    acquire_radius_tolerance_ratio: float = 0.45
    acquire_min_motion: float = 0.15
    acquire_min_isolation: float = 0.08
    measurement_median_window: int = 3
    large_innovation_px: float = 28.0
    large_innovation_consistency_px: float = 48.0
    large_innovation_max_age_s: float = 0.08


@dataclass(frozen=True)
class MappingConfig:
    # 实物约定固定为右负左正：负端在画面右侧，正端在画面左侧。
    negative_point_px: tuple[float, float] = (560.0, 240.0)
    positive_point_px: tuple[float, float] = (80.0, 240.0)
    negative_position_m: float = -0.125
    positive_position_m: float = 0.125
    position_correction_enabled: bool = False
    position_correction_axis_fractions: tuple[float, ...] = (
        0.096111,
        0.274281,
        0.461220,
        0.670166,
        0.888223,
    )
    position_correction_positions_m: tuple[float, ...] = (
        -0.100,
        -0.050,
        0.000,
        0.050,
        0.100,
    )


@dataclass(frozen=True)
class TubePoseConfig:
    enabled: bool = True
    method: str = "green_contour"
    lock_after_background: bool = False
    update_fps: float = 15.0
    hold_s: float = 0.25
    downscale: float = 0.5
    green_h_min: int = 30
    green_h_max: int = 95
    green_s_min: int = 70
    green_v_min: int = 35
    green_excess_min: int = 4
    green_excess_ratio_min: float = 0.30
    low_light_green_s_min: int = 45
    low_light_green_v_min: int = 18
    low_light_green_excess_min: int = 6
    low_light_green_excess_ratio_min: float = 0.20
    min_brightness: int = 150
    brightness_percentile: float = 84.0
    min_axis_length_px: float = 280.0
    max_length_error_ratio: float = 0.40
    min_aspect_ratio: float = 5.0
    max_axis_angle_error_deg: float = 25.0
    min_confidence: float = 0.45
    smoothing_alpha: float = 0.38
    expected_width_px: float = 42.0
    corridor_margin_px: int = 40
    rectified_height: int = 160


@dataclass(frozen=True)
class SerialConfig:
    enabled: bool = False
    port: str = "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0"
    baudrate: int = 115200
    tx_hz: float = 50.0
    capture_latency_margin_ms: float = 0.0
    write_timeout_s: float = 0.02
    reconnect_interval_s: float = 1.0


@dataclass(frozen=True)
class UdpConfig:
    enabled: bool = True
    host: str = "192.168.50.255"
    port: int = 10002


@dataclass(frozen=True)
class VideoConfig:
    enabled: bool = True
    bind: str = "0.0.0.0"
    port: int = 8080
    fps: float = 20.0
    control_priority: bool = True
    degraded_fps: float = 10.0
    recovery_hold_s: float = 2.0
    full_rate_min_vision_fps: float = 35.0
    full_rate_max_processing_ms: float = 32.0
    full_rate_max_delay_us: int = 50_000
    annotate: bool = False


@dataclass(frozen=True)
class NetworkConfig:
    enabled: bool = True
    interface: str = "wlan1"
    connection_name: str = "H2026-CAR"
    ssid: str = "never give up"
    ipv4_cidr: str = "192.168.50.1/24"
    channel: int = 36
    country_code: str = "CN"
    driver: str = "mt76x2u"
    require_for_selftest: bool = True


@dataclass(frozen=True)
class RuntimeConfig:
    opencv_threads: int = 2
    log_interval_s: float = 1.0
    idle_vision_fps: float = 20.0
    control_target_vision_fps: float = 35.0
    control_min_vision_fps: float = 30.0
    control_max_processing_ms: float = 40.0
    status_update_hz: float = 5.0
    max_frame_start_age_ms: float = 20.0
    max_publish_age_ms: float = 50.0
    python_switch_interval_ms: float = 2.0
    disable_gc_during_realtime: bool = True
    startup_background_frames: int = 30
    startup_background_max_attempts: int = 180
    startup_background_retry_limit: int = 2


@dataclass(frozen=True)
class CalibrationConfig:
    camera_controls_path: Path = Path("calibration/camera_controls.json")
    sample_fps: float = 60.0
    preview_bind: str = "0.0.0.0"
    preview_port: int = 8080
    preview_fps: float = 8.0
    operator_clear_s: float = 2.0
    control_settle_s: float = 0.12
    frames_per_candidate: int = 5
    verification_frames: int = 20
    exposures: tuple[int, ...] = (64, 88, 120)
    gains: tuple[int, ...] = (0, 4, 8)
    white_balances: tuple[int, ...] = (4000, 4500, 5000)
    minimum_rail_shadow_value: float = 24.0
    maximum_green_clipping_ratio: float = 0.25
    minimum_pose_detection_rate: float = 0.80
    minimum_pose_confidence: float = 0.45
    maximum_pose_jitter_px: float = 8.0
    minimum_verification_pose_detection_rate: float = 0.90


@dataclass(frozen=True)
class PreflightConfig:
    empty_test_s: float = 3.0
    total_timeout_s: float = 10.0
    min_camera_fps: float = 50.0
    min_vision_fps: float = 30.0
    max_p95_processing_ms: float = 40.0
    max_empty_false_positive_rate: float = 0.02
    min_pose_confidence: float = 0.45
    max_cpu_temperature_c: float = 75.0
    require_performance_governor: bool = True
    reject_throttled: bool = True
    require_serial: bool = True
    require_hotspot: bool = True
    setup_empty_confirm_frames: int = 20
    setup_ball_confirm_frames: int = 10


@dataclass(frozen=True)
class DebugConfig:
    server_bind: str = "0.0.0.0"
    server_port: int = 8083
    server_fps: float = 10.0
    jpeg_quality: int = 82
    window_title: str = "H Ball Detection Debug"
    screenshot_dir: Path = Path("debug_captures")


@dataclass(frozen=True)
class PanelConfig:
    i2c_bus: int = 1
    oled_address: int = 0x3C
    button_gpio: int = 22
    button_hold_s: float = 0.5
    button_bounce_s: float = 0.05


@dataclass(frozen=True)
class TaskConfig:
    minimum_confidence: float = 180.0 / 255.0
    positive_target_m: float = 0.05
    negative_target_m: float = -0.05
    positive_reached_m: float = 0.045
    positive_reached_hold_s: float = 0.05
    final_error_m: float = 0.005
    final_speed_mps: float = 0.02
    final_hold_s: float = 0.30
    timeout_s: float = 5.0
    ready_error_m: float = 0.008
    ready_speed_mps: float = 0.03
    ready_hold_s: float = 0.30
    t6_min_target_m: float = -0.10
    t6_max_target_m: float = 0.10
    t6_step_m: float = 0.01


@dataclass(frozen=True)
class AppConfig:
    path: Path
    camera_controls_source: str
    camera: CameraConfig
    target: TargetConfig
    detector: DetectorConfig
    tracker: TrackerConfig
    mapping: MappingConfig
    tube_pose: TubePoseConfig
    serial: SerialConfig
    telemetry_udp: UdpConfig
    video: VideoConfig
    network: NetworkConfig
    runtime: RuntimeConfig
    calibration: CalibrationConfig
    preflight: PreflightConfig
    debug: DebugConfig
    panel: PanelConfig
    task: TaskConfig


def _construct(cls: type[T], values: dict[str, Any] | None) -> T:
    values = values or {}
    known = {field.name for field in fields(cls)}
    unknown = sorted(set(values) - known)
    if unknown:
        raise ValueError(f"{cls.__name__} 含未知配置项: {', '.join(unknown)}")
    return cls(**values)


def _resolve_path(config_dir: Path, raw: str | Path) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else (config_dir / path).resolve()


def load_config(path: str | Path) -> AppConfig:
    config_path = Path(path).expanduser().resolve()
    with config_path.open("rb") as stream:
        data = tomllib.load(stream)

    detector_values = dict(data.get("detector", {}))

    calibration_values = dict(data.get("calibration", {}))
    for key in ("camera_controls_path",):
        if key in calibration_values:
            calibration_values[key] = _resolve_path(
                config_path.parent, calibration_values[key]
            )
    for key in ("exposures", "gains", "white_balances"):
        if key in calibration_values:
            value = calibration_values[key]
            if not isinstance(value, list):
                raise ValueError(f"calibration.{key} must be an integer array")
            calibration_values[key] = tuple(int(item) for item in value)

    debug_values = dict(data.get("debug", {}))
    if "screenshot_dir" in debug_values:
        debug_values["screenshot_dir"] = _resolve_path(
            config_path.parent, debug_values["screenshot_dir"]
        )

    mapping_values = dict(data.get("mapping", {}))
    for key in ("negative_point_px", "positive_point_px"):
        if key in mapping_values:
            value = mapping_values[key]
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError(f"mapping.{key} 必须是两个数")
            mapping_values[key] = (float(value[0]), float(value[1]))
    camera = _construct(CameraConfig, data.get("camera"))
    calibration = _construct(CalibrationConfig, calibration_values)
    saved_camera_controls = load_camera_controls(
        calibration.camera_controls_path
    )
    camera_controls_source = "HARDWARE_BASELINE"
    if saved_camera_controls is not None:
        camera = replace(
            camera,
            auto_exposure=False,
            auto_white_balance=False,
            **saved_camera_controls,
        )
        camera_controls_source = "CURRENT_ENVIRONMENT"

    config = AppConfig(
        path=config_path,
        camera_controls_source=camera_controls_source,
        camera=camera,
        target=_construct(TargetConfig, data.get("target")),
        detector=_construct(DetectorConfig, detector_values),
        tracker=_construct(TrackerConfig, data.get("tracker")),
        mapping=_construct(MappingConfig, mapping_values),
        tube_pose=_construct(TubePoseConfig, data.get("tube_pose")),
        serial=_construct(SerialConfig, data.get("serial")),
        telemetry_udp=_construct(UdpConfig, data.get("telemetry_udp")),
        video=_construct(VideoConfig, data.get("video")),
        network=_construct(NetworkConfig, data.get("network")),
        runtime=_construct(RuntimeConfig, data.get("runtime")),
        calibration=calibration,
        preflight=_construct(PreflightConfig, data.get("preflight")),
        debug=_construct(DebugConfig, debug_values),
        panel=_construct(PanelConfig, data.get("panel")),
        task=_construct(TaskConfig, data.get("task")),
    )
    _validate(config)
    return config


def _validate(config: AppConfig) -> None:
    camera = config.camera
    if camera.width <= 0 or camera.height <= 0 or camera.fps <= 0:
        raise ValueError("摄像头宽、高和 FPS 必须大于 0")
    if len(camera.fourcc) != 4:
        raise ValueError("camera.fourcc 必须是 4 个字符")
    if camera.raw_mjpeg_passthrough and camera.fourcc not in {"MJPG", "JPEG"}:
        raise ValueError("原始 JPEG 直通要求 camera.fourcc 为 MJPG 或 JPEG")
    if camera.mmap_buffers < 2:
        raise ValueError("camera.mmap_buffers 至少为 2")
    if not 0.005 <= config.target.ball_diameter_m <= 0.020:
        raise ValueError("target.ball_diameter_m 应位于 0.005-0.020 m")

    detector = config.detector
    if not 1 <= detector.min_radius_px < detector.max_radius_px:
        raise ValueError("钢球半径必须满足 1 <= min < max")
    if not 0.0 < detector.min_score <= 1.0:
        raise ValueError("detector.min_score 必须位于 (0, 1]")
    if detector.max_candidates < 1 or detector.max_track_jump_px <= 0.0:
        raise ValueError("detector 候选数和最大跟踪跳变必须大于 0")

    tracker = config.tracker
    if tracker.max_predict_frames < 1 or tracker.max_predict_s <= 0.0:
        raise ValueError("tracker 预测帧数和预测时间必须大于 0")

    if tracker.acquire_confirm_frames < 1:
        raise ValueError("tracker.acquire_confirm_frames must be at least 1")
    if tracker.acquire_max_jump_px <= 0.0:
        raise ValueError("tracker.acquire_max_jump_px must be greater than 0")
    if not 0.0 <= tracker.acquire_radius_tolerance_ratio <= 1.0:
        raise ValueError(
            "tracker.acquire_radius_tolerance_ratio must be within [0,1]"
        )
    if not 0.0 <= tracker.acquire_min_motion <= 1.0:
        raise ValueError("tracker.acquire_min_motion must be within [0,1]")
    if not -1.0 <= tracker.acquire_min_isolation <= 1.0:
        raise ValueError("tracker.acquire_min_isolation must be within [-1,1]")
    if tracker.measurement_median_window not in {1, 3, 5}:
        raise ValueError(
            "tracker.measurement_median_window must be 1, 3, or 5"
        )
    if tracker.large_innovation_px <= 0.0:
        raise ValueError("tracker.large_innovation_px must be positive")
    if tracker.large_innovation_consistency_px < tracker.large_innovation_px:
        raise ValueError(
            "tracker.large_innovation_consistency_px must be >= large_innovation_px"
        )
    if not 0.02 <= tracker.large_innovation_max_age_s <= 0.10:
        raise ValueError("tracker.large_innovation_max_age_s must be in 0.02-0.10")

    mapping = config.mapping
    dx = mapping.positive_point_px[0] - mapping.negative_point_px[0]
    dy = mapping.positive_point_px[1] - mapping.negative_point_px[1]
    if dx * dx + dy * dy < 100.0:
        raise ValueError("坐标标定两点过近")
    if mapping.positive_position_m == mapping.negative_position_m:
        raise ValueError("坐标标定两点物理位置不能相同")
    if not 16 <= config.detector.low_light_contrast_floor <= 192:
        raise ValueError("detector.low_light_contrast_floor must be in 16-192")
    if not 4 <= config.detector.local_illumination_radius_px <= 64:
        raise ValueError("detector.local_illumination_radius_px must be in 4-64")
    if not 0.0 <= config.detector.local_illumination_compensation <= 1.0:
        raise ValueError(
            "detector.local_illumination_compensation must be in 0-1"
        )

    tube = config.tube_pose
    if tube.method not in {"green_contour", "white_contour", "static"}:
        raise ValueError(
            "tube_pose.method 必须为 green_contour、white_contour 或 static"
        )
    if not 1.0 <= tube.update_fps <= camera.fps:
        raise ValueError("tube_pose.update_fps 必须位于 1 到 camera.fps")
    if not 0.2 <= tube.downscale <= 1.0:
        raise ValueError("tube_pose.downscale 必须位于 0.2-1.0")
    if not 0 <= tube.min_brightness <= 255:
        raise ValueError("tube_pose.min_brightness 必须位于 0-255")
    if not 0 <= tube.green_h_min < tube.green_h_max <= 179:
        raise ValueError("tube_pose 绿色 H 范围必须位于 0-179 且下限小于上限")
    if not 0 <= tube.green_s_min <= 255 or not 0 <= tube.green_v_min <= 255:
        raise ValueError("tube_pose 绿色 S/V 下限必须位于 0-255")
    if not 0 <= tube.green_excess_min <= 255:
        raise ValueError("tube_pose.green_excess_min 必须位于 0-255")
    if not 0.0 <= tube.green_excess_ratio_min <= 1.0:
        raise ValueError("tube_pose.green_excess_ratio_min 必须位于 0-1")
    if not 0 <= tube.low_light_green_s_min <= 255:
        raise ValueError("tube_pose.low_light_green_s_min must be in 0-255")
    if not 0 <= tube.low_light_green_v_min <= 255:
        raise ValueError("tube_pose.low_light_green_v_min must be in 0-255")
    if not 0 <= tube.low_light_green_excess_min <= 255:
        raise ValueError("tube_pose.low_light_green_excess_min must be in 0-255")
    if not 0.0 <= tube.low_light_green_excess_ratio_min <= 1.0:
        raise ValueError("tube_pose.low_light_green_excess_ratio_min must be in 0-1")
    if not 50.0 <= tube.brightness_percentile <= 99.9:
        raise ValueError("tube_pose.brightness_percentile 必须位于 50-99.9")
    if tube.min_axis_length_px <= 0.0 or tube.expected_width_px <= 0.0:
        raise ValueError("tube_pose 几何尺寸必须大于 0")
    if not 0.0 < tube.min_confidence <= 1.0:
        raise ValueError("tube_pose.min_confidence 必须位于 (0,1]")
    if not 0.0 < tube.smoothing_alpha <= 1.0:
        raise ValueError("tube_pose.smoothing_alpha 必须位于 (0,1]")

    if not 1.0 <= config.video.fps <= 30.0:
        raise ValueError("video.fps 建议并限制在 1-30")
    if not 1.0 <= config.video.degraded_fps <= config.video.fps:
        raise ValueError("video.degraded_fps must be in 1-video.fps")
    if not 0.5 <= config.video.recovery_hold_s <= 10.0:
        raise ValueError("video.recovery_hold_s must be in 0.5-10")

    network = config.network
    if network.enabled:
        if not network.interface.strip():
            raise ValueError("network.interface 不能为空")
        if not network.connection_name.strip():
            raise ValueError("network.connection_name 不能为空")
        if not network.ssid.strip():
            raise ValueError("network.ssid 不能为空")
        if not 1 <= network.channel <= 196:
            raise ValueError("network.channel 必须位于1-196")
        if len(network.country_code) != 2 or not network.country_code.isalpha():
            raise ValueError("network.country_code 必须是两个英文字母")
        if not network.driver.strip():
            raise ValueError("network.driver 不能为空")
        try:
            address = ipaddress.ip_interface(network.ipv4_cidr)
        except ValueError as error:
            raise ValueError("network.ipv4_cidr 必须是有效的CIDR地址") from error
        if address.version != 4:
            raise ValueError("network.ipv4_cidr 必须是IPv4地址")

    if not 1.0 <= config.runtime.idle_vision_fps <= camera.fps:
        raise ValueError("runtime.idle_vision_fps 必须位于 1 到 camera.fps")
    if not (
        13.0
        <= config.runtime.control_min_vision_fps
        <= config.runtime.control_target_vision_fps
        <= camera.fps
    ):
        raise ValueError(
            "runtime control vision FPS must satisfy 13 <= min <= target <= camera"
        )
    if not 10.0 <= config.runtime.control_max_processing_ms <= 70.0:
        raise ValueError("runtime.control_max_processing_ms must be in 10-70")
    if not 1.0 <= config.runtime.status_update_hz <= 20.0:
        raise ValueError("runtime.status_update_hz must be in 1-20")
    if not 0.0 < config.runtime.max_frame_start_age_ms <= 40.0:
        raise ValueError("runtime.max_frame_start_age_ms must be in 0-40")
    if not (
        config.runtime.max_frame_start_age_ms
        < config.runtime.max_publish_age_ms
        <= 50.0
    ):
        raise ValueError(
            "runtime.max_publish_age_ms must be above frame-start age and at most 50 ms"
        )
    if not 1.0 <= config.runtime.python_switch_interval_ms <= 10.0:
        raise ValueError("runtime.python_switch_interval_ms must be in 1-10")
    if config.runtime.startup_background_frames < 5:
        raise ValueError("runtime.startup_background_frames 至少为 5")
    if (
        config.runtime.startup_background_max_attempts
        < config.runtime.startup_background_frames
    ):
        raise ValueError(
            "runtime.startup_background_max_attempts "
            "不能小于启动背景帧数"
        )

    if not 0 <= config.runtime.startup_background_retry_limit <= 5:
        raise ValueError(
            "runtime.startup_background_retry_limit must be in 0-5"
        )

    video = config.video
    if not (
        config.runtime.control_min_vision_fps
        <= video.full_rate_min_vision_fps
        <= camera.fps
    ):
        raise ValueError(
            "video.full_rate_min_vision_fps must be between the control minimum and camera FPS"
        )
    if not 5.0 <= video.full_rate_max_processing_ms <= config.runtime.control_max_processing_ms:
        raise ValueError(
            "video.full_rate_max_processing_ms must be in 5-control_max_processing_ms"
        )
    if not 10_000 <= video.full_rate_max_delay_us <= 70_000:
        raise ValueError("video.full_rate_max_delay_us must be in 10000-70000")

    serial = config.serial
    if not serial.port.strip():
        raise ValueError("serial.port 不能为空")
    if serial.baudrate != 115200:
        raise ValueError("BallLink 串口波特率必须为 115200")
    if abs(serial.tx_hz - 50.0) > 1e-6:
        raise ValueError("BallLink 发送频率必须为 50 Hz")
    if not 0.0 <= serial.capture_latency_margin_ms <= 50.0:
        raise ValueError("相机链路延迟裕量必须位于 0-50 ms")
    if not 0.005 <= serial.write_timeout_s <= 0.10:
        raise ValueError("BallLink write_timeout_s must be in 0.005-0.10 s")
    if serial.reconnect_interval_s <= 0.0:
        raise ValueError("串口写超时和重连时间必须大于 0")

    calibration = config.calibration
    if not 0.5 <= calibration.operator_clear_s <= 10.0:
        raise ValueError("calibration.operator_clear_s 必须位于 0.5 到 10 秒")
    if not 1.0 <= calibration.sample_fps <= camera.fps:
        raise ValueError("calibration.sample_fps 必须位于 1 到 camera.fps")
    if calibration.control_settle_s < 0.0:
        raise ValueError("calibration.control_settle_s cannot be negative")
    if calibration.frames_per_candidate < 1:
        raise ValueError("calibration.frames_per_candidate must be at least 1")
    if calibration.verification_frames < calibration.frames_per_candidate:
        raise ValueError(
            "calibration.verification_frames must be at least frames_per_candidate"
        )
    if not calibration.exposures or not all(1 <= value <= 157 for value in calibration.exposures):
        raise ValueError("calibration.exposures must contain values in 1-157")
    if not calibration.gains or not all(0 <= value <= 100 for value in calibration.gains):
        raise ValueError("calibration.gains must contain values in 0-100")
    if not calibration.white_balances or not all(
        2800 <= value <= 6500 for value in calibration.white_balances
    ):
        raise ValueError("calibration.white_balances must contain values in 2800-6500")
    if not 0 <= calibration.minimum_rail_shadow_value <= 255:
        raise ValueError("calibration.minimum_rail_shadow_value must be in 0-255")
    if not 0.0 <= calibration.maximum_green_clipping_ratio <= 1.0:
        raise ValueError("calibration.maximum_green_clipping_ratio must be in 0-1")
    if not 0.0 <= calibration.minimum_pose_detection_rate <= 1.0:
        raise ValueError("calibration.minimum_pose_detection_rate must be in 0-1")
    if not 0.0 <= calibration.minimum_pose_confidence <= 1.0:
        raise ValueError("calibration.minimum_pose_confidence must be in 0-1")
    if calibration.maximum_pose_jitter_px <= 0.0:
        raise ValueError("calibration.maximum_pose_jitter_px must be positive")
    if not (
        calibration.minimum_pose_detection_rate
        <= calibration.minimum_verification_pose_detection_rate
        <= 1.0
    ):
        raise ValueError(
            "calibration.minimum_verification_pose_detection_rate must be "
            "between minimum_pose_detection_rate and 1"
        )

    preflight = config.preflight
    if preflight.empty_test_s <= 0.0 or preflight.total_timeout_s <= preflight.empty_test_s:
        raise ValueError("preflight timeout must exceed the empty-rail test duration")
    if not 1.0 <= preflight.min_camera_fps <= camera.fps:
        raise ValueError("preflight.min_camera_fps must be in 1-camera.fps")
    if not 1.0 <= preflight.min_vision_fps <= camera.fps:
        raise ValueError("preflight.min_vision_fps must be in 1-camera.fps")
    if preflight.max_p95_processing_ms <= 0.0:
        raise ValueError("preflight.max_p95_processing_ms must be positive")
    if not 0.0 <= preflight.max_empty_false_positive_rate <= 1.0:
        raise ValueError("preflight.max_empty_false_positive_rate must be in 0-1")
    if not 0.0 < preflight.min_pose_confidence <= 1.0:
        raise ValueError("preflight.min_pose_confidence must be in (0,1]")
    if not 40.0 <= preflight.max_cpu_temperature_c <= 90.0:
        raise ValueError("preflight.max_cpu_temperature_c must be in 40-90")

    if preflight.setup_empty_confirm_frames < 5:
        raise ValueError(
            "preflight.setup_empty_confirm_frames must be at least 5"
        )
    if preflight.setup_ball_confirm_frames < 3:
        raise ValueError(
            "preflight.setup_ball_confirm_frames must be at least 3"
        )

    debug = config.debug
    if not 1.0 <= debug.server_fps <= 30.0:
        raise ValueError("debug.server_fps 必须位于 1-30")
    if not 30 <= debug.jpeg_quality <= 100:
        raise ValueError("debug.jpeg_quality 必须位于 30-100")
    if not 1 <= debug.server_port <= 65535:
        raise ValueError("debug.server_port 无效")

    panel = config.panel
    if panel.i2c_bus < 0 or not 0x03 <= panel.oled_address <= 0x77:
        raise ValueError("panel I2C 总线或 OLED 地址无效")
    if not 0 <= panel.button_gpio <= 27:
        raise ValueError("panel.button_gpio 必须是 BCM 0-27")
    if panel.button_hold_s <= 0.0 or panel.button_bounce_s < 0.0:
        raise ValueError("panel 按键时间参数无效")

    task = config.task
    if not 0.0 < task.minimum_confidence <= 1.0:
        raise ValueError("task.minimum_confidence 必须位于 (0,1]")
    if not task.negative_target_m < 0.0 < task.positive_target_m:
        raise ValueError("task 正负目标必须跨越 O 点")
    if task.final_error_m <= 0.0 or task.final_speed_mps <= 0.0:
        raise ValueError("task 完成误差和速度必须大于 0")
    if task.timeout_s <= 0.0:
        raise ValueError("task 时间参数必须大于 0")
    if (
        task.ready_error_m <= 0.0
        or task.ready_speed_mps <= 0.0
        or task.ready_hold_s <= 0.0
    ):
        raise ValueError("task READY 判据必须大于 0")
    if not -0.12 <= task.t6_min_target_m < task.t6_max_target_m <= 0.12:
        raise ValueError("T6 可选范围必须位于题目允许的±12 cm安全范围内")
    if task.t6_step_m <= 0.0:
        raise ValueError("T6 步进必须大于 0")
