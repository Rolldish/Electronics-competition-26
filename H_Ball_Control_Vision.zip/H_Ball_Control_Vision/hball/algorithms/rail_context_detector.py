"""Raw-frame steel-ball candidates constrained by the green rail geometry."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass

import cv2
import numpy as np

from ..common.config import DetectorConfig, MappingConfig, TubePoseConfig
from .tube_pose import TubePose, TubeRectifier, green_mask_bgr


@dataclass(frozen=True)
class RailBallCandidate:
    x_px: float
    y_px: float
    radius_px: float
    axis_fraction: float
    cross_axis_px: float
    score: float
    accepted: bool
    rejection: str
    source: str
    circularity: float
    fit_valid: bool
    fit_error_ratio: float
    expected_radius_px: float
    radius_error_ratio: float
    edge_coverage: float
    radial_score: float
    change_ratio: float
    non_green_ratio: float
    green_annulus_ratio: float
    achromatic_ratio: float


@dataclass(frozen=True)
class RailContextResult:
    candidates: tuple[RailBallCandidate, ...]
    accepted: tuple[RailBallCandidate, ...]
    corridor_mask: np.ndarray
    green_mask: np.ndarray
    anomaly_mask: np.ndarray
    processing_ms: float
    contour_count: int
    hough_count: int
    seed_diagnostics: dict[str, object]


class RailContextBallDetector:
    """Generate ball candidates in the original camera frame.

    Perspective geometry is used only to define the current rail corridor and
    the one-dimensional axis coordinate.  Pixel intensities are never warped.
    """

    def __init__(
        self,
        detector: DetectorConfig,
        tube: TubePoseConfig,
        mapping: MappingConfig,
        ball_diameter_m: float,
    ) -> None:
        self.detector = detector
        self.tube = tube
        self.rectifier = TubeRectifier(tube, mapping)
        rail_length_m = abs(
            mapping.positive_position_m - mapping.negative_position_m
        )
        self._ball_radius_to_rail_length = (
            ball_diameter_m * 0.5 / max(rail_length_m, 1e-6)
        )
        self._background_lab: np.ndarray | None = None
        morph_radius = max(1, detector.morph_radius)
        open_size = max(3, 2 * morph_radius - 1)
        close_size = 2 * morph_radius + 1
        self._open_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (open_size, open_size),
        )
        self._close_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (close_size, close_size),
        )
        angles = np.linspace(0.0, 2.0 * math.pi, 72, endpoint=False)
        self._cos = np.cos(angles).astype(np.float32)
        self._sin = np.sin(angles).astype(np.float32)
        self._last_illumination_shift_p95 = 0.0
        self._last_shadow_compensation_active = False

    @property
    def background_ready(self) -> bool:
        return self._background_lab is not None

    def clear_background(self) -> None:
        self._background_lab = None

    def reference_sample(self, frame: np.ndarray, pose: TubePose) -> np.ndarray:
        strip, _ = self.rectifier.rectify(frame, pose)
        return cv2.cvtColor(strip, cv2.COLOR_BGR2LAB)

    def set_background(self, samples: list[np.ndarray]) -> None:
        if len(samples) < 5:
            raise ValueError("registered rail background requires at least 5 frames")
        expected = samples[0].shape
        if any(sample.shape != expected for sample in samples):
            raise ValueError("registered rail background sample shape mismatch")
        self._background_lab = np.median(
            np.stack(samples, axis=0),
            axis=0,
        ).astype(np.uint8)

    def detect(self, frame: np.ndarray, pose: TubePose) -> RailContextResult:
        if frame.ndim != 3 or frame.shape[2] != 3:
            raise ValueError("rail-context detector requires one BGR frame")
        if self._background_lab is None:
            raise RuntimeError("registered no-ball rail background is not ready")
        started = time.perf_counter()
        corridor = self._corridor_mask(frame.shape[:2], pose)
        roi_x1, roi_y1, roi_x2, roi_y2 = self._analysis_roi(corridor)
        frame_roi = frame[roi_y1:roi_y2, roi_x1:roi_x2]
        corridor_roi = corridor[roi_y1:roi_y2, roi_x1:roi_x2]
        green = np.zeros(frame.shape[:2], dtype=np.uint8)
        green[roi_y1:roi_y2, roi_x1:roi_x2] = self._green_mask(
            frame_roi
        )
        anomaly = self._registered_change_mask(frame, pose)
        anomaly = cv2.bitwise_and(anomaly, corridor)
        anomaly = cv2.morphologyEx(
            anomaly,
            cv2.MORPH_OPEN,
            self._open_kernel,
            iterations=1,
        )
        anomaly = cv2.morphologyEx(
            anomaly,
            cv2.MORPH_CLOSE,
            self._close_kernel,
            iterations=1,
        )

        gray = cv2.cvtColor(frame_roi, cv2.COLOR_BGR2GRAY)
        analysis_gray, contrast_span, contrast_enhanced = (
            self._low_light_analysis_gray(gray, corridor_roi)
        )
        smooth = cv2.GaussianBlur(analysis_gray, (5, 5), 1.0)
        gx = cv2.Sobel(smooth, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(smooth, cv2.CV_32F, 0, 1, ksize=3)
        magnitude = cv2.magnitude(gx, gy)

        seeds, contour_count, seed_diagnostics = self._contour_seeds(anomaly)
        seed_diagnostics["change_pixels"] = int(np.count_nonzero(anomaly))
        seed_diagnostics["corridor_contrast_span"] = round(contrast_span, 1)
        seed_diagnostics["low_light_contrast_enhanced"] = contrast_enhanced
        seed_diagnostics["illumination_shift_p95"] = round(
            self._last_illumination_shift_p95,
            1,
        )
        seed_diagnostics["shadow_compensation_active"] = (
            self._last_shadow_compensation_active
        )
        seed_diagnostics["analysis_roi"] = {
            "x": roi_x1,
            "y": roi_y1,
            "width": roi_x2 - roi_x1,
            "height": roi_y2 - roi_y1,
            "pixel_ratio": round(
                ((roi_x2 - roi_x1) * (roi_y2 - roi_y1))
                / max(frame.shape[0] * frame.shape[1], 1),
                4,
            ),
        }
        seeds = self._merge_seeds(seeds)

        # Registered colour change is both more selective and more accurate
        # than a frame-only circle search.  In the final mechanical assembly,
        # however, the fixed camera-support shadow can split the ball blob and
        # leave no usable contour.  Evaluate colour-difference seeds first and
        # run Hough only as a fallback; otherwise a static rail reflection can
        # outrank the real ball even when the real blob is already reliable.
        evaluated = [
            self._evaluate(
                frame,
                pose,
                corridor,
                green,
                anomaly,
                gx,
                gy,
                magnitude,
                x,
                y,
                radius,
                source,
                circularity,
                (roi_x1, roi_y1),
            )
            for x, y, radius, source, circularity in seeds
        ]
        contour_accepted = any(item.accepted for item in evaluated)
        hough_seeds: list[tuple[float, float, float, str, float]] = []
        if not contour_accepted:
            hough_seeds = self._merge_seeds(
                self._hough_seeds(
                    smooth,
                    corridor_roi,
                    offset=(roi_x1, roi_y1),
                )
            )
            evaluated.extend(
                self._evaluate(
                    frame,
                    pose,
                    corridor,
                    green,
                    anomaly,
                    gx,
                    gy,
                    magnitude,
                    x,
                    y,
                    radius,
                    source,
                    circularity,
                    (roi_x1, roi_y1),
                )
                for x, y, radius, source, circularity in hough_seeds
            )
        seed_diagnostics["hough_fallback_used"] = not contour_accepted
        seed_diagnostics["hough_seeds"] = len(hough_seeds)
        evaluated.sort(key=lambda item: item.score, reverse=True)
        accepted = tuple(item for item in evaluated if item.accepted)
        return RailContextResult(
            candidates=tuple(evaluated),
            accepted=accepted,
            corridor_mask=corridor,
            green_mask=green,
            anomaly_mask=anomaly,
            processing_ms=(time.perf_counter() - started) * 1000.0,
            contour_count=contour_count,
            hough_count=len(hough_seeds),
            seed_diagnostics=seed_diagnostics,
        )

    def _hough_seeds(
        self,
        smooth: np.ndarray,
        corridor: np.ndarray,
        *,
        offset: tuple[int, int] = (0, 0),
    ) -> list[tuple[float, float, float, str, float]]:
        """Find partial ball rims only inside the narrow physical rail corridor.

        Registered colour change remains the acceptance evidence.  Hough is
        used only to seed a circle when a fixed camera-support shadow splits
        the ball foreground into elongated or incomplete components.
        """

        points = cv2.findNonZero(corridor)
        if points is None:
            return []
        x, y, width, height = cv2.boundingRect(points)
        if width < 2 * self.detector.min_radius_px or height < 5:
            return []
        crop = smooth[y : y + height, x : x + width].copy()
        crop_mask = corridor[y : y + height, x : x + width] > 0
        inside = crop[crop_mask]
        fill = int(np.median(inside)) if inside.size else 0
        crop[~crop_mask] = fill
        circles = cv2.HoughCircles(
            crop,
            cv2.HOUGH_GRADIENT,
            dp=1.0,
            minDist=max(8.0, self.detector.min_radius_px * 1.5),
            param1=max(36.0, float(self.detector.gradient_threshold)),
            param2=9.0,
            minRadius=self.detector.min_radius_px,
            maxRadius=self.detector.max_radius_px,
        )
        if circles is None:
            return []
        seeds: list[tuple[float, float, float, str, float]] = []
        for local_x, local_y, radius in circles[0]:
            roi_center_x = float(local_x + x)
            roi_center_y = float(local_y + y)
            ix = int(round(roi_center_x))
            iy = int(round(roi_center_y))
            if not (0 <= ix < corridor.shape[1] and 0 <= iy < corridor.shape[0]):
                continue
            if corridor[iy, ix] == 0:
                continue
            seeds.append(
                (
                    roi_center_x + offset[0],
                    roi_center_y + offset[1],
                    float(radius),
                    "RAIL_HOUGH",
                    0.62,
                )
            )
        return seeds[: self.detector.max_candidates]

    def _analysis_roi(
        self,
        corridor: np.ndarray,
    ) -> tuple[int, int, int, int]:
        """Return the fixed-rail processing box with a ball-sized guard band."""
        points = cv2.findNonZero(corridor)
        if points is None:
            return 0, 0, corridor.shape[1], corridor.shape[0]
        x, y, width, height = cv2.boundingRect(points)
        padding = self.detector.max_radius_px + 3
        return (
            max(0, x - padding),
            max(0, y - padding),
            min(corridor.shape[1], x + width + padding),
            min(corridor.shape[0], y + height + padding),
        )

    def _registered_change_mask(
        self,
        frame: np.ndarray,
        pose: TubePose,
    ) -> np.ndarray:
        assert self._background_lab is not None
        strip, inverse = self.rectifier.rectify(frame, pose)
        current_lab = cv2.cvtColor(strip, cv2.COLOR_BGR2LAB)
        signed = current_lab.astype(np.int16) - self._background_lab.astype(np.int16)

        center_y = int(round(self.rectifier.height * 0.5))
        half_height = int(
            max(
                self.rectifier.rail_half_height * 0.82,
                self.detector.max_radius_px * 1.25,
            )
        )
        top = max(0, center_y - half_height)
        bottom = min(self.rectifier.height, center_y + half_height + 1)
        # The physical negative end may be on either image side. Calibration
        # deliberately orients the axis from -x to +x, so never assume that
        # the negative endpoint has the smaller rectified x coordinate.
        left = max(
            0,
            int(
                round(
                    min(
                        self.rectifier.negative_px[0],
                        self.rectifier.positive_px[0],
                    )
                )
            ),
        )
        right = min(
            self.rectifier.width,
            int(
                round(
                    max(
                        self.rectifier.negative_px[0],
                        self.rectifier.positive_px[0],
                    )
                )
            )
            + 1,
        )
        calibration_area = signed[top:bottom, left:right]
        if calibration_area.size:
            global_shift = np.median(
                calibration_area.reshape(-1, 3),
                axis=0,
            )
            signed = signed - global_shift.reshape(1, 1, 3)
        # A person, bracket, or changing venue light can introduce a broad
        # local luminance shift after the no-ball background was captured.
        # Remove only that low-frequency L component. The smaller steel ball,
        # its rim, and both LAB chroma channels remain as detection evidence.
        luminance = signed[:, :, 0].astype(np.float32)
        radius_x = int(self.detector.local_illumination_radius_px)
        radius_y = max(4, int(round(radius_x * 0.35)))
        local_illumination = cv2.blur(
            luminance,
            (2 * radius_x + 1, 2 * radius_y + 1),
            borderType=cv2.BORDER_REFLECT,
        )
        compensated_luminance = luminance - (
            float(self.detector.local_illumination_compensation)
            * local_illumination
        )
        absolute = np.abs(signed).astype(np.float32)
        absolute[:, :, 0] = np.abs(compensated_luminance)
        rail_local_shift = np.abs(local_illumination[top:bottom, left:right])
        self._last_illumination_shift_p95 = (
            float(np.percentile(rail_local_shift, 95.0))
            if rail_local_shift.size
            else 0.0
        )
        self._last_shadow_compensation_active = (
            self._last_illumination_shift_p95 >= 6.0
        )
        score = (
            0.55 * absolute[:, :, 0]
            + 0.80 * absolute[:, :, 1]
            + 0.80 * absolute[:, :, 2]
        )

        hsv = cv2.cvtColor(strip, cv2.COLOR_BGR2HSV)
        low_saturation = hsv[:, :, 1] <= 175
        difference_threshold = float(self.detector.diff_threshold)
        changed = (score >= difference_threshold) & (
            low_saturation | (score >= 2.0 * difference_threshold)
        )
        strip_mask = np.zeros(score.shape, dtype=np.uint8)
        strip_mask[top:bottom, left:right][changed[top:bottom, left:right]] = 255
        strip_mask = cv2.morphologyEx(
            strip_mask,
            cv2.MORPH_OPEN,
            self._open_kernel,
            iterations=1,
        )
        strip_mask = cv2.morphologyEx(
            strip_mask,
            cv2.MORPH_CLOSE,
            self._close_kernel,
            iterations=1,
        )
        return cv2.warpPerspective(
            strip_mask,
            inverse,
            (frame.shape[1], frame.shape[0]),
            flags=cv2.INTER_NEAREST,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )

    def _corridor_mask(
        self,
        shape: tuple[int, int],
        pose: TubePose,
    ) -> np.ndarray:
        height, width = shape
        axis = np.asarray(pose.axis, dtype=np.float32)
        length = max(1.0, float(np.linalg.norm(axis)))
        unit = axis / length
        normal = np.array([-unit[1], unit[0]], dtype=np.float32)
        half_width = max(
            self.detector.max_radius_px * 1.35,
            pose.width_px * 0.30,
        )
        extension = self.detector.max_radius_px * 1.15
        negative = np.asarray(pose.negative_px, dtype=np.float32) - unit * extension
        positive = np.asarray(pose.positive_px, dtype=np.float32) + unit * extension
        polygon = np.asarray(
            [
                negative - normal * half_width,
                positive - normal * half_width,
                positive + normal * half_width,
                negative + normal * half_width,
            ],
            dtype=np.int32,
        )
        mask = np.zeros((height, width), dtype=np.uint8)
        cv2.fillConvexPoly(mask, polygon, 255)
        return mask

    def _green_mask(self, frame: np.ndarray) -> np.ndarray:
        return green_mask_bgr(frame, self.tube)

    def _low_light_analysis_gray(
        self,
        gray: np.ndarray,
        corridor: np.ndarray,
    ) -> tuple[np.ndarray, float, bool]:
        """Increase weak edge contrast without altering detection evidence.

        Registered LAB change and green/achromatic evidence use the original
        frame. Only Sobel and Hough receive the LUT-stretched grayscale image,
        so a brightness change cannot create a fake foreground object.
        """
        pixels = gray[corridor > 0]
        if pixels.size < 64:
            return gray, 255.0, False
        low, high = np.percentile(pixels, (1.0, 99.0))
        span = float(high - low)
        target = float(self.detector.low_light_contrast_floor)
        if span >= target or span < 4.0:
            return gray, span, False
        scale = min(3.0, target / span)
        values = np.arange(256, dtype=np.float32)
        lut = np.clip((values - float(low)) * scale + float(low), 0, 255)
        return cv2.LUT(gray, lut.astype(np.uint8)), span, True

    def _contour_seeds(
        self,
        anomaly: np.ndarray,
    ) -> tuple[
        list[tuple[float, float, float, str, float]],
        int,
        dict[str, object],
    ]:
        contours, _ = cv2.findContours(
            anomaly,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_NONE,
        )
        seeds: list[tuple[float, float, float, str, float]] = []
        minimum_area = math.pi * self.detector.min_radius_px**2 * 0.18
        maximum_area = math.pi * self.detector.max_radius_px**2 * 2.8
        rejection_counts = {
            "too_small": 0,
            "too_large": 0,
            "short_perimeter": 0,
            "elongated": 0,
            "radius": 0,
            "accepted_seed": 0,
        }
        contour_details: list[dict[str, object]] = []
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < minimum_area:
                rejection_counts["too_small"] += 1
                contour_details.append(
                    {"area": round(area, 1), "rejected": "TOO_SMALL"}
                )
                continue
            if area > maximum_area:
                rejection_counts["too_large"] += 1
                contour_details.append(
                    {"area": round(area, 1), "rejected": "TOO_LARGE"}
                )
                continue
            perimeter = float(cv2.arcLength(contour, True))
            if perimeter <= 1.0:
                rejection_counts["short_perimeter"] += 1
                continue
            x, y, width, height = cv2.boundingRect(contour)
            aspect = min(width, height) / max(1.0, float(max(width, height)))
            if aspect < 0.38:
                rejection_counts["elongated"] += 1
                contour_details.append(
                    {
                        "area": round(area, 1),
                        "width": width,
                        "height": height,
                        "aspect": round(aspect, 3),
                        "rejected": "ELONGATED",
                    }
                )
                continue
            (center_x, center_y), radius = cv2.minEnclosingCircle(contour)
            if not (
                self.detector.min_radius_px * 0.75
                <= radius
                <= self.detector.max_radius_px * 1.30
            ):
                rejection_counts["radius"] += 1
                contour_details.append(
                    {
                        "area": round(area, 1),
                        "width": width,
                        "height": height,
                        "radius": round(float(radius), 2),
                        "rejected": "RADIUS",
                    }
                )
                continue
            circularity = float(
                np.clip(4.0 * math.pi * area / (perimeter**2), 0.0, 1.0)
            )
            rejection_counts["accepted_seed"] += 1
            contour_details.append(
                {
                    "area": round(area, 1),
                    "width": width,
                    "height": height,
                    "aspect": round(aspect, 3),
                    "radius": round(float(radius), 2),
                    "circularity": round(circularity, 3),
                    "rejected": "NONE",
                }
            )
            seeds.append(
                (
                    float(center_x),
                    float(center_y),
                    float(radius),
                    "COLOR_DIFF",
                    circularity,
                )
            )
        contour_details.sort(
            key=lambda item: float(item.get("area", 0.0)),
            reverse=True,
        )
        return (
            seeds,
            len(contours),
            {
                "minimum_area": round(minimum_area, 2),
                "maximum_area": round(maximum_area, 2),
                "rejections": rejection_counts,
                "largest_contours": contour_details[:6],
            },
        )

    def _merge_seeds(
        self,
        seeds: list[tuple[float, float, float, str, float]],
    ) -> list[tuple[float, float, float, str, float]]:
        merged: list[tuple[float, float, float, str, float]] = []
        for seed in sorted(seeds, key=lambda item: item[4], reverse=True):
            duplicate = False
            for existing in merged:
                if math.hypot(seed[0] - existing[0], seed[1] - existing[1]) <= 5.0:
                    duplicate = True
                    break
            if not duplicate:
                merged.append(seed)
        return merged[: self.detector.max_candidates]

    def _evaluate(
        self,
        frame: np.ndarray,
        pose: TubePose,
        corridor: np.ndarray,
        green: np.ndarray,
        anomaly: np.ndarray,
        gx: np.ndarray,
        gy: np.ndarray,
        magnitude: np.ndarray,
        center_x: float,
        center_y: float,
        seed_radius: float,
        source: str,
        circularity: float,
        gradient_origin: tuple[int, int] = (0, 0),
    ) -> RailBallCandidate:
        expected_radius = float(
            np.clip(
                pose.length_px * self._ball_radius_to_rail_length,
                self.detector.min_radius_px,
                self.detector.max_radius_px,
            )
        )
        original_center_x = center_x
        original_center_y = center_y
        original_seed_radius = seed_radius
        gradient_x = center_x - gradient_origin[0]
        gradient_y = center_y - gradient_origin[1]
        (
            gradient_x,
            gradient_y,
            seed_radius,
            fit_error_ratio,
            fit_valid,
        ) = self._refine_circle(
            gx,
            gy,
            magnitude,
            gradient_x,
            gradient_y,
            seed_radius,
        )
        center_x = gradient_x + gradient_origin[0]
        center_y = gradient_y + gradient_origin[1]
        if (
            fit_valid
            and abs(seed_radius - expected_radius) / max(expected_radius, 1e-6)
            > 0.45
        ):
            # A hard shadow edge can look more circular than the steel-ball
            # boundary. Do not let that outer edge move the candidate or seed
            # the radius search far away from the known 10 mm ball size.
            center_x = original_center_x
            center_y = original_center_y
            seed_radius = original_seed_radius
            fit_error_ratio = 0.0
            fit_valid = False
        axis = np.asarray(pose.axis, dtype=np.float32)
        length = max(1.0, float(np.linalg.norm(axis)))
        unit = axis / length
        normal = np.array([-unit[1], unit[0]], dtype=np.float32)
        relative = np.asarray(
            [center_x - pose.negative_px[0], center_y - pose.negative_px[1]],
            dtype=np.float32,
        )
        fraction = float(relative @ unit / length)
        cross_axis = float(relative @ normal)
        if pose.corners_px is not None:
            # A top-view camera is still not perfectly orthographic.  Use the
            # same rail homography as registered background subtraction for
            # the one-dimensional coordinate, otherwise five physical points
            # are measurably nonlinear in raw image pixels.
            forward, _ = self.rectifier.matrices(pose)
            rectified_x, _ = self.rectifier.transform_point(
                forward,
                (center_x, center_y),
            )
            denominator = (
                self.rectifier.positive_px[0]
                - self.rectifier.negative_px[0]
            )
            if abs(denominator) > 1e-6:
                fraction = float(
                    (rectified_x - self.rectifier.negative_px[0])
                    / denominator
                )

        radius, edge_coverage, radial_score = self._best_radius(
            gx,
            gy,
            magnitude,
            center_x - gradient_origin[0],
            center_y - gradient_origin[1],
            seed_radius,
            expected_radius,
        )
        radius_error_ratio = (
            abs(radius - expected_radius) / max(expected_radius, 1e-6)
        )
        disk, annulus, bounds = self._local_masks(
            frame.shape[:2],
            center_x,
            center_y,
            radius,
        )
        x1, y1, x2, y2 = bounds
        inside_count = max(1, int(np.count_nonzero(disk)))
        annulus_count = max(1, int(np.count_nonzero(annulus)))
        local_anomaly = anomaly[y1:y2, x1:x2] > 0
        local_green = green[y1:y2, x1:x2] > 0
        change_ratio = float(np.count_nonzero(local_anomaly & disk)) / inside_count
        non_green_ratio = float(np.count_nonzero((~local_green) & disk)) / inside_count
        green_annulus_ratio = (
            float(np.count_nonzero(local_green & annulus)) / annulus_count
        )
        hsv = cv2.cvtColor(frame[y1:y2, x1:x2], cv2.COLOR_BGR2HSV)
        achromatic_ratio = (
            float(np.count_nonzero((hsv[:, :, 1] <= 155) & disk)) / inside_count
        )

        center_score = float(
            np.clip(1.0 - abs(cross_axis) / max(pose.width_px * 0.34, 1.0), 0.0, 1.0)
        )
        change_score = float(np.clip(change_ratio / 0.30, 0.0, 1.0))
        non_green_score = float(np.clip(non_green_ratio / 0.38, 0.0, 1.0))
        annulus_target = 0.16 if fraction < 0.10 or fraction > 0.90 else 0.30
        annulus_score = float(
            np.clip(green_annulus_ratio / max(annulus_target, 1e-6), 0.0, 1.0)
        )
        achromatic_score = float(np.clip(achromatic_ratio / 0.20, 0.0, 1.0))
        fit_score = (
            float(np.clip(1.0 - fit_error_ratio / 0.24, 0.0, 1.0))
            if fit_valid
            else 0.50
        )
        radius_score = float(
            math.exp(-0.5 * (radius_error_ratio / 0.24) ** 2)
        )
        score = (
            0.18 * edge_coverage
            + 0.12 * radial_score
            + 0.14 * circularity
            + 0.10 * fit_score
            + 0.12 * change_score
            + 0.08 * non_green_score
            + 0.08 * annulus_score
            + 0.06 * achromatic_score
            + 0.04 * center_score
            + 0.08 * radius_score
        )
        strong_contour_evidence = (
            circularity >= 0.60
            and edge_coverage >= 0.60
            and radial_score >= 0.55
            and change_ratio >= 0.35
            and abs(cross_axis) <= pose.width_px * 0.20
        )
        strong_ball_appearance = (
            change_ratio >= 0.24
            and non_green_ratio >= 0.62
            and achromatic_ratio >= 0.32
            and green_annulus_ratio >= annulus_target * 0.50
            and abs(cross_axis) <= max(pose.width_px * 0.24, radius * 0.90)
        )
        hough_appearance_valid = (
            source != "RAIL_HOUGH"
            or (
                change_ratio >= 0.20
                and non_green_ratio >= 0.36
                and achromatic_ratio >= 0.20
            )
        )
        # The fixed camera-support shadow can split the true ball rim so the
        # least-squares refinement has too few evenly distributed edge points.
        # Accept that Hough seed without a valid fit only when every independent
        # rail-context cue is strong.  This deliberately does not rescue weak
        # Hough reflections or relax the final confidence threshold.
        shadow_split_hough_evidence = (
            source == "RAIL_HOUGH"
            and circularity >= 0.58
            and edge_coverage >= 0.40
            and radial_score >= 0.40
            and change_ratio >= 0.20
            and non_green_ratio >= 0.60
            and achromatic_ratio >= 0.50
            and green_annulus_ratio >= annulus_target * 0.75
            and radius_error_ratio <= 0.25
            and abs(cross_axis)
            <= max(pose.width_px * 0.24, radius * 0.90)
        )
        if shadow_split_hough_evidence:
            # Nine mutually independent cues replace the missing least-squares
            # fit.  Reflect that evidence in confidence instead of lowering the
            # frozen 180/255 control threshold.  The observed real-ball sample
            # rises from 0.685 to about 0.725; weak Hough seeds get no bonus.
            score = min(1.0, score + 0.04)

        rejection = "NONE"
        if not 0.04 <= fraction <= 0.96:
            rejection = "OUTSIDE_AXIS"
        elif abs(cross_axis) > max(pose.width_px * 0.24, radius * 0.90):
            rejection = "OUTSIDE_CENTER"
        elif not hough_appearance_valid:
            rejection = "WEAK_HOUGH_APPEARANCE"
        elif circularity < 0.40 and not strong_ball_appearance:
            rejection = "LOW_COMPACTNESS"
        elif radius_error_ratio > 0.45:
            rejection = "RADIUS_MISMATCH"
        elif edge_coverage < 0.20 and not strong_ball_appearance:
            rejection = "LOW_CIRCLE_EDGE"
        elif radial_score < 0.28 and not strong_ball_appearance:
            rejection = "LOW_RADIAL"
        elif fit_valid and fit_error_ratio > 0.24 and not strong_ball_appearance:
            rejection = "POOR_CIRCLE_FIT"
        elif (
            not fit_valid
            and not strong_contour_evidence
            and not strong_ball_appearance
            and not shadow_split_hough_evidence
        ):
            rejection = "NO_RELIABLE_CIRCLE"
        elif change_ratio < 0.08:
            rejection = "LOW_REGISTERED_CHANGE"
        elif non_green_ratio < 0.12:
            rejection = "TOO_GREEN"
        elif green_annulus_ratio < annulus_target * 0.50:
            rejection = "NO_GREEN_CONTEXT"
        elif achromatic_ratio < 0.09:
            rejection = "NO_STEEL_PIXELS"
        elif score < max(0.48, self.detector.min_score):
            rejection = "LOW_SCORE"

        return RailBallCandidate(
            x_px=center_x,
            y_px=center_y,
            radius_px=radius,
            axis_fraction=fraction,
            cross_axis_px=cross_axis,
            score=float(np.clip(score, 0.0, 1.0)),
            accepted=rejection == "NONE",
            rejection=rejection,
            source=source,
            circularity=circularity,
            fit_valid=fit_valid,
            fit_error_ratio=fit_error_ratio,
            expected_radius_px=expected_radius,
            radius_error_ratio=radius_error_ratio,
            edge_coverage=edge_coverage,
            radial_score=radial_score,
            change_ratio=change_ratio,
            non_green_ratio=non_green_ratio,
            green_annulus_ratio=green_annulus_ratio,
            achromatic_ratio=achromatic_ratio,
        )

    def _best_radius(
        self,
        gx: np.ndarray,
        gy: np.ndarray,
        magnitude: np.ndarray,
        center_x: float,
        center_y: float,
        seed_radius: float,
        expected_radius: float,
    ) -> tuple[float, float, float]:
        base_radius = float(
            np.clip(
                seed_radius,
                self.detector.min_radius_px,
                self.detector.max_radius_px,
            )
        )
        low = max(
            self.detector.min_radius_px,
            int(math.floor(expected_radius * 0.65)),
        )
        high = min(
            self.detector.max_radius_px,
            int(math.ceil(expected_radius * 1.40)),
        )
        if low > high:
            low = high = int(
                round(
                    np.clip(
                        expected_radius,
                        self.detector.min_radius_px,
                        self.detector.max_radius_px,
                    )
                )
            )
        evaluated: list[tuple[float, float, float, float]] = []
        for radius in range(low, high + 1):
            xs = center_x + radius * self._cos
            ys = center_y + radius * self._sin
            xi = np.clip(np.rint(xs).astype(np.int32), 0, gx.shape[1] - 1)
            yi = np.clip(np.rint(ys).astype(np.int32), 0, gx.shape[0] - 1)
            ring_magnitude = magnitude[yi, xi]
            alignment = np.abs(
                gx[yi, xi] * self._cos + gy[yi, xi] * self._sin
            ) / np.maximum(ring_magnitude, 1e-6)
            strong = ring_magnitude >= max(18.0, self.detector.gradient_threshold * 0.55)
            coverage = float(np.mean(strong & (alignment >= 0.48)))
            radial = float(
                np.mean(
                    np.clip(
                        alignment
                        * ring_magnitude
                        / max(1.0, self.detector.gradient_threshold),
                        0.0,
                        1.0,
                    )
                )
            )
            radius_error = (
                abs(float(radius) - expected_radius)
                / max(expected_radius, 1e-6)
            )
            radius_prior = math.exp(-0.5 * (radius_error / 0.20) ** 2)
            combined = (
                0.40 * coverage
                + 0.20 * radial
                + 0.40 * radius_prior
            )
            evaluated.append((float(radius), coverage, radial, combined))

        if not evaluated:
            return base_radius, 0.0, 0.0

        maximum_score = max(item[3] for item in evaluated)
        maximum_coverage = max(item[1] for item in evaluated)
        near_best = [
            item
            for item in evaluated
            if item[3] >= maximum_score - 0.025
            and item[1] >= maximum_coverage * 0.80
        ]
        selected = (
            min(near_best, key=lambda item: item[0])
            if near_best
            else max(evaluated, key=lambda item: item[3])
        )
        return selected[0], selected[1], selected[2]

    def _refine_circle(
        self,
        gx: np.ndarray,
        gy: np.ndarray,
        magnitude: np.ndarray,
        center_x: float,
        center_y: float,
        seed_radius: float,
    ) -> tuple[float, float, float, float, bool]:
        """Fit a circle to locally radial edge pixels in the original frame."""
        radius = float(
            np.clip(
                seed_radius,
                self.detector.min_radius_px,
                self.detector.max_radius_px,
            )
        )
        extent = int(math.ceil(radius * 1.55 + 3.0))
        x1 = max(0, int(math.floor(center_x)) - extent)
        y1 = max(0, int(math.floor(center_y)) - extent)
        x2 = min(gx.shape[1], int(math.ceil(center_x)) + extent + 1)
        y2 = min(gx.shape[0], int(math.ceil(center_y)) + extent + 1)
        if x2 - x1 < 5 or y2 - y1 < 5:
            return center_x, center_y, radius, 0.0, False

        yy, xx = np.mgrid[y1:y2, x1:x2]
        dx = xx.astype(np.float32) - center_x
        dy = yy.astype(np.float32) - center_y
        distance = np.sqrt(dx * dx + dy * dy)
        local_magnitude = magnitude[y1:y2, x1:x2]
        alignment = np.abs(
            gx[y1:y2, x1:x2] * dx + gy[y1:y2, x1:x2] * dy
        ) / np.maximum(local_magnitude * distance, 1e-6)
        selected = (
            (distance >= radius * 0.68)
            & (distance <= radius * 1.34)
            & (
                local_magnitude
                >= max(18.0, self.detector.gradient_threshold * 0.55)
            )
            & (alignment >= 0.52)
        )
        points_x = xx[selected].astype(np.float64)
        points_y = yy[selected].astype(np.float64)
        if points_x.size < 10:
            return center_x, center_y, radius, 0.0, False

        matrix = np.column_stack(
            (2.0 * points_x, 2.0 * points_y, np.ones(points_x.size))
        )
        target = points_x * points_x + points_y * points_y
        try:
            solution, _, _, _ = np.linalg.lstsq(matrix, target, rcond=None)
        except np.linalg.LinAlgError:
            return center_x, center_y, radius, 0.0, False
        fitted_x, fitted_y, constant = solution
        squared_radius = constant + fitted_x * fitted_x + fitted_y * fitted_y
        if squared_radius <= 0.0:
            return center_x, center_y, radius, 0.0, False
        fitted_radius = math.sqrt(float(squared_radius))
        center_shift = math.hypot(fitted_x - center_x, fitted_y - center_y)
        if (
            center_shift > 3.5
            or fitted_radius < self.detector.min_radius_px
            or fitted_radius > self.detector.max_radius_px
        ):
            return center_x, center_y, radius, 0.0, False

        residual = np.abs(
            np.hypot(points_x - fitted_x, points_y - fitted_y) - fitted_radius
        )
        fit_error_ratio = float(
            np.median(residual) / max(fitted_radius, 1e-6)
        )
        return (
            float(fitted_x),
            float(fitted_y),
            float(fitted_radius),
            fit_error_ratio,
            True,
        )

    @staticmethod
    def _local_masks(
        shape: tuple[int, int],
        center_x: float,
        center_y: float,
        radius: float,
    ) -> tuple[np.ndarray, np.ndarray, tuple[int, int, int, int]]:
        height, width = shape
        outer = max(3.0, radius * 1.75)
        extent = int(math.ceil(outer))
        x1 = max(0, int(math.floor(center_x)) - extent)
        y1 = max(0, int(math.floor(center_y)) - extent)
        x2 = min(width, int(math.ceil(center_x)) + extent + 1)
        y2 = min(height, int(math.ceil(center_y)) + extent + 1)
        yy, xx = np.ogrid[y1:y2, x1:x2]
        distance_sq = (xx - center_x) ** 2 + (yy - center_y) ** 2
        disk = distance_sq <= radius**2
        annulus = (distance_sq >= (radius * 1.18) ** 2) & (
            distance_sq <= outer**2
        )
        return disk, annulus, (x1, y1, x2, y2)
