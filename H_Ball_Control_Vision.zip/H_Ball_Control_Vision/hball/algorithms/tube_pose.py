"""Green U-channel pose estimation and narrow-strip perspective rectification."""

from __future__ import annotations

import math
from dataclasses import dataclass, replace

import cv2
import numpy as np

from ..common.config import MappingConfig, TubePoseConfig


Point = tuple[float, float]


def green_mask_bgr(frame: np.ndarray, config: TubePoseConfig) -> np.ndarray:
    """Build a selective green-rail mask for normal and weak lighting."""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    hue = hsv[:, :, 0]
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]
    hue_ok = (hue >= config.green_h_min) & (hue <= config.green_h_max)

    b, g, r = cv2.split(frame)
    green_excess = g.astype(np.int16) - np.maximum(
        b.astype(np.int16), r.astype(np.int16)
    )
    green_excess_ratio = green_excess.astype(np.float32) / np.maximum(
        g.astype(np.float32), 1.0
    )

    normal = (
        hue_ok
        & (saturation >= config.green_s_min)
        & (value >= config.green_v_min)
        & (green_excess >= config.green_excess_min)
        & (green_excess_ratio >= config.green_excess_ratio_min)
    )
    # This branch does not merely lower HSV thresholds: dark pixels must still
    # have a measurable green-channel advantage. Morphology and rail geometry
    # reject isolated high-gain colour noise downstream.
    low_light = (
        hue_ok
        & (saturation >= config.low_light_green_s_min)
        & (value >= config.low_light_green_v_min)
        & (green_excess >= config.low_light_green_excess_min)
        & (
            green_excess_ratio
            >= config.low_light_green_excess_ratio_min
        )
    )
    mask = np.zeros(frame.shape[:2], dtype=np.uint8)
    mask[normal | low_light] = 255
    return mask


def _distance(a: Point, b: Point) -> float:
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _angle_error_degrees(a: Point, b: Point) -> float:
    a_length = max(1e-6, math.hypot(a[0], a[1]))
    b_length = max(1e-6, math.hypot(b[0], b[1]))
    cosine = abs((a[0] * b[0] + a[1] * b[1]) / (a_length * b_length))
    return math.degrees(math.acos(float(np.clip(cosine, -1.0, 1.0))))


@dataclass(frozen=True)
class TubePose:
    negative_px: Point
    positive_px: Point
    width_px: float
    confidence: float
    timestamp_ns: int
    measured: bool
    source: str = "GREEN"
    # 顺序固定为：负端上沿、正端上沿、正端下沿、负端下沿。
    # 有四角时使用透视变换；静态配置没有四角时退化为矩形。
    corners_px: tuple[Point, Point, Point, Point] | None = None

    @property
    def center_px(self) -> Point:
        return (
            (self.negative_px[0] + self.positive_px[0]) * 0.5,
            (self.negative_px[1] + self.positive_px[1]) * 0.5,
        )

    @property
    def axis(self) -> Point:
        return (
            self.positive_px[0] - self.negative_px[0],
            self.positive_px[1] - self.negative_px[1],
        )

    @property
    def length_px(self) -> float:
        return _distance(self.negative_px, self.positive_px)

    def point_at_fraction(self, fraction: float) -> Point:
        return (
            self.negative_px[0] + fraction * self.axis[0],
            self.negative_px[1] + fraction * self.axis[1],
        )

    def mapping(self, base: MappingConfig) -> MappingConfig:
        return MappingConfig(
            negative_point_px=self.negative_px,
            positive_point_px=self.positive_px,
            negative_position_m=base.negative_position_m,
            positive_position_m=base.positive_position_m,
        )


class RailPoseEstimator:
    """Track the green U-channel with temporal and geometry gating.

    The estimator deliberately returns no pose instead of guessing when the
    rail silhouette is ambiguous. The C-board failsafe is safer than using a
    stale coordinate system.
    """

    def __init__(self, config: TubePoseConfig, mapping: MappingConfig) -> None:
        self.config = config
        self.reference_axis = (
            mapping.positive_point_px[0] - mapping.negative_point_px[0],
            mapping.positive_point_px[1] - mapping.negative_point_px[1],
        )
        self.reference_length = math.hypot(*self.reference_axis)
        self.reference_pose = TubePose(
            mapping.negative_point_px,
            mapping.positive_point_px,
            config.expected_width_px,
            1.0,
            0,
            True,
            "REFERENCE",
        )
        self._last: TubePose | None = None
        self._last_attempt_ns = -10**18
        self._update_interval_ns = int(1e9 / config.update_fps)
        self.last_diagnostics: dict[str, object] = {
            "result": "NOT_RUN",
        }

    def reset(self) -> None:
        self._last = None
        self._last_attempt_ns = -10**18

    def seed(self, pose: TubePose) -> None:
        """Start temporal gating from an already validated reference pose."""
        self._last = pose
        self._last_attempt_ns = -10**18

    def update(
        self,
        gray: np.ndarray,
        timestamp_ns: int,
        *,
        force: bool = False,
    ) -> TubePose | None:
        if not self.config.enabled or self.config.method == "static":
            return TubePose(
                self.reference_pose.negative_px,
                self.reference_pose.positive_px,
                self.reference_pose.width_px,
                1.0,
                timestamp_ns,
                True,
                "STATIC",
                None,
            )

        due = timestamp_ns - self._last_attempt_ns >= self._update_interval_ns
        if force or due:
            self._last_attempt_ns = timestamp_ns
            measured = self._detect(gray, timestamp_ns)
            if measured is not None and measured.confidence >= self.config.min_confidence:
                self.last_diagnostics["result"] = "ACCEPTED"
                self.last_diagnostics["minimum_confidence"] = round(
                    self.config.min_confidence,
                    4,
                )
                self._last = self._smooth(measured)
                return self._last
            if measured is not None:
                self.last_diagnostics["result"] = "LOW_CONFIDENCE"
                self.last_diagnostics["candidate_confidence"] = round(
                    measured.confidence,
                    4,
                )
                self.last_diagnostics["minimum_confidence"] = round(
                    self.config.min_confidence,
                    4,
                )

        if self._last is None:
            return None
        age_s = (timestamp_ns - self._last.timestamp_ns) * 1e-9
        if age_s > self.config.hold_s:
            return None
        confidence = self._last.confidence * max(
            0.0, 1.0 - age_s / max(self.config.hold_s, 1e-6)
        )
        return TubePose(
            self._last.negative_px,
            self._last.positive_px,
            self._last.width_px,
            confidence,
            self._last.timestamp_ns,
            False,
            "HELD",
            self._last.corners_px,
        )

    def _detect(self, frame: np.ndarray, timestamp_ns: int) -> TubePose | None:
        if self.config.method == "green_contour":
            return self._detect_green(frame, timestamp_ns)
        return self._detect_white(frame, timestamp_ns)

    def _detect_green(
        self, frame: np.ndarray, timestamp_ns: int
    ) -> TubePose | None:
        if frame.ndim != 3 or frame.shape[2] != 3:
            return None
        scale = self.config.downscale
        if scale != 1.0:
            small = cv2.resize(
                frame,
                None,
                fx=scale,
                fy=scale,
                interpolation=cv2.INTER_AREA,
            )
        else:
            small = frame
        mask = green_mask_bgr(small, self.config)
        close_size = max(
            3,
            int(round(self.config.expected_width_px * scale * 0.30)),
        )
        if close_size % 2 == 0:
            close_size += 1
        # High UVC gain leaves isolated, green-biased pixels in dark regions.
        # Remove those bridges before closing gaps inside the solid rail.
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
            iterations=1,
        )
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(
                cv2.MORPH_ELLIPSE, (close_size, close_size)
            ),
            iterations=1,
        )
        # The steel ball and its dark reflection interrupt the saturated green
        # strip by roughly one ball diameter.  Join only gaps along the known
        # rail axis; an isotropic kernel large enough to do this would also
        # merge the greenish floor and chassis into the rail silhouette.
        axis_close_length = max(
            5,
            int(round(self.config.expected_width_px * scale * 0.90)),
        )
        axis_kernel = self._axis_close_kernel(axis_close_length, scale)
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            axis_kernel,
            iterations=1,
        )
        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        pose = self._best_contour_pose(
            contours,
            timestamp_ns,
            scale,
            source="GREEN",
            allow_perspective=True,
        )
        if pose is not None:
            return pose

        # A fixed camera bracket can cast a hard vertical shadow across the
        # rail.  In that case the normal one-ball-diameter close deliberately
        # leaves two roughly half-length contours, both rejected as TOO_SHORT.
        # Retry only after that exact failure, using a longer *axis-only*
        # kernel.  The result then has to remain close to the known 25 cm rail
        # length and pivot centre; this is intentionally stricter than the
        # ordinary single-contour path so unrelated green chassis parts cannot
        # be joined into a plausible rail.
        rejection_counts = self.last_diagnostics.get("rejections", {})
        if (
            not isinstance(rejection_counts, dict)
            or int(rejection_counts.get("too_short", 0)) < 2
        ):
            return None
        bridge_length = max(
            axis_close_length + 2,
            int(round(self.config.expected_width_px * scale * 2.0)),
        )
        bridge_kernel = self._axis_close_kernel(bridge_length, scale)
        bridged_mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_CLOSE,
            bridge_kernel,
            iterations=1,
        )
        bridged_contours, _ = cv2.findContours(
            bridged_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        bridged = self._best_contour_pose(
            bridged_contours,
            timestamp_ns,
            scale,
            source="GREEN_SHADOW_BRIDGE",
            allow_perspective=True,
        )
        self.last_diagnostics["shadow_bridge_attempted"] = True
        if bridged is None:
            self.last_diagnostics["shadow_bridge_used"] = False
            return None
        length_error = abs(bridged.length_px - self.reference_length) / max(
            self.reference_length,
            1.0,
        )
        center_error = _distance(
            bridged.center_px,
            self.reference_pose.center_px,
        )
        self.last_diagnostics["shadow_bridge_length_error"] = round(
            length_error,
            4,
        )
        self.last_diagnostics["shadow_bridge_center_error_px"] = round(
            center_error,
            2,
        )
        if (
            length_error > 0.25
            or center_error > max(
                float(self.config.corridor_margin_px),
                self.config.expected_width_px,
            )
        ):
            self.last_diagnostics["result"] = "SHADOW_BRIDGE_REJECTED"
            self.last_diagnostics["shadow_bridge_used"] = False
            return None
        self.last_diagnostics["shadow_bridge_used"] = True
        return bridged

    def _axis_close_kernel(
        self,
        axis_length: int,
        scale: float,
    ) -> np.ndarray:
        if axis_length % 2 == 0:
            axis_length += 1
        axis_thickness = max(3, int(round(6.0 * scale)))
        if axis_thickness % 2 == 0:
            axis_thickness += 1
        kernel_size = max(axis_length, axis_thickness)
        if kernel_size % 2 == 0:
            kernel_size += 1
        kernel = np.zeros((kernel_size, kernel_size), dtype=np.uint8)
        reference = np.asarray(self.reference_axis, dtype=np.float32)
        reference /= max(float(np.linalg.norm(reference)), 1e-6)
        center = np.asarray(
            ((kernel_size - 1) * 0.5, (kernel_size - 1) * 0.5),
            dtype=np.float32,
        )
        half = reference * ((axis_length - 1) * 0.5)
        cv2.line(
            kernel,
            tuple(np.rint(center - half).astype(int)),
            tuple(np.rint(center + half).astype(int)),
            255,
            axis_thickness,
            cv2.LINE_8,
        )
        return kernel

    def _detect_white(
        self, frame: np.ndarray, timestamp_ns: int
    ) -> TubePose | None:
        gray = (
            cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            if frame.ndim == 3
            else frame
        )
        scale = self.config.downscale
        if scale != 1.0:
            small = cv2.resize(
                gray,
                None,
                fx=scale,
                fy=scale,
                interpolation=cv2.INTER_AREA,
            )
        else:
            small = gray
        blurred = cv2.GaussianBlur(small, (5, 5), 0)
        percentile = float(
            np.percentile(blurred[::2, ::2], self.config.brightness_percentile)
        )
        threshold = int(
            np.clip(max(self.config.min_brightness, percentile), 0, 250)
        )
        _, mask = cv2.threshold(blurred, threshold, 255, cv2.THRESH_BINARY)
        close_size = max(3, int(round(self.config.expected_width_px * scale * 0.45)))
        if close_size % 2 == 0:
            close_size += 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (close_size, close_size)
        )
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
            iterations=1,
        )
        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        return self._best_contour_pose(
            contours,
            timestamp_ns,
            scale,
            source="WHITE",
            allow_perspective=False,
        )

    def _best_contour_pose(
        self,
        contours: list[np.ndarray],
        timestamp_ns: int,
        scale: float,
        *,
        source: str,
        allow_perspective: bool,
    ) -> TubePose | None:
        candidates: list[tuple[float, TubePose]] = []
        rectangles: list[dict[str, object]] = []
        rejection_counts = {
            "too_few_points": 0,
            "too_short": 0,
            "low_aspect": 0,
            "length_error": 0,
            "angle_error": 0,
            "geometry_pass": 0,
        }
        reference_axis = self.reference_axis
        expected_small = self.reference_length * scale
        minimum_small = self.config.min_axis_length_px * scale
        for contour in contours:
            if len(contour) < 4:
                rejection_counts["too_few_points"] += 1
                continue
            rect = cv2.minAreaRect(contour)
            center, size, angle = rect
            del angle
            long_side = max(float(size[0]), float(size[1]))
            short_side = max(1.0, min(float(size[0]), float(size[1])))
            rectangle = {
                "long_px": round(long_side / scale, 1),
                "short_px": round(short_side / scale, 1),
                "aspect": round(long_side / short_side, 2),
            }
            if long_side < minimum_small:
                rectangle["rejected"] = "TOO_SHORT"
                rectangles.append(rectangle)
                rejection_counts["too_short"] += 1
                continue
            aspect = long_side / short_side
            if aspect < self.config.min_aspect_ratio:
                rectangle["rejected"] = "LOW_ASPECT"
                rectangles.append(rectangle)
                rejection_counts["low_aspect"] += 1
                continue
            length_error = abs(long_side - expected_small) / max(expected_small, 1.0)
            rectangle["length_error"] = round(length_error, 3)
            if length_error > self.config.max_length_error_ratio:
                rectangle["rejected"] = "LENGTH_ERROR"
                rectangles.append(rectangle)
                rejection_counts["length_error"] += 1
                continue

            # A rectangle diagonal is not its axis. Use the min-area-rectangle
            # orientation and choose the dimension that corresponds to long_side.
            theta = math.radians(float(rect[2]))
            direction = np.array([math.cos(theta), math.sin(theta)], np.float32)
            if float(size[0]) < float(size[1]):
                direction = np.array([-direction[1], direction[0]], np.float32)
            axis_small = (float(direction[0]), float(direction[1]))
            axis_full = (axis_small[0] / scale, axis_small[1] / scale)
            angle_error = _angle_error_degrees(axis_full, reference_axis)
            rectangle["angle_error_deg"] = round(angle_error, 2)
            if angle_error > self.config.max_axis_angle_error_deg:
                rectangle["rejected"] = "ANGLE_ERROR"
                rectangles.append(rectangle)
                rejection_counts["angle_error"] += 1
                continue
            rectangle["rejected"] = "NONE"
            rectangles.append(rectangle)
            rejection_counts["geometry_pass"] += 1

            center_array = np.asarray(center, np.float32)
            half = direction * (long_side * 0.5)
            negative_small = center_array - half
            positive_small = center_array + half
            corners: tuple[Point, Point, Point, Point] | None = None
            if allow_perspective:
                points = contour.reshape(-1, 2).astype(np.float32)
                relative = points - center_array
                normal = np.array(
                    [-direction[1], direction[0]], dtype=np.float32
                )
                longitudinal = relative @ direction
                transverse = relative @ normal
                low = float(np.percentile(longitudinal, 3.0))
                high = float(np.percentile(longitudinal, 97.0))
                span = max(1.0, high - low)
                negative_band = longitudinal <= low + 0.14 * span
                positive_band = longitudinal >= high - 0.14 * span
                if np.count_nonzero(negative_band) >= 2:
                    neg_low = float(np.percentile(transverse[negative_band], 8.0))
                    neg_high = float(np.percentile(transverse[negative_band], 92.0))
                else:
                    neg_low, neg_high = -short_side * 0.5, short_side * 0.5
                if np.count_nonzero(positive_band) >= 2:
                    pos_low = float(np.percentile(transverse[positive_band], 8.0))
                    pos_high = float(np.percentile(transverse[positive_band], 92.0))
                else:
                    pos_low, pos_high = -short_side * 0.5, short_side * 0.5

                def raw_point(along: float, across: float) -> Point:
                    value = center_array + direction * along + normal * across
                    return (
                        float(value[0] / scale),
                        float(value[1] / scale),
                    )

                negative_small = center_array + direction * low
                positive_small = center_array + direction * high
                corners = (
                    raw_point(low, neg_low),
                    raw_point(high, pos_low),
                    raw_point(high, pos_high),
                    raw_point(low, neg_high),
                )
            negative = (
                float(negative_small[0] / scale),
                float(negative_small[1] / scale),
            )
            positive = (
                float(positive_small[0] / scale),
                float(positive_small[1] / scale),
            )
            candidate_axis = (
                positive[0] - negative[0],
                positive[1] - negative[1],
            )
            if (
                candidate_axis[0] * reference_axis[0]
                + candidate_axis[1] * reference_axis[1]
            ) < 0.0:
                negative, positive = positive, negative
                if corners is not None:
                    corners = (corners[1], corners[0], corners[3], corners[2])

            rect_area = max(1.0, long_side * short_side)
            fill = float(np.clip(cv2.contourArea(contour) / rect_area, 0.0, 1.0))
            length_score = math.exp(-0.5 * (length_error / 0.22) ** 2)
            aspect_score = float(
                np.clip(
                    (aspect - self.config.min_aspect_ratio)
                    / max(self.config.min_aspect_ratio * 2.0, 1.0),
                    0.0,
                    1.0,
                )
            )
            temporal_score = self._temporal_score(negative, positive)
            confidence = (
                0.38 * length_score
                + 0.24 * aspect_score
                + 0.18 * fill
                + 0.20 * temporal_score
            )
            pose = TubePose(
                negative,
                positive,
                short_side / scale,
                float(np.clip(confidence, 0.0, 1.0)),
                timestamp_ns,
                True,
                source,
                corners,
            )
            candidates.append((confidence, pose))

        top_rectangles = sorted(
            rectangles,
            key=lambda item: float(item["long_px"]),
            reverse=True,
        )[:5]
        self.last_diagnostics = {
            "result": "CANDIDATE" if candidates else "NO_GEOMETRY",
            "contours": len(contours),
            "expected_length_px": round(self.reference_length, 1),
            "minimum_length_px": round(self.config.min_axis_length_px, 1),
            "maximum_length_error": round(
                self.config.max_length_error_ratio,
                3,
            ),
            "minimum_aspect": round(self.config.min_aspect_ratio, 2),
            "maximum_angle_error_deg": round(
                self.config.max_axis_angle_error_deg,
                2,
            ),
            "rejections": rejection_counts,
            "largest_rectangles": top_rectangles,
        }
        if not candidates:
            return None
        best = max(candidates, key=lambda item: item[0])[1]
        self.last_diagnostics["candidate_confidence"] = round(
            best.confidence,
            4,
        )
        self.last_diagnostics["candidate_length_px"] = round(
            best.length_px,
            1,
        )
        self.last_diagnostics["candidate_width_px"] = round(
            best.width_px,
            1,
        )
        return best

    def _temporal_score(self, negative: Point, positive: Point) -> float:
        if self._last is None:
            return 0.75
        center = ((negative[0] + positive[0]) * 0.5, (negative[1] + positive[1]) * 0.5)
        center_error = _distance(center, self._last.center_px)
        angle_error = _angle_error_degrees(
            (positive[0] - negative[0], positive[1] - negative[1]),
            self._last.axis,
        )
        return math.exp(-0.5 * (center_error / 45.0) ** 2) * math.exp(
            -0.5 * (angle_error / 8.0) ** 2
        )

    def _smooth(self, measured: TubePose) -> TubePose:
        if self._last is None:
            return measured
        alpha = self.config.smoothing_alpha

        def blend(old: Point, new: Point) -> Point:
            return (
                old[0] + alpha * (new[0] - old[0]),
                old[1] + alpha * (new[1] - old[1]),
            )

        return TubePose(
            blend(self._last.negative_px, measured.negative_px),
            blend(self._last.positive_px, measured.positive_px),
            self._last.width_px + alpha * (measured.width_px - self._last.width_px),
            measured.confidence,
            measured.timestamp_ns,
            True,
            measured.source,
            (
                None
                if measured.corners_px is None or self._last.corners_px is None
                else tuple(
                    blend(old, new)
                    for old, new in zip(
                        self._last.corners_px, measured.corners_px
                    )
                )
            ),
        )


class WhiteTubePoseEstimator(RailPoseEstimator):
    """Compatibility wrapper used by old calibration datasets and tests."""

    def __init__(self, config: TubePoseConfig, mapping: MappingConfig) -> None:
        super().__init__(replace(config, enabled=True, method="white_contour"), mapping)


class TubeRectifier:
    """Warp only a narrow tube strip, never the complete camera frame."""

    def __init__(self, config: TubePoseConfig, mapping: MappingConfig) -> None:
        axis_length = _distance(
            mapping.negative_point_px, mapping.positive_point_px
        )
        self.margin = float(config.corridor_margin_px)
        self.width = int(math.ceil(axis_length + 2.0 * self.margin))
        self.height = int(config.rectified_height)
        self.negative_px = (self.margin, self.height * 0.5)
        self.positive_px = (self.margin + axis_length, self.height * 0.5)
        self.rail_half_height = max(4.0, config.expected_width_px * 0.5)
        self.mapping = MappingConfig(
            negative_point_px=self.negative_px,
            positive_point_px=self.positive_px,
            negative_position_m=mapping.negative_position_m,
            positive_position_m=mapping.positive_position_m,
        )

    def matrices(self, pose: TubePose) -> tuple[np.ndarray, np.ndarray]:
        if pose.corners_px is not None:
            source = np.asarray(pose.corners_px, dtype=np.float32)
        else:
            dx, dy = pose.axis
            length = max(1e-6, pose.length_px)
            normal = np.array([-dy / length, dx / length], dtype=np.float32)
            half = max(4.0, pose.width_px * 0.5)
            source = np.array(
                [
                    (
                        pose.negative_px[0] - normal[0] * half,
                        pose.negative_px[1] - normal[1] * half,
                    ),
                    (
                        pose.positive_px[0] - normal[0] * half,
                        pose.positive_px[1] - normal[1] * half,
                    ),
                    (
                        pose.positive_px[0] + normal[0] * half,
                        pose.positive_px[1] + normal[1] * half,
                    ),
                    (
                        pose.negative_px[0] + normal[0] * half,
                        pose.negative_px[1] + normal[1] * half,
                    ),
                ],
                dtype=np.float32,
            )
        target = np.array(
            [
                (
                    self.negative_px[0],
                    self.negative_px[1] - self.rail_half_height,
                ),
                (
                    self.positive_px[0],
                    self.positive_px[1] - self.rail_half_height,
                ),
                (
                    self.positive_px[0],
                    self.positive_px[1] + self.rail_half_height,
                ),
                (
                    self.negative_px[0],
                    self.negative_px[1] + self.rail_half_height,
                ),
            ],
            dtype=np.float32,
        )
        forward = cv2.getPerspectiveTransform(source, target)
        inverse = np.linalg.inv(forward)
        return forward, inverse

    def rectify(self, gray: np.ndarray, pose: TubePose) -> tuple[np.ndarray, np.ndarray]:
        forward, inverse = self.matrices(pose)
        strip = cv2.warpPerspective(
            gray,
            forward,
            (self.width, self.height),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REPLICATE,
        )
        return strip, inverse

    @staticmethod
    def transform_point(matrix: np.ndarray, point: Point) -> Point:
        x, y = point
        if matrix.shape == (2, 3):
            return (
                float(matrix[0, 0] * x + matrix[0, 1] * y + matrix[0, 2]),
                float(matrix[1, 0] * x + matrix[1, 1] * y + matrix[1, 2]),
            )
        denominator = float(
            matrix[2, 0] * x + matrix[2, 1] * y + matrix[2, 2]
        )
        if abs(denominator) < 1e-9:
            raise ValueError("轨道透视矩阵把点映射到了无穷远")
        return (
            float(
                (matrix[0, 0] * x + matrix[0, 1] * y + matrix[0, 2])
                / denominator
            ),
            float(
                (matrix[1, 0] * x + matrix[1, 1] * y + matrix[1, 2])
                / denominator
            ),
        )
