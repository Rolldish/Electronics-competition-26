"""Map the fixed 25 cm rail axis to the competition coordinate system."""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass

from ..common.config import MappingConfig


_CURRENT_FIVE_POINT_FRACTIONS = (
    0.096111,
    0.274281,
    0.461220,
    0.670166,
    0.888223,
)
_CURRENT_FIVE_POINT_POSITIONS_M = (
    -0.100,
    -0.050,
    0.000,
    0.050,
    0.100,
)


@dataclass(frozen=True)
class AxisFractionMapper:
    """以线性坐标为主，并可叠加五点静态位置残差修正。"""

    negative_position_m: float
    positive_position_m: float
    correction_enabled: bool
    correction_axis_fractions: tuple[float, ...]
    correction_positions_m: tuple[float, ...]

    @classmethod
    def from_config(cls, config: MappingConfig) -> "AxisFractionMapper":
        fractions = tuple(
            getattr(
                config,
                "position_correction_axis_fractions",
                _CURRENT_FIVE_POINT_FRACTIONS,
            )
        )
        positions = tuple(
            getattr(
                config,
                "position_correction_positions_m",
                _CURRENT_FIVE_POINT_POSITIONS_M,
            )
        )
        if len(fractions) != 5 or len(positions) != 5:
            raise ValueError("五点位置修正必须恰好包含5个点")
        if not all(0.0 < value < 1.0 for value in fractions):
            raise ValueError("五点位置修正比例必须位于0到1之间")
        if not all(left < right for left, right in zip(fractions, fractions[1:])):
            raise ValueError("五点位置修正比例必须严格递增")
        if not all(left < right for left, right in zip(positions, positions[1:])):
            raise ValueError("五点实物坐标必须严格递增")
        return cls(
            config.negative_position_m,
            config.positive_position_m,
            getattr(config, "position_correction_enabled", True),
            fractions,
            positions,
        )

    @property
    def span_m(self) -> float:
        return self.positive_position_m - self.negative_position_m

    def position_m(self, fraction: float) -> float:
        fraction = float(fraction)
        linear_position = self.negative_position_m + fraction * self.span_m
        if not self.correction_enabled or fraction <= 0.0 or fraction >= 1.0:
            return linear_position

        anchors = (0.0, *self.correction_axis_fractions, 1.0)
        residuals = (
            0.0,
            *(
                position
                - (self.negative_position_m + anchor * self.span_m)
                for anchor, position in zip(
                    self.correction_axis_fractions,
                    self.correction_positions_m,
                )
            ),
            0.0,
        )
        left_index = min(len(anchors) - 2, bisect_right(anchors, fraction) - 1)
        left_fraction = anchors[left_index]
        right_fraction = anchors[left_index + 1]
        interpolation = (fraction - left_fraction) / (
            right_fraction - left_fraction
        )
        correction = residuals[left_index] + interpolation * (
            residuals[left_index + 1] - residuals[left_index]
        )
        return linear_position + correction

    def velocity_mps(self, fraction: float, fraction_per_s: float) -> float:
        # 本轮标定只修正位置；速度继续使用已验证的线性比例。
        del fraction
        return float(fraction_per_s) * self.span_m
