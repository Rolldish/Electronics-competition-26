"""Create the one competition runtime profile from the merged configuration."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ..common.config import AppConfig, CameraConfig


LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class RuntimeVisionProfile:
    vision_config: AppConfig
    camera_config: CameraConfig
    profile_id: str
    mode: str = "runtime_adaptive"

    @property
    def runtime_geometry_allowed(self) -> bool:
        return True


def resolve_runtime_vision_profile(config: AppConfig) -> RuntimeVisionProfile:
    """Return the already-merged competition profile without a second loader."""
    camera = config.camera
    LOG.info(
        "competition profile: runtime 25 cm linear mapping; "
        "camera source=%s exposure=%d gain=%d white_balance=%d",
        config.camera_controls_source,
        camera.exposure,
        camera.gain,
        camera.white_balance_temperature,
    )
    return RuntimeVisionProfile(
        vision_config=config,
        camera_config=camera,
        profile_id="RUNTIME-ADAPTIVE-25CM+CAMERA-CONTROLS+BACKGROUND",
    )
