"""One-dimensional steel-ball acquisition and tracking along the rail axis."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum
from statistics import median
from typing import TYPE_CHECKING

from ..common.config import TrackerConfig

if TYPE_CHECKING:
    from .rail_context_detector import RailBallCandidate


class AxisTrackState(str, Enum):
    SEARCH = "SEARCH"
    ACQUIRE = "ACQUIRE"
    TRACK = "TRACK"
    PREDICT = "PREDICT"


@dataclass(frozen=True)
class AxisTrackEstimate:
    state: AxisTrackState
    axis_fraction: float
    velocity_fraction_s: float
    confidence: float
    measurement_valid: bool
    track_valid: bool
    predicted: bool
    acquisition_frames: int
    acquisition_required: int
    missed_frames: int
    jump_quarantined: bool
    selected: "RailBallCandidate | None"

    @property
    def control_valid(self) -> bool:
        """Only a confirmed track with a current measurement may drive control."""
        return self.track_valid and self.measurement_valid


class AxisBallTracker:
    """Track only the physically meaningful coordinate along the rail.

    Candidate generation may inspect the full rail every frame, but an
    unrelated high-score candidate cannot take over an established track
    unless it lies inside the predicted one-dimensional motion gate.
    """

    _MAX_SPEED_FRACTION_S = 4.0

    def __init__(
        self,
        config: TrackerConfig,
        *,
        max_track_jump_px: float = 80.0,
    ) -> None:
        self.config = config
        self.max_track_jump_px = max_track_jump_px
        self.reset()

    def reset(self) -> None:
        self._state = AxisTrackState.SEARCH
        self._axis_fraction = 0.0
        self._velocity_fraction_s = 0.0
        self._confidence = 0.0
        self._radius_px = 0.0
        self._last_timestamp_ns: int | None = None
        self._last_measurement_ns: int | None = None
        self._missed_frames = 0
        self._pending: "RailBallCandidate | None" = None
        self._pending_timestamp_ns: int | None = None
        self._pending_velocity = 0.0
        self._acquisition_frames = 0
        self._measurement_history: deque[float] = deque(
            maxlen=self.config.measurement_median_window
        )
        self._jump_candidate: "RailBallCandidate | None" = None
        self._jump_timestamp_ns: int | None = None
        self._last_raw_fraction: float | None = None
        self._last_raw_timestamp_ns: int | None = None
        self._last_raw_velocity = 0.0

    def update(
        self,
        candidates: tuple["RailBallCandidate", ...],
        timestamp_ns: int,
        rail_length_px: float,
    ) -> AxisTrackEstimate:
        usable = tuple(candidate for candidate in candidates if candidate.accepted)
        if self._state in {AxisTrackState.SEARCH, AxisTrackState.ACQUIRE}:
            return self._acquire(usable, timestamp_ns, rail_length_px)
        return self._track(usable, timestamp_ns, rail_length_px)

    def _acquire(
        self,
        candidates: tuple["RailBallCandidate", ...],
        timestamp_ns: int,
        rail_length_px: float,
    ) -> AxisTrackEstimate:
        if not candidates:
            self._clear_pending()
            return self._estimate(None, measurement_valid=False)

        maximum_jump = max(
            0.025,
            self.config.acquire_max_jump_px / max(rail_length_px, 1.0),
        )
        selected: "RailBallCandidate | None" = None
        if self._pending is not None:
            nearby = [
                candidate
                for candidate in candidates
                if abs(candidate.axis_fraction - self._pending.axis_fraction)
                <= maximum_jump
                and self._radius_consistent(
                    candidate.radius_px,
                    self._pending.radius_px,
                )
            ]
            if nearby:
                selected = min(
                    nearby,
                    key=lambda candidate: (
                        abs(candidate.axis_fraction - self._pending.axis_fraction)
                        - 0.08 * candidate.score
                    ),
                )
        if selected is None:
            selected = max(candidates, key=lambda candidate: candidate.score)
            self._measurement_history.clear()
            measured_fraction = self._filtered_fraction(
                selected.axis_fraction
            )
            self._pending = selected
            self._pending_timestamp_ns = timestamp_ns
            self._pending_velocity = 0.0
            self._acquisition_frames = 1
            self._state = AxisTrackState.ACQUIRE
            if self.config.acquire_confirm_frames <= 1:
                self._state = AxisTrackState.TRACK
                self._axis_fraction = measured_fraction
                self._velocity_fraction_s = 0.0
                self._confidence = selected.score
                self._radius_px = selected.radius_px
                self._last_timestamp_ns = timestamp_ns
                self._last_measurement_ns = timestamp_ns
                self._missed_frames = 0
                self._record_raw_measurement(
                    selected.axis_fraction,
                    timestamp_ns,
                )
            return self._estimate(selected, measurement_valid=True)

        assert self._pending_timestamp_ns is not None
        elapsed_s = max(
            1e-3,
            (timestamp_ns - self._pending_timestamp_ns) * 1e-9,
        )
        instantaneous_velocity = (
            selected.axis_fraction - self._pending.axis_fraction
        ) / elapsed_s
        self._pending_velocity = (
            0.65 * self._pending_velocity + 0.35 * instantaneous_velocity
        )
        self._pending_velocity = float(
            max(
                -self._MAX_SPEED_FRACTION_S,
                min(self._MAX_SPEED_FRACTION_S, self._pending_velocity),
            )
        )
        self._pending = selected
        measured_fraction = self._filtered_fraction(selected.axis_fraction)
        self._pending_timestamp_ns = timestamp_ns
        self._acquisition_frames += 1
        self._state = AxisTrackState.ACQUIRE
        if self._acquisition_frames < self.config.acquire_confirm_frames:
            return self._estimate(selected, measurement_valid=True)

        self._state = AxisTrackState.TRACK
        self._axis_fraction = measured_fraction
        self._velocity_fraction_s = self._pending_velocity
        self._confidence = selected.score
        self._radius_px = selected.radius_px
        self._last_timestamp_ns = timestamp_ns
        self._last_measurement_ns = timestamp_ns
        self._missed_frames = 0
        self._record_raw_measurement(
            selected.axis_fraction,
            timestamp_ns,
        )
        return self._estimate(selected, measurement_valid=True)

    def _track(
        self,
        candidates: tuple["RailBallCandidate", ...],
        timestamp_ns: int,
        rail_length_px: float,
    ) -> AxisTrackEstimate:
        assert self._last_timestamp_ns is not None
        elapsed_s = float(
            max(
                1.0 / 240.0,
                min(0.10, (timestamp_ns - self._last_timestamp_ns) * 1e-9),
            )
        )
        predicted = self._axis_fraction + self._velocity_fraction_s * elapsed_s
        maximum_jump = min(
            self.max_track_jump_px / max(rail_length_px, 1.0),
            0.028
            + self._MAX_SPEED_FRACTION_S * elapsed_s
            + 0.012 * self._missed_frames,
        )
        nearby = [
            candidate
            for candidate in candidates
            if abs(candidate.axis_fraction - predicted) <= maximum_jump
            and self._radius_consistent(candidate.radius_px, self._radius_px)
        ]
        selected = (
            min(
                nearby,
                key=lambda candidate: (
                    abs(candidate.axis_fraction - predicted)
                    / max(maximum_jump, 1e-6)
                    + 0.30 * (1.0 - candidate.score)
                    + 0.12
                    * abs(candidate.radius_px - self._radius_px)
                    / max(self._radius_px, 1.0)
                ),
            )
            if nearby
            else None
        )

        if selected is not None and self._quarantine_large_innovation(
            selected,
            predicted,
            timestamp_ns,
            rail_length_px,
        ):
            selected = None

        self._last_timestamp_ns = timestamp_ns
        if selected is not None:
            measured_fraction = self._filtered_fraction(
                selected.axis_fraction
            )
            innovation = measured_fraction - predicted
            quality = max(0.0, min(1.0, selected.score))
            alpha = self.config.alpha_min + (
                self.config.alpha_max - self.config.alpha_min
            ) * quality
            beta = self.config.beta_min + (
                self.config.beta_max - self.config.beta_min
            ) * quality
            self._axis_fraction = predicted + alpha * innovation
            self._velocity_fraction_s += beta * innovation / elapsed_s
            self._velocity_fraction_s = float(
                max(
                    -self._MAX_SPEED_FRACTION_S,
                    min(self._MAX_SPEED_FRACTION_S, self._velocity_fraction_s),
                )
            )
            self._confidence = 0.60 * self._confidence + 0.40 * selected.score
            self._radius_px = 0.75 * self._radius_px + 0.25 * selected.radius_px
            self._last_measurement_ns = timestamp_ns
            self._missed_frames = 0
            self._state = AxisTrackState.TRACK
            self._record_raw_measurement(
                selected.axis_fraction,
                timestamp_ns,
            )
            return self._estimate(selected, measurement_valid=True)

        self._axis_fraction = predicted
        self._confidence *= self.config.confidence_decay
        self._missed_frames += 1
        assert self._last_measurement_ns is not None
        missing_s = (timestamp_ns - self._last_measurement_ns) * 1e-9
        if (
            self._missed_frames <= self.config.max_predict_frames
            and missing_s <= self.config.max_predict_s
            and -0.08 <= self._axis_fraction <= 1.08
        ):
            self._state = AxisTrackState.PREDICT
            return self._estimate(None, measurement_valid=False)

        self.reset()
        return self._estimate(None, measurement_valid=False)

    def _radius_consistent(self, current: float, reference: float) -> bool:
        return (
            abs(current - reference) / max(reference, 1.0)
            <= self.config.acquire_radius_tolerance_ratio
        )

    def _quarantine_large_innovation(
        self,
        candidate: "RailBallCandidate",
        predicted: float,
        timestamp_ns: int,
        rail_length_px: float,
    ) -> bool:
        """Require a second real frame before accepting a suspicious jump."""
        threshold = self.config.large_innovation_px / max(
            rail_length_px,
            1.0,
        )
        innovation = abs(candidate.axis_fraction - predicted)
        if innovation <= threshold:
            self._clear_jump_candidate()
            return False

        if (
            self._last_raw_fraction is not None
            and self._last_raw_timestamp_ns is not None
        ):
            raw_age_s = (timestamp_ns - self._last_raw_timestamp_ns) * 1e-9
            expected_raw = (
                self._last_raw_fraction
                + self._last_raw_velocity * max(0.0, raw_age_s)
            )
            continuation_tolerance = max(0.012, threshold * 0.50)
            if (
                0.0 < raw_age_s <= self.config.large_innovation_max_age_s
                and abs(candidate.axis_fraction - expected_raw)
                <= continuation_tolerance
            ):
                # A steady fast trajectory can outrun the deliberately smooth
                # alpha-beta state. Do not mistake that consistent raw motion
                # for a reflection-induced position jump.
                self._clear_jump_candidate()
                return False

        if self._jump_candidate is not None and self._jump_timestamp_ns is not None:
            age_s = (timestamp_ns - self._jump_timestamp_ns) * 1e-9
            consistency = (
                self.config.large_innovation_consistency_px
                / max(rail_length_px, 1.0)
                + abs(self._velocity_fraction_s) * max(0.0, age_s)
            )
            if (
                0.0 < age_s <= self.config.large_innovation_max_age_s
                and abs(
                    candidate.axis_fraction
                    - self._jump_candidate.axis_fraction
                )
                <= consistency
                and self._radius_consistent(
                    candidate.radius_px,
                    self._jump_candidate.radius_px,
                )
            ):
                # Preserve the first quarantined measurement in the median
                # window now that a second camera frame confirmed it. Without
                # this, the old three-frame history would keep the filtered
                # position behind and quarantine the same real motion again.
                self._measurement_history.append(
                    float(self._jump_candidate.axis_fraction)
                )
                self._clear_jump_candidate()
                return False

        self._jump_candidate = candidate
        self._jump_timestamp_ns = timestamp_ns
        return True

    def _clear_jump_candidate(self) -> None:
        self._jump_candidate = None
        self._jump_timestamp_ns = None

    def _record_raw_measurement(
        self,
        axis_fraction: float,
        timestamp_ns: int,
    ) -> None:
        if (
            self._last_raw_fraction is not None
            and self._last_raw_timestamp_ns is not None
        ):
            elapsed_s = (timestamp_ns - self._last_raw_timestamp_ns) * 1e-9
            if elapsed_s > 0.0:
                instantaneous = (
                    float(axis_fraction) - self._last_raw_fraction
                ) / elapsed_s
                instantaneous = max(
                    -self._MAX_SPEED_FRACTION_S,
                    min(self._MAX_SPEED_FRACTION_S, instantaneous),
                )
                self._last_raw_velocity = (
                    0.50 * self._last_raw_velocity
                    + 0.50 * instantaneous
                )
        self._last_raw_fraction = float(axis_fraction)
        self._last_raw_timestamp_ns = timestamp_ns

    def _filtered_fraction(self, value: float) -> float:
        """Reject an isolated reflected candidate with a tiny history window."""
        self._measurement_history.append(float(value))
        return float(median(self._measurement_history))

    def _clear_pending(self) -> None:
        self._pending = None
        self._pending_timestamp_ns = None
        self._pending_velocity = 0.0
        self._acquisition_frames = 0
        self._state = AxisTrackState.SEARCH

    def _estimate(
        self,
        selected: "RailBallCandidate | None",
        *,
        measurement_valid: bool,
    ) -> AxisTrackEstimate:
        track_valid = self._state in {
            AxisTrackState.TRACK,
            AxisTrackState.PREDICT,
        }
        return AxisTrackEstimate(
            state=self._state,
            axis_fraction=self._axis_fraction,
            velocity_fraction_s=self._velocity_fraction_s,
            confidence=self._confidence,
            measurement_valid=measurement_valid,
            track_valid=track_valid,
            predicted=self._state is AxisTrackState.PREDICT,
            acquisition_frames=self._acquisition_frames,
            acquisition_required=self.config.acquire_confirm_frames,
            missed_frames=self._missed_frames,
            jump_quarantined=self._jump_candidate is not None,
            selected=selected,
        )
