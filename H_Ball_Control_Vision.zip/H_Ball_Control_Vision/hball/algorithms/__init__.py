"""Steel-ball detection, tube geometry, mapping, and tracking algorithms."""
