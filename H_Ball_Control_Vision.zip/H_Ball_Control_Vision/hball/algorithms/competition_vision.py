"""Competition rail/ball vision built from the validated raw-BGR prototype."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, replace

import numpy as np

from ..common.config import AppConfig
from .axis_tracker import AxisBallTracker, AxisTrackEstimate
from .mapping import AxisFractionMapper
from .rail_context_detector import RailContextBallDetector, RailContextResult
from .tube_pose import RailPoseEstimator, TubePose


@dataclass(frozen=True)
class CompetitionVisionFrame:
    result: RailContextResult | None
    estimate: AxisTrackEstimate
    pose: TubePose | None
    pose_valid: bool
    background_ready: bool
    background_failed: bool
    background_frames: int
    background_required: int
    background_attempts: int
    background_max_attempts: int
    background_retry_count: int
    background_retry_limit: int
    x_m: float
    v_mps: float
    x_px: float
    y_px: float
    radius_px: float
    axis_x_px: float
    axis_v_px_s: float
    processing_ms: float


class CompetitionRailVision:
    """Runtime background registration, rail localization and 1-D tracking.

    Startup background samples live only in memory.  Until all samples are
    collected successfully, every returned estimate is invalid and therefore
    cannot enable C-board ball control.
    """

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.pose_estimator = RailPoseEstimator(
            config.tube_pose,
            config.mapping,
        )
        self.detector = RailContextBallDetector(
            config.detector,
            config.tube_pose,
            config.mapping,
            config.target.ball_diameter_m,
        )
        self.tracker = AxisBallTracker(
            config.tracker,
            max_track_jump_px=config.detector.max_track_jump_px,
        )
        self.mapper = AxisFractionMapper.from_config(config.mapping)
        self.background_required = config.runtime.startup_background_frames
        self.maximum_background_attempts = (
            config.runtime.startup_background_max_attempts
        )
        self.background_retry_limit = (
            config.runtime.startup_background_retry_limit
        )
        self._background_samples: list[np.ndarray] = []
        self._background_poses: list[TubePose] = []
        self._background_collected = 0
        self._background_attempts = 0
        self._background_failed = False
        self._background_retry_count = 0
        self._reference_pose: TubePose | None = None

    @property
    def background_ready(self) -> bool:
        return self.detector.background_ready

    @property
    def background_failed(self) -> bool:
        return self._background_failed

    @property
    def background_frames(self) -> int:
        return self._background_collected

    @property
    def reference_pose(self) -> TubePose | None:
        return self._reference_pose

    @property
    def background_attempts(self) -> int:
        return self._background_attempts

    @property
    def background_retry_count(self) -> int:
        return self._background_retry_count

    @property
    def pose_diagnostics(self) -> dict[str, object]:
        return dict(self.pose_estimator.last_diagnostics)

    def reset(self) -> None:
        """Reset only ball tracking; keep the validated no-ball background."""
        self.tracker.reset()

    def restart_background(self) -> None:
        """Explicitly discard the in-memory reference and sample an empty rail."""
        self.pose_estimator.reset()
        self.tracker.reset()
        self.detector.clear_background()
        self._background_samples.clear()
        self._background_poses.clear()
        self._background_collected = 0
        self._background_attempts = 0
        self._background_failed = False
        self._background_retry_count = 0
        self._reference_pose = None

    def process(
        self,
        frame: np.ndarray,
        timestamp_ns: int,
    ) -> CompetitionVisionFrame:
        started = time.perf_counter()
        if not self.background_ready:
            return self._sample_background(frame, timestamp_ns, started)

        if (
            self.config.tube_pose.lock_after_background
            and self._reference_pose is not None
        ):
            pose = replace(
                self._reference_pose,
                timestamp_ns=timestamp_ns,
                measured=False,
                source="BACKGROUND_LOCKED",
            )
            self.pose_estimator.last_diagnostics = {
                "result": "BACKGROUND_LOCKED",
                "reason": "FIXED_CAMERA_RAIL_GEOMETRY",
                "confidence": round(pose.confidence, 4),
                "length_px": round(pose.length_px, 2),
                "width_px": round(pose.width_px, 2),
            }
        else:
            pose = self.pose_estimator.update(frame, timestamp_ns)
        pose_valid = pose is not None
        result = None if pose is None else self.detector.detect(frame, pose)
        candidates = () if result is None else result.accepted
        rail_length_px = (
            self._fallback_rail_length_px()
            if pose is None
            else pose.length_px
        )
        estimate = self.tracker.update(
            candidates,
            timestamp_ns,
            rail_length_px,
        )
        return self._frame(
            result=result,
            estimate=estimate,
            pose=pose,
            pose_valid=pose_valid,
            started=started,
        )

    def _sample_background(
        self,
        frame: np.ndarray,
        timestamp_ns: int,
        started: float,
    ) -> CompetitionVisionFrame:
        pose: TubePose | None = None
        if not self._background_failed:
            self._background_attempts += 1
            pose = self.pose_estimator.update(
                frame,
                timestamp_ns,
                force=True,
            )
            if pose is not None:
                self._background_samples.append(
                    self.detector.reference_sample(frame, pose)
                )
                self._background_poses.append(pose)
                self._background_collected += 1
            if self._background_collected >= self.background_required:
                self.detector.set_background(self._background_samples)
                self._reference_pose = self._median_pose(
                    self._background_poses
                )
                self.pose_estimator.seed(
                    replace(
                        self._reference_pose,
                        timestamp_ns=timestamp_ns,
                        measured=False,
                        source="BACKGROUND_SEED",
                    )
                )
                # The detector owns the median image now. The raw startup
                # samples are no longer useful and would otherwise keep
                # several megabytes resident for the whole competition.
                self._background_samples.clear()
                self._background_poses.clear()
            elif self._background_attempts >= self.maximum_background_attempts:
                if self._background_retry_count < self.background_retry_limit:
                    # A moving shadow or a brief pose loss must not force an
                    # operator restart.  Discard the incomplete window and
                    # retry from a clean set; never weaken the pose gate and
                    # never publish a partially registered background.
                    self._background_retry_count += 1
                    self._background_samples.clear()
                    self._background_poses.clear()
                    self._background_collected = 0
                    self._background_attempts = 0
                    self.pose_estimator.reset()
                else:
                    self._background_failed = True

        estimate = self.tracker.update(
            (),
            timestamp_ns,
            (
                self._fallback_rail_length_px()
                if pose is None
                else pose.length_px
            ),
        )
        return self._frame(
            result=None,
            estimate=estimate,
            pose=pose,
            pose_valid=False,
            started=started,
        )

    def _frame(
        self,
        *,
        result: RailContextResult | None,
        estimate: AxisTrackEstimate,
        pose: TubePose | None,
        pose_valid: bool,
        started: float,
    ) -> CompetitionVisionFrame:
        if estimate.track_valid:
            x_m = self.mapper.position_m(estimate.axis_fraction)
            v_mps = self.mapper.velocity_mps(
                estimate.axis_fraction,
                estimate.velocity_fraction_s,
            )
            display_pose = pose or self._reference_pose
            if display_pose is not None:
                x_px, y_px = display_pose.point_at_fraction(
                    estimate.axis_fraction
                )
                axis_x_px = estimate.axis_fraction * display_pose.length_px
                axis_v_px_s = (
                    estimate.velocity_fraction_s * display_pose.length_px
                )
            else:
                x_px = y_px = axis_x_px = axis_v_px_s = 0.0
        else:
            x_m = v_mps = 0.0
            x_px = y_px = axis_x_px = axis_v_px_s = 0.0
        radius_px = (
            0.0
            if estimate.selected is None
            else estimate.selected.radius_px
        )
        return CompetitionVisionFrame(
            result=result,
            estimate=estimate,
            pose=pose,
            pose_valid=pose_valid,
            background_ready=self.background_ready,
            background_failed=self._background_failed,
            background_frames=self._background_collected,
            background_required=self.background_required,
            background_attempts=self._background_attempts,
            background_max_attempts=self.maximum_background_attempts,
            background_retry_count=self._background_retry_count,
            background_retry_limit=self.background_retry_limit,
            x_m=float(x_m),
            v_mps=float(v_mps),
            x_px=float(x_px),
            y_px=float(y_px),
            radius_px=float(radius_px),
            axis_x_px=float(axis_x_px),
            axis_v_px_s=float(axis_v_px_s),
            processing_ms=(time.perf_counter() - started) * 1000.0,
        )

    def _fallback_rail_length_px(self) -> float:
        if self._reference_pose is not None:
            return self._reference_pose.length_px
        delta_x = (
            self.config.mapping.positive_point_px[0]
            - self.config.mapping.negative_point_px[0]
        )
        delta_y = (
            self.config.mapping.positive_point_px[1]
            - self.config.mapping.negative_point_px[1]
        )
        return max(1.0, math.hypot(delta_x, delta_y))

    @staticmethod
    def _median_pose(poses: list[TubePose]) -> TubePose:
        if not poses:
            raise ValueError("cannot build a reference pose without samples")

        def median_point(
            values: list[tuple[float, float]],
        ) -> tuple[float, float]:
            array = np.asarray(values, dtype=np.float64)
            point = np.median(array, axis=0)
            return float(point[0]), float(point[1])

        corners = None
        valid_corners = [
            pose.corners_px
            for pose in poses
            if pose.corners_px is not None
        ]
        if len(valid_corners) >= max(5, len(poses) // 2):
            median_corners = np.median(
                np.asarray(valid_corners, dtype=np.float64),
                axis=0,
            )
            corners = tuple(
                (float(point[0]), float(point[1]))
                for point in median_corners
            )
        return TubePose(
            negative_px=median_point(
                [pose.negative_px for pose in poses]
            ),
            positive_px=median_point(
                [pose.positive_px for pose in poses]
            ),
            width_px=float(np.median([pose.width_px for pose in poses])),
            confidence=float(
                np.median([pose.confidence for pose in poses])
            ),
            timestamp_ns=max(pose.timestamp_ns for pose in poses),
            measured=False,
            source="BACKGROUND_REFERENCE",
            corners_px=corners,
        )
