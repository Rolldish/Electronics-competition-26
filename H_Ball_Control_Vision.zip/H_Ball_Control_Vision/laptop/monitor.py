"""Laptop-only live display, automatic recording, and independent replay."""

from __future__ import annotations

import argparse
import csv
import json
import logging
import shutil
import socket
import subprocess
import sys
import threading
import time
import tomllib
import urllib.request
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import cv2
import numpy as np

from hball.drivers.mjpeg import JpegByteStreamParser
from hball.drivers.protocol import (
    ControlFlags,
    Flags,
    Telemetry,
    decode_packet,
)


LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class MonitorConfig:
    stream_url: str
    telemetry_bind: str
    telemetry_port: int
    recordings_dir: Path
    record_fps: float
    fullscreen: bool
    auto_record: bool
    preroll_s: float
    postroll_s: float
    min_free_warn_gb: float
    min_free_record_gb: float
    task_record_s: dict[int, float]
    window_title: str


@dataclass(frozen=True)
class FrameSample:
    stream_sequence: int
    frame: np.ndarray
    telemetry: Telemetry | None
    telemetry_age_ms: float
    wall_time_iso: str


def load_monitor_config(path: str | Path) -> MonitorConfig:
    config_path = Path(path).expanduser().resolve()
    with config_path.open("rb") as stream:
        data = tomllib.load(stream)["monitor"]
    recordings = Path(data["recordings_dir"])
    if not recordings.is_absolute():
        recordings = (config_path.parent / recordings).resolve()
    task_record_s = {
        task_id: float(data[f"t{task_id}_record_s"])
        for task_id in range(2, 7)
    }
    config = MonitorConfig(
        stream_url=str(data["stream_url"]),
        telemetry_bind=str(data["telemetry_bind"]),
        telemetry_port=int(data["telemetry_port"]),
        recordings_dir=recordings,
        record_fps=float(data["record_fps"]),
        fullscreen=bool(data["fullscreen"]),
        auto_record=bool(data["auto_record"]),
        preroll_s=float(data["preroll_s"]),
        postroll_s=float(data["postroll_s"]),
        min_free_warn_gb=float(data["min_free_warn_gb"]),
        min_free_record_gb=float(data["min_free_record_gb"]),
        task_record_s=task_record_s,
        window_title=str(data["window_title"]),
    )
    if not 1.0 <= config.record_fps <= 30.0:
        raise ValueError("monitor.record_fps 必须位于1-30")
    if config.preroll_s < 0.0 or config.postroll_s < 0.0:
        raise ValueError("预录和后录时间不能为负数")
    if not 0.0 < config.min_free_record_gb <= config.min_free_warn_gb:
        raise ValueError("磁盘停止录像门槛必须大于0且不高于警告门槛")
    if any(value <= 0.0 for value in config.task_record_s.values()):
        raise ValueError("T2-T6录像时间必须大于0")
    return config


class MjpegReceiver:
    """Reconnect in the background and expose only the newest original JPEG."""

    def __init__(self, url: str) -> None:
        self.url = url
        self._lock = threading.Lock()
        self._latest: tuple[int, bytes, int] | None = None
        self._state = "STARTING"
        self._sequence = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._loop,
            name="mjpeg-receiver",
            daemon=True,
        )
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                request = urllib.request.Request(
                    self.url,
                    headers={
                        "User-Agent": "HBallMonitor/1.0",
                        "Cache-Control": "no-cache",
                    },
                )
                with urllib.request.urlopen(request, timeout=5.0) as response:
                    parser = JpegByteStreamParser()
                    with self._lock:
                        self._state = "CONNECTED"
                    while not self._stop.is_set():
                        chunk = response.read(16384)
                        if not chunk:
                            raise ConnectionError("MJPEG stream ended")
                        for jpeg in parser.push(chunk):
                            self._sequence += 1
                            with self._lock:
                                self._latest = (
                                    self._sequence,
                                    jpeg,
                                    time.monotonic_ns(),
                                )
            except Exception as error:
                if self._stop.is_set():
                    break
                with self._lock:
                    self._state = f"RECONNECT: {error}"
                self._stop.wait(1.0)

    def latest(self) -> tuple[int, bytes, float] | None:
        with self._lock:
            value = self._latest
        if value is None:
            return None
        sequence, jpeg, received_ns = value
        age_ms = (time.monotonic_ns() - received_ns) * 1e-6
        return sequence, jpeg, age_ms

    @property
    def state(self) -> str:
        with self._lock:
            return self._state

    def close(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.5)
            self._thread = None


class TelemetryReceiver:
    def __init__(self, bind: str, port: int) -> None:
        self.bind = bind
        self.port = port
        self._lock = threading.Lock()
        self._latest: tuple[Telemetry, int] | None = None
        self._stop = threading.Event()
        self._socket: socket.socket | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._socket.bind((self.bind, self.port))
        self._socket.settimeout(0.5)
        self._thread = threading.Thread(
            target=self._loop,
            name="telemetry-udp",
            daemon=True,
        )
        self._thread.start()

    def _loop(self) -> None:
        assert self._socket is not None
        while not self._stop.is_set():
            try:
                data, _ = self._socket.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                message = decode_packet(data)
            except ValueError:
                continue
            with self._lock:
                self._latest = message, time.monotonic_ns()

    def latest(self) -> tuple[Telemetry | None, float]:
        with self._lock:
            value = self._latest
        if value is None:
            return None, float("inf")
        message, timestamp_ns = value
        return message, (time.monotonic_ns() - timestamp_ns) * 1e-6

    def close(self) -> None:
        self._stop.set()
        if self._socket is not None:
            self._socket.close()
            self._socket = None
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None


class SessionRecorder:
    """Write clean video plus sidecar telemetry on the laptop only."""

    def __init__(self, root: Path, fps: float) -> None:
        self.root = root
        self.fps = fps
        self.session_dir: Path | None = None
        self.video: cv2.VideoWriter | None = None
        self.csv_file = None
        self.csv_writer = None
        self.frame_count = 0
        self.started_wall = 0.0
        self.run_id = 0
        self.task_id = 0
        self.mode = "manual"

    @property
    def active(self) -> bool:
        return self.video is not None

    def start(
        self,
        frame: np.ndarray,
        telemetry: Telemetry | None,
        *,
        mode: str,
    ) -> Path:
        if self.active:
            assert self.session_dir is not None
            return self.session_dir
        self.root.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        task_id = 0 if telemetry is None else int(telemetry.task_id)
        run_id = 0 if telemetry is None else telemetry.run_id
        prefix = f"T{task_id}_run{run_id}_" if task_id else "manual_"
        self.session_dir = self.root / f"{prefix}{stamp}"
        suffix = 1
        while self.session_dir.exists():
            self.session_dir = self.root / f"{prefix}{stamp}_{suffix:02d}"
            suffix += 1
        self.session_dir.mkdir(parents=True)
        height, width = frame.shape[:2]
        self.video = cv2.VideoWriter(
            str(self.session_dir / "video_raw.avi"),
            cv2.VideoWriter_fourcc(*"MJPG"),
            self.fps,
            (width, height),
        )
        if not self.video.isOpened():
            self.video.release()
            self.video = None
            raise RuntimeError("无法创建笔记本端MJPG AVI录像")
        self.csv_file = (self.session_dir / "frames.csv").open(
            "w", newline="", encoding="utf-8"
        )
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(
            [
                "frame",
                "stream_sequence",
                "wall_time_iso",
                "udp_receive_age_ms",
                "measurement_age_ms",
                "sequence",
                "session_id",
                "capture_timestamp_ms",
                "capture_to_send_delay_us",
                "flags",
                "x_m",
                "v_mps",
                "confidence",
                "target_x_m",
                "task_id",
                "control_flags",
                "run_id",
            ]
        )
        self.frame_count = 0
        self.started_wall = time.time()
        self.run_id = run_id
        self.task_id = task_id
        self.mode = mode
        return self.session_dir

    def write(self, sample: FrameSample) -> None:
        if not self.active:
            return
        assert self.video is not None and self.csv_writer is not None
        self.video.write(sample.frame)
        self.frame_count += 1
        telemetry = sample.telemetry
        if telemetry is None:
            measurement_age = ""
            values = ("", "", "", "", "", "", "", "", "", "", "", "")
        else:
            measurement_age = (
                telemetry.capture_to_send_delay_us / 1000.0
                + sample.telemetry_age_ms
            )
            values = (
                telemetry.sequence,
                telemetry.session_id,
                telemetry.capture_timestamp_ms,
                telemetry.capture_to_send_delay_us,
                int(telemetry.flags),
                f"{telemetry.x_m:.6f}",
                f"{telemetry.v_mps:.6f}",
                f"{telemetry.confidence:.4f}",
                f"{telemetry.target_x_m:.6f}",
                int(telemetry.task_id),
                int(telemetry.control_flags),
                telemetry.run_id,
            )
        self.csv_writer.writerow(
            [
                self.frame_count,
                sample.stream_sequence,
                sample.wall_time_iso,
                (
                    ""
                    if not np.isfinite(sample.telemetry_age_ms)
                    else f"{sample.telemetry_age_ms:.2f}"
                ),
                "" if measurement_age == "" else f"{measurement_age:.2f}",
                *values,
            ]
        )
        if self.frame_count % 10 == 0 and self.csv_file is not None:
            self.csv_file.flush()

    def stop(self, reason: str = "manual") -> Path | None:
        if not self.active:
            return self.session_dir
        assert self.video is not None and self.session_dir is not None
        self.video.release()
        self.video = None
        if self.csv_file is not None:
            self.csv_file.close()
            self.csv_file = None
            self.csv_writer = None
        manifest = {
            "created_at": datetime.fromtimestamp(
                self.started_wall
            ).astimezone().isoformat(),
            "stopped_at": datetime.now().astimezone().isoformat(),
            "stop_reason": reason,
            "recording_mode": self.mode,
            "frames": self.frame_count,
            "nominal_fps": self.fps,
            "task_id": self.task_id,
            "run_id": self.run_id,
            "video": "video_raw.avi",
            "telemetry": "frames.csv",
            "video_has_overlay": False,
            "storage_location": "laptop",
        }
        (self.session_dir / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        path = self.session_dir
        self.session_dir = None
        return path


def _overlay(
    frame: np.ndarray,
    telemetry: Telemetry | None,
    age_ms: float,
    recording: bool,
    *,
    stream_state: str,
    warning: str = "",
) -> np.ndarray:
    display = frame.copy()
    panel = display.copy()
    cv2.rectangle(panel, (8, 8), (632, 128), (0, 0, 0), -1)
    display = cv2.addWeighted(panel, 0.58, display, 0.42, 0)
    if telemetry is None:
        lines = (
            f"STREAM {stream_state[:40]} / TELEMETRY NO DATA",
            "x=--  target=--  error=--",
            "v=--  confidence=--",
        )
        color = (0, 0, 255)
    else:
        measurement_age_ms = (
            telemetry.capture_to_send_delay_us / 1000.0 + age_ms
        )
        valid = (
            bool(telemetry.flags & Flags.BALL_VALID)
            and bool(telemetry.flags & Flags.CAMERA_CALIBRATED)
            and not bool(telemetry.flags & Flags.PROCESSING_DEGRADED)
            and measurement_age_ms <= 80.0
        )
        mode = "MEASURED" if telemetry.flags & Flags.BALL_VALID else "NO BALL"
        lines = (
            (
                f"{mode} T{int(telemetry.task_id)} run={telemetry.run_id} "
                f"seq={telemetry.sequence} age={measurement_age_ms:.0f}ms"
            ),
            (
                f"x={telemetry.x_m * 100:+.2f}cm  "
                f"target={telemetry.target_x_m * 100:+.2f}cm  "
                f"error={(telemetry.x_m - telemetry.target_x_m) * 100:+.2f}cm"
            ),
            (
                f"v={telemetry.v_mps * 100:+.1f}cm/s "
                f"conf={telemetry.confidence:.2f} "
                f"vision=0x{int(telemetry.flags):02X} "
                f"control=0x{int(telemetry.control_flags):02X}"
            ),
        )
        color = (0, 255, 0) if valid else (0, 180, 255)
    cv2.putText(
        display, lines[0], (20, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.58, color, 2
    )
    cv2.putText(
        display,
        lines[1],
        (20, 72),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.57,
        (245, 245, 245),
        1,
    )
    cv2.putText(
        display,
        lines[2],
        (20, 103),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.50,
        (225, 225, 225),
        1,
    )
    if warning:
        cv2.putText(
            display,
            warning[:65],
            (18, display.shape[0] - 16),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 0, 255),
            2,
        )
    if recording:
        cv2.circle(display, (display.shape[1] - 28, 28), 9, (0, 0, 255), -1)
        cv2.putText(
            display,
            "REC",
            (display.shape[1] - 82, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 0, 255),
            2,
        )
    return display


def _overlay_replay_row(frame: np.ndarray, row: dict[str, str]) -> np.ndarray:
    display = frame.copy()
    try:
        text = (
            f"T{row.get('task_id', '--')} run={row.get('run_id', '--')} "
            f"x={float(row['x_m']) * 100:+.2f}cm "
            f"target={float(row['target_x_m']) * 100:+.2f}cm "
            f"v={float(row['v_mps']) * 100:+.1f}cm/s"
        )
    except (KeyError, TypeError, ValueError):
        text = "NO TELEMETRY FOR THIS FRAME"
    panel = display.copy()
    cv2.rectangle(panel, (8, 8), (632, 52), (0, 0, 0), -1)
    display = cv2.addWeighted(panel, 0.58, display, 0.42, 0)
    cv2.putText(
        display,
        text,
        (18, 37),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (0, 255, 255),
        1,
    )
    return display


def _replay(path: Path, window_title: str) -> None:
    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise RuntimeError(f"无法回放 {path}")
    csv_path = path.with_name("frames.csv")
    rows: list[dict[str, str]] = []
    if csv_path.is_file():
        with csv_path.open("r", newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
    fps = float(capture.get(cv2.CAP_PROP_FPS)) or 10.0
    delay_ms = max(1, int(round(1000.0 / fps)))
    title = f"{window_title} - Replay"
    overlay_enabled = True
    index = 0
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            display = (
                _overlay_replay_row(frame, rows[index])
                if overlay_enabled and index < len(rows)
                else frame
            )
            cv2.imshow(title, display)
            key = cv2.waitKey(delay_ms) & 0xFF
            if key in (ord("q"), 27):
                break
            if key in (ord("o"), ord("O")):
                overlay_enabled = not overlay_enabled
            index += 1
    finally:
        capture.release()
        cv2.destroyAllWindows()


def _latest_video(root: Path) -> Path | None:
    candidates = sorted(
        root.glob("*/video_raw.avi"),
        key=lambda path: path.stat().st_mtime,
    )
    return candidates[-1] if candidates else None


def _free_gb(path: Path) -> float:
    path.mkdir(parents=True, exist_ok=True)
    return shutil.disk_usage(path).free / (1024.0**3)


def _launch_replay(path: Path, config_path: Path) -> None:
    subprocess.Popen(
        [
            sys.executable,
            str(Path(__file__).resolve()),
            "--config",
            str(config_path),
            "--replay",
            str(path),
        ],
        cwd=str(PROJECT_ROOT),
    )


def run(config: MonitorConfig, config_path: Path) -> None:
    stream = MjpegReceiver(config.stream_url)
    telemetry = TelemetryReceiver(config.telemetry_bind, config.telemetry_port)
    recorder = SessionRecorder(config.recordings_dir, config.record_fps)
    pre_roll: deque[FrameSample] = deque(
        maxlen=max(2, int(round(config.preroll_s * config.record_fps)) + 2)
    )
    stream.start()
    telemetry.start()
    cv2.namedWindow(config.window_title, cv2.WINDOW_NORMAL)
    if config.fullscreen:
        cv2.setWindowProperty(
            config.window_title,
            cv2.WND_PROP_FULLSCREEN,
            cv2.WINDOW_FULLSCREEN,
        )
    fullscreen = config.fullscreen
    last_stream_sequence = -1
    last_frame = np.zeros((480, 640, 3), dtype=np.uint8)
    auto_run: tuple[int, int] | None = None
    automatic_runs_seen: set[tuple[int, int]] = set()
    auto_stop_at = 0.0
    stop = False
    warning = ""
    last_disk_check = 0.0
    free_gb = float("inf")
    try:
        while not stop:
            now = time.monotonic()
            if now - last_disk_check >= 2.0:
                try:
                    free_gb = _free_gb(config.recordings_dir)
                    warning = (
                        f"LOW DISK {free_gb:.2f}GB: NEW RECORDING DISABLED"
                        if free_gb < config.min_free_record_gb
                        else (
                            f"LOW DISK {free_gb:.2f}GB"
                            if free_gb < config.min_free_warn_gb
                            else ""
                        )
                    )
                except OSError as error:
                    warning = f"DISK ERROR: {error}"
                    free_gb = 0.0
                last_disk_check = now

            newest = stream.latest()
            wrote_current = False
            if newest is not None and newest[0] != last_stream_sequence:
                sequence, jpeg, _ = newest
                frame = cv2.imdecode(
                    np.frombuffer(jpeg, np.uint8),
                    cv2.IMREAD_COLOR,
                )
                if frame is not None:
                    last_stream_sequence = sequence
                    last_frame = frame
                    message, age_ms = telemetry.latest()
                    sample = FrameSample(
                        stream_sequence=sequence,
                        frame=frame,
                        telemetry=message,
                        telemetry_age_ms=age_ms,
                        wall_time_iso=datetime.now().astimezone().isoformat(),
                    )
                    pre_roll.append(sample)
                    task_id = 0 if message is None else int(message.task_id)
                    run_active = bool(
                        message is not None
                        and task_id in config.task_record_s
                        and message.control_flags & ControlFlags.RUN_ACTIVE
                    )
                    current_run = (
                        None
                        if message is None
                        else (message.session_id, message.run_id)
                    )
                    if (
                        config.auto_record
                        and run_active
                        and current_run is not None
                        and current_run not in automatic_runs_seen
                    ):
                        if recorder.active:
                            path = recorder.stop("new_task_run")
                            LOG.info("recording stopped: %s", path)
                        if free_gb >= config.min_free_record_gb:
                            path = recorder.start(
                                frame,
                                message,
                                mode="automatic",
                            )
                            for buffered in pre_roll:
                                recorder.write(buffered)
                            wrote_current = True
                            auto_run = current_run
                            automatic_runs_seen.add(current_run)
                            auto_stop_at = (
                                now
                                + config.task_record_s[task_id]
                                + config.postroll_s
                            )
                            LOG.info(
                                "automatic T%d recording started with %.1fs pre-roll: %s",
                                task_id,
                                config.preroll_s,
                                path,
                            )
                    if recorder.active and not wrote_current:
                        recorder.write(sample)

            if recorder.active and auto_run is not None and now >= auto_stop_at:
                path = recorder.stop("configured_task_duration")
                LOG.info("automatic recording completed: %s", path)
                auto_run = None

            message, age_ms = telemetry.latest()
            display = _overlay(
                last_frame,
                message,
                age_ms,
                recorder.active,
                stream_state=stream.state,
                warning=warning,
            )
            cv2.imshow(config.window_title, display)
            key = cv2.waitKey(10) & 0xFF
            if key in (ord("q"), 27):
                stop = True
            elif key in (ord("r"), ord("R")):
                if recorder.active:
                    path = recorder.stop("manual_stop")
                    LOG.info("recording stopped: %s", path)
                    auto_run = None
                elif free_gb >= config.min_free_record_gb:
                    path = recorder.start(last_frame, message, mode="manual")
                    for buffered in pre_roll:
                        recorder.write(buffered)
                    LOG.info("manual recording started: %s", path)
            elif key in (ord("p"), ord("P")):
                path = _latest_video(config.recordings_dir)
                if path is not None:
                    _launch_replay(path, config_path)
            elif key in (ord("f"), ord("F")):
                fullscreen = not fullscreen
                cv2.setWindowProperty(
                    config.window_title,
                    cv2.WND_PROP_FULLSCREEN,
                    cv2.WINDOW_FULLSCREEN
                    if fullscreen
                    else cv2.WINDOW_NORMAL,
                )
    finally:
        recorder.stop("application_exit")
        stream.close()
        telemetry.close()
        cv2.destroyAllWindows()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="H题笔记本端：持续显示、自动录像、独立回放"
    )
    parser.add_argument(
        "--config",
        default=str(PROJECT_ROOT / "config" / "laptop.toml"),
    )
    parser.add_argument("--stream-url")
    parser.add_argument("--replay", type=Path)
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    config_path = Path(args.config).expanduser().resolve()
    config = load_monitor_config(config_path)
    if args.replay is not None:
        _replay(args.replay.expanduser().resolve(), config.window_title)
        return
    if args.stream_url:
        config = MonitorConfig(
            **{**config.__dict__, "stream_url": args.stream_url}
        )
    try:
        run(config, config_path)
    except KeyboardInterrupt:
        LOG.info("stopped by user")


if __name__ == "__main__":
    main()
