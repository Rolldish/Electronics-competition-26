"""Receive-only laptop monitor for the H-ball project."""

