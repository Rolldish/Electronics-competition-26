from __future__ import annotations

import argparse
import logging
import sys
import time
import tomllib
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import cv2
import numpy as np

from laptop.monitor import MjpegClient


LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class DebugClientConfig:
    stream_url: str
    recordings_dir: Path
    record_fps: float
    fullscreen: bool
    window_title: str


def load_debug_config(path: str | Path) -> DebugClientConfig:
    config_path = Path(path).expanduser().resolve()
    with config_path.open("rb") as stream:
        values = tomllib.load(stream)["debug_client"]
    recordings = Path(values.get("recordings_dir", "../debug_recordings"))
    if not recordings.is_absolute():
        recordings = (config_path.parent / recordings).resolve()
    return DebugClientConfig(
        stream_url=str(values["stream_url"]),
        recordings_dir=recordings,
        record_fps=float(values.get("record_fps", 10.0)),
        fullscreen=bool(values.get("fullscreen", False)),
        window_title=str(values.get("window_title", "H Ball Debug Client")),
    )


class DebugRecorder:
    def __init__(self, root: Path, fps: float) -> None:
        self.root = root
        self.fps = fps
        self.path: Path | None = None
        self.writer: cv2.VideoWriter | None = None

    @property
    def active(self) -> bool:
        return self.writer is not None

    def start(self, frame: np.ndarray) -> Path:
        if self.writer is not None and self.path is not None:
            return self.path
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / (
            datetime.now().strftime("debug_%Y%m%d_%H%M%S") + ".avi"
        )
        height, width = frame.shape[:2]
        self.writer = cv2.VideoWriter(
            str(self.path),
            cv2.VideoWriter_fourcc(*"MJPG"),
            self.fps,
            (width, height),
        )
        if not self.writer.isOpened():
            self.writer.release()
            self.writer = None
            raise RuntimeError(f"无法创建调试录像: {self.path}")
        return self.path

    def write(self, frame: np.ndarray) -> None:
        if self.writer is not None:
            self.writer.write(frame)

    def stop(self) -> Path | None:
        if self.writer is not None:
            self.writer.release()
            self.writer = None
        return self.path


def replay(path: Path, title: str) -> None:
    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise RuntimeError(f"无法打开调试录像: {path}")
    fps = float(capture.get(cv2.CAP_PROP_FPS)) or 10.0
    delay_ms = max(1, int(round(1000.0 / fps)))
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            cv2.imshow(title, frame)
            if cv2.waitKey(delay_ms) & 0xFF in (ord("q"), ord("Q"), 27):
                break
    finally:
        capture.release()
        cv2.destroyWindow(title)


def run(config: DebugClientConfig) -> None:
    recorder = DebugRecorder(config.recordings_dir, config.record_fps)
    cv2.namedWindow(config.window_title, cv2.WINDOW_NORMAL)
    fullscreen = config.fullscreen
    if fullscreen:
        cv2.setWindowProperty(
            config.window_title,
            cv2.WND_PROP_FULLSCREEN,
            cv2.WINDOW_FULLSCREEN,
        )
    stop = False
    try:
        while not stop:
            try:
                for jpeg in MjpegClient(config.stream_url).frames():
                    frame = cv2.imdecode(
                        np.frombuffer(jpeg, dtype=np.uint8),
                        cv2.IMREAD_COLOR,
                    )
                    if frame is None:
                        continue
                    recorder.write(frame)
                    cv2.imshow(config.window_title, frame)
                    key = cv2.waitKey(1) & 0xFF
                    if key in (ord("q"), ord("Q"), 27):
                        stop = True
                        break
                    if key in (ord("r"), ord("R")):
                        if recorder.active:
                            LOG.info("debug recording stopped: %s", recorder.stop())
                        else:
                            LOG.info("debug recording started: %s", recorder.start(frame))
                    elif key in (ord("s"), ord("S")):
                        config.recordings_dir.mkdir(parents=True, exist_ok=True)
                        path = config.recordings_dir / (
                            datetime.now().strftime("shot_%Y%m%d_%H%M%S_%f")
                            + ".jpg"
                        )
                        if cv2.imwrite(str(path), frame):
                            LOG.info("debug screenshot: %s", path)
                    elif key in (ord("f"), ord("F")):
                        fullscreen = not fullscreen
                        cv2.setWindowProperty(
                            config.window_title,
                            cv2.WND_PROP_FULLSCREEN,
                            cv2.WINDOW_FULLSCREEN
                            if fullscreen
                            else cv2.WINDOW_NORMAL,
                        )
            except Exception as error:
                if stop:
                    break
                LOG.warning("debug stream disconnected: %s; reconnecting", error)
                time.sleep(1.0)
    finally:
        recorder.stop()
        cv2.destroyAllWindows()


def main() -> None:
    parser = argparse.ArgumentParser(description="电脑端钢球检测调试画面")
    parser.add_argument(
        "--config", default=str(PROJECT_ROOT / "config" / "debug-client.toml")
    )
    parser.add_argument("--stream-url")
    parser.add_argument("--replay", type=Path)
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    config = load_debug_config(args.config)
    if args.replay is not None:
        replay(args.replay.expanduser().resolve(), config.window_title + " - Replay")
        return
    if args.stream_url:
        config = replace(config, stream_url=args.stream_url)
    run(config)


if __name__ == "__main__":
    main()
