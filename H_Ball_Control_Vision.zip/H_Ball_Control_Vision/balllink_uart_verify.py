#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""树莓派5 USB转串口 BallLink 确定性验证程序。

编码检查（不打开串口）：
    python3 balllink_uart_verify.py --encode-only

USB转串口持续真实发送（按Ctrl+C停止）：
    python3 balllink_uart_verify.py

模块TX与RX短接后的自环测试：
    python3 balllink_uart_verify.py --loopback

有限发送500帧：
    python3 balllink_uart_verify.py --count 500

每帧固定32字节、默认50 Hz，CONTROL_ENABLED始终为0。
"""

from __future__ import annotations

import argparse
import struct
import time

from hball.drivers.usb_serial import resolve_usb_serial_port


MAGIC = b"\xA5\x5A"
VERSION = 0x02
FRAME_TYPE = 0x10
PAYLOAD_LENGTH = 24
FRAME_LENGTH = 32

BALL_VALID = 0x01
VELOCITY_VALID = 0x02
CAMERA_CALIBRATED = 0x04
VISION_FLAGS = BALL_VALID | VELOCITY_VALID | CAMERA_CALIBRATED
CONTROL_FLAGS_SAFE = 0x00

# 使用此前串口助手数据中的固定值，方便逐字节直接比较。
SESSION_ID = 0xECDB7B85
FIRST_SEQUENCE = 0x97
FIRST_TIMESTAMP_MS = 0x000977EB
X_0P1MM = 500
CONFIDENCE = 220
RUN_ID = 0xA284


def crc16_ccitt_false(data: bytes) -> int:
    crc = 0xFFFF
    for value in data:
        crc ^= value << 8
        for _ in range(8):
            crc = (
                ((crc << 1) ^ 0x1021) & 0xFFFF
                if crc & 0x8000
                else (crc << 1) & 0xFFFF
            )
    return crc


def encode_packet(index: int) -> bytes:
    sequence = (FIRST_SEQUENCE + index) & 0xFF
    timestamp_ms = (FIRST_TIMESTAMP_MS + index * 20) & 0xFFFFFFFF
    payload = struct.pack(
        "<IIIhhBBhBBH",
        SESSION_ID,
        timestamp_ms,
        0,  # capture_to_send_delay_us
        X_0P1MM,
        0,  # v_mmps
        CONFIDENCE,
        VISION_FLAGS,
        0,  # target_x_0p1mm
        0,  # task_id = IDLE
        CONTROL_FLAGS_SAFE,
        RUN_ID,
    )
    body = bytes((VERSION, FRAME_TYPE, sequence, PAYLOAD_LENGTH)) + payload
    packet = MAGIC + body + struct.pack("<H", crc16_ccitt_false(body))
    verify_packet(packet)
    return packet


def verify_packet(packet: bytes) -> None:
    if len(packet) != FRAME_LENGTH:
        raise RuntimeError(f"帧长错误：{len(packet)}，应为32")
    if packet[:2] != MAGIC:
        raise RuntimeError("帧头错误")
    if packet[2] != VERSION or packet[3] != FRAME_TYPE:
        raise RuntimeError("版本或消息类型错误")
    if packet[5] != PAYLOAD_LENGTH:
        raise RuntimeError(f"LENGTH错误：{packet[5]}")
    expected_crc = struct.unpack_from("<H", packet, 30)[0]
    actual_crc = crc16_ccitt_false(packet[2:30])
    if actual_crc != expected_crc:
        raise RuntimeError(
            f"CRC错误：计算0x{actual_crc:04X}，帧内0x{expected_crc:04X}"
        )


def print_packet(index: int, packet: bytes) -> None:
    sequence = packet[4]
    crc = struct.unpack_from("<H", packet, 30)[0]
    print(
        f"FRAME[{index:02d}] len={len(packet)} "
        f"seq=0x{sequence:02X} crc=0x{crc:04X}"
    )
    print(packet.hex(" ").upper())


def open_serial(port: str):
    try:
        import serial
    except ImportError as error:
        raise RuntimeError(
            "未安装pyserial，请执行：sudo apt install python3-serial"
        ) from error

    return serial.Serial(
        port=port,
        baudrate=115200,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=1.0,
        write_timeout=1.0,
        xonxoff=False,
        rtscts=False,
        dsrdtr=False,
        exclusive=True,
    )


def run(
    *,
    port: str,
    count: int,
    interval_ms: float,
    encode_only: bool,
    loopback: bool,
) -> None:
    if count < 0:
        raise ValueError("count不能为负数；0表示持续发送")
    if interval_ms < 20:
        raise ValueError("interval-ms不能小于20")
    if encode_only and loopback:
        raise ValueError("--encode-only与--loopback不能同时使用")

    preview_count = count if 0 < count < 3 else 3
    print("前三帧确定性数据：" if preview_count == 3 else "待发送数据：")
    for index in range(preview_count):
        packet = encode_packet(index)
        print_packet(index, packet)

    if encode_only:
        print(
            f"ENCODE-ONLY完成：生成{preview_count}帧、"
            f"{preview_count * FRAME_LENGTH}字节，"
            "串口实际发送0字节"
        )
        return

    resolved_port = resolve_usb_serial_port(port)
    serial_port = open_serial(resolved_port)
    sent_frames = 0
    sent_bytes = 0
    loopback_passed = 0
    period_ns = int(round(interval_ms * 1_000_000))
    started_ns = time.monotonic_ns()
    next_tick_ns = started_ns
    next_report_ns = started_ns + 1_000_000_000
    index = 0

    try:
        serial_port.reset_input_buffer()
        print(
            f"打开 {resolved_port}：115200-8-N-1，"
            f"{'模块TX<->RX自环' if loopback else 'USB串口真实发送'}"
        )
        print(
            "发送方式："
            + ("持续发送，按Ctrl+C停止" if count == 0 else f"发送{count}帧后停止")
        )
        while count == 0 or index < count:
            now_ns = time.monotonic_ns()
            if now_ns < next_tick_ns:
                time.sleep((next_tick_ns - now_ns) / 1_000_000_000)
                now_ns = time.monotonic_ns()
            elif now_ns - next_tick_ns > period_ns * 2:
                next_tick_ns = now_ns

            packet = encode_packet(index)
            written = serial_port.write(packet)
            if written != FRAME_LENGTH:
                raise RuntimeError(
                    f"FRAME[{index:02d}]短写：{written}/{FRAME_LENGTH}"
                )
            sent_frames += 1
            sent_bytes += written

            if loopback:
                serial_port.flush()
                received = serial_port.read(FRAME_LENGTH)
                if received != packet:
                    print(
                        f"LOOPBACK[{index:02d}] FAIL "
                        f"rx_len={len(received)}"
                    )
                    print("TX:", packet.hex(" ").upper())
                    print("RX:", received.hex(" ").upper())
                    raise RuntimeError("USB转串口模块TX/RX自环数据不一致")
                loopback_passed += 1
                if index < 3:
                    print(f"LOOPBACK[{index:02d}] PASS，32/32字节一致")

            index += 1
            next_tick_ns += period_ns
            report_ns = time.monotonic_ns()
            if report_ns >= next_report_ns:
                elapsed_s = (report_ns - started_ns) / 1_000_000_000
                actual_hz = sent_frames / elapsed_s
                print(
                    f"TX正常：frames={sent_frames} bytes={sent_bytes} "
                    f"rate={actual_hz:.2f}Hz "
                    f"loopback={loopback_passed}"
                )
                while next_report_ns <= report_ns:
                    next_report_ns += 1_000_000_000
    except KeyboardInterrupt:
        print("\n收到Ctrl+C，停止发送")
    finally:
        serial_port.close()

    print(
        f"完成：串口写入{sent_frames}帧、{sent_bytes}字节；"
        f"自环通过{loopback_passed}帧"
    )
    print(
        "串口助手中相邻A5 5A之间必须正好32字节，"
        "不得出现额外00。"
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="树莓派5 USB转串口 BallLink 确定性验证"
    )
    parser.add_argument(
        "--port",
        default="/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0",
        help="CH340稳定by-id路径；更换模块后可用auto-usb诊断",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=0,
        help="发送帧数；0表示持续发送（默认）",
    )
    parser.add_argument("--interval-ms", type=float, default=20.0)
    parser.add_argument(
        "--encode-only",
        action="store_true",
        help="只验证编码并打印HEX，不打开串口",
    )
    parser.add_argument(
        "--loopback",
        action="store_true",
        help="USB转串口模块TX与RX短接后，发送并读取同一帧",
    )
    args = parser.parse_args()

    try:
        run(
            port=args.port,
            count=args.count,
            interval_ms=args.interval_ms,
            encode_only=args.encode_only,
            loopback=args.loopback,
        )
    except (OSError, RuntimeError, ValueError) as error:
        raise SystemExit(f"验证失败：{error}") from error


if __name__ == "__main__":
    main()
