#!/usr/bin/env bash
# Read-only one-command competition check for Raspberry Pi.

set -u

PROJECT_DIR="${HBALL_PROJECT_DIR:-/home/pi/Desktop/H_Ball_Control_Vision}"
STATUS_URL="http://127.0.0.1:8080/status.json"

echo "=== H-Ball competition check ==="
cd "$PROJECT_DIR" || {
  echo "FAIL project missing: $PROJECT_DIR"
  exit 1
}

python3 -c "import hball; print('version=', hball.__version__, sep='')"

if systemctl is-active --quiet hball-vision.service; then
  echo "service=OK"
else
  echo "service=WARN (not managed by hball-vision.service)"
fi

if ip -4 address show wlan1 2>/dev/null | grep -q "192.168.50.1/24"; then
  echo "hotspot_ip=OK"
else
  echo "hotspot_ip=WARN (UART vision remains independent)"
fi

if ! payload="$(curl -fsS --max-time 2 "$STATUS_URL")"; then
  echo "FAIL status unavailable: $STATUS_URL"
  exit 2
fi

printf '%s' "$payload" | python3 -c '
import json, sys
s = json.load(sys.stdin)
fps = float(s.get("detection_fps") or 0)
ms = float(s.get("processing_ewma_ms") or 0)
delay = s.get("telemetry_capture_to_send_delay_us")
delay_ok = delay is None or int(delay) <= 77000
print("camera={:.1f}fps".format(float(s.get("camera_fps") or 0)))
print("vision={:.1f}fps processing={:.1f}ms".format(fps, ms))
print("frame_start_age={}ms result_age={}ms".format(
    s.get("frame_start_age_ms", "NONE"),
    s.get("result_age_ms", "NONE"),
))
print("superseded={} stale_before_decode={}".format(
    s.get("superseded_camera_frames", 0),
    s.get("stale_before_decode_frames", 0),
))
print("capture_to_send={}us".format(delay if delay is not None else "NONE"))
print("background={}".format("OK" if s.get("registered_background_ready") else "NO"))
print("uart={}".format("OK" if s.get("uart_tx_open") else "NO"))
realtime = (
    bool(s.get("control_realtime_ready"))
    and bool(s.get("registered_background_ready"))
    and bool(s.get("uart_tx_open"))
    and delay_ok
)
print("control_realtime={}".format("OK" if realtime else "NO"))
print("video_full_rate_safe={}".format(
    "YES" if s.get("video_full_rate_safe") else "NO (10fps control protection)"
))
if not realtime:
    raise SystemExit(3)
'
result=$?

echo "PAD=http://192.168.50.1:8080/"
echo "stream=http://192.168.50.1:8080/stream.mjpg"

if [ "$result" -eq 0 ]; then
  echo "PASS control chain timing is ready"
else
  echo "WARN wait for startup background, then require vision>=30fps, processing<=40ms, delay<=77000us"
fi
exit "$result"
