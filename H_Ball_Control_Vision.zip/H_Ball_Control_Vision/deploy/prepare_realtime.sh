#!/usr/bin/env bash
# Root-only, bounded preparation for deterministic competition timing.

set -eu

changed=0
for governor in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    if [ -f "$governor" ]; then
        printf '%s\n' performance > "$governor"
        changed=1
    fi
done

if [ -w /sys/module/usbcore/parameters/autosuspend ]; then
    printf '%s\n' -1 > /sys/module/usbcore/parameters/autosuspend
fi

if [ "$changed" -eq 0 ]; then
    echo "WARN: no CPU governor controls found" >&2
fi
