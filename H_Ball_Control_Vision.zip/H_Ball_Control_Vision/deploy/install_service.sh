#!/usr/bin/env bash
# Install or refresh the boot-time OLED/task supervisor on Raspberry Pi.

set -eu

PROJECT_DIR="${HBALL_PROJECT_DIR:-/home/pi/Desktop/H_Ball_Control_Vision}"
SERVICE_SOURCE="$PROJECT_DIR/deploy/hball-vision.service"
SERVICE_TARGET="/etc/systemd/system/hball-vision.service"

test -f "$PROJECT_DIR/config/pi.toml"
test -f "$SERVICE_SOURCE"

sudo install -m 0644 "$SERVICE_SOURCE" "$SERVICE_TARGET"
sudo systemctl daemon-reload
sudo systemctl enable --now hball-vision.service
sudo systemctl --no-pager --full status hball-vision.service

echo "PAD: http://192.168.50.1:8080/"
