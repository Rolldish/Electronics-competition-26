# -*- coding: utf-8 -*-
"""上场前摄像头、标定和视觉状态自检。

直接运行：
    python3 system_selftest.py
"""

from hball.tasks.selftest import main


if __name__ == "__main__":
    main()
